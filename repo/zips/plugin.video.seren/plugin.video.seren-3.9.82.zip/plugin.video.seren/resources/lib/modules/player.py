import copy
import importlib
import json
import sys
import time
from functools import cached_property
from urllib import parse

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib.common import tools
from resources.lib.database.trakt_sync import bookmark
from resources.lib.indexers import trakt
from resources.lib.modules import catalog_profiles, locale_playback, smartPlay
from resources.lib.modules.globals import g


class SerenPlayer(xbmc.Player):
    """
    Class to handle playback methods and accept callbacks from Kodi player
    """

    def __init__(self):
        super().__init__()

        self.trakt_id = None
        self.mediatype = None
        self.offset = None
        self.playing_file = None
        self.scrobbling_enabled = g.get_bool_setting("trakt.scrobbling", True)
        self.item_information = None
        self.smart_playlists = g.get_bool_setting("smartplay.playlistcreate")
        self.smart_module = None
        self.current_time = 0
        self.total_time = 0
        self.watched_percentage = 0
        self.ignoreSecondsAtStart = g.get_int_setting("trakt.ignoreSecondsAtStart")
        self.min_time_before_scrape = 600
        self.playCountMinimumPercent = g.get_int_setting("trakt.playCountMinimumPercent")
        self.mdblist_ignoreSecondsAtStart = g.get_int_setting("mdblist.ignoreSecondsAtStart")
        self.mdblist_playCountMinimumPercent = g.get_int_setting("mdblist.playCountMinimumPercent")
        self.mdblist_scrobbling_enabled = g.get_bool_setting("mdblist.scrobbling", True)
        self.simkl_ignoreSecondsAtStart = g.get_int_setting("simkl.ignoreSecondsAtStart")
        self.simkl_playCountMinimumPercent = g.get_int_setting("simkl.playCountMinimumPercent")
        self.simkl_scrobbling_enabled = g.get_bool_setting("simkl.scrobbling", True)
        self.dialogs_enabled = g.get_bool_setting("smartplay.playingnextdialog") or g.get_bool_setting(
            "smartplay.stillwatching"
        )
        self.pre_scrape_enabled = g.get_bool_setting("smartPlay.preScrape")
        self.playing_next_time = g.get_int_setting("playingnext.time")
        self.trakt_enabled = bool(g.get_setting("trakt.auth", "")) and g.get_bool_setting("trakt.enabled", False)
        self._running_path = None

        # Flags
        self.resumed = False
        self.playback_started = False
        self.playback_error = False
        self.playback_ended = False
        self.playback_stopped = False
        self.stop_event_received = False  # Set by onPlayBackStopped regardless of playback_started
        self._end_playback_done = False  # Guard: prevents double-execution of _end_playback()
        self._playback_marker = ""  # Value this play wrote to the seren.playback Home property (see g.set_playback_marker)
        self._locale_backup = None  # Pre-override Kodi locale snapshot from apply_catalog_locale()
        self.scrobbled = False
        self.scrobble_started = False
        self.last_attempted_scrobble_stop = 0
        self.last_attempted_scrobble_pause = 0
        self.mdblist_enabled = g.get_bool_setting("mdblist.enabled") and bool(g.get_setting("mdblist.auth") or g.get_setting("mdblist.apikey"))
        self.mdblist_scrobbled = False
        self.last_attempted_mdblist_stop = 0
        self.last_attempted_mdblist_pause = 0
        self.simkl_enabled = bool(g.get_setting("simkl.auth", "")) and g.get_bool_setting("simkl.enabled", True)
        self.simkl_scrobbled = False
        self.simkl_scrobble_started = False
        self.last_attempted_simkl_stop = 0
        self.last_attempted_simkl_pause = 0
        self.simkl_anime_target = None  # (ids, episode inside the entry) / False; resolved on the first Simkl request
        self.simkl_anime_used = False  # the last Simkl request was the entry-based one and Simkl took it
        self.simkl_anime_failed = False  # Simkl answered 404 to the entry-based request: not tried again in this playback
        self.marked_watched = False
        self.dialogs_triggered = False
        self.pre_scrape_initiated = False
        self.playback_timestamp = 0

        # Skip segment handler (intro/recap/credits/preview across anime/TV/movies)
        self._skip_handler = None
        # Per-segment-type one-shot trigger guard. Resets if user seeks back into a segment.
        self._skip_state = {
            "intro": {"inside": False, "shown": False, "last_t": None},
            "recap": {"inside": False, "shown": False, "last_t": None},
            "credits": {"inside": False, "shown": False, "last_t": None},
            "preview": {"inside": False, "shown": False, "last_t": None},
        }

        # Per-type enable toggles (introduced in 3.3.92 — replaces anime.skip* names).
        self._skip_enabled = {
            "intro": g.get_bool_setting("skip.intro"),
            "recap": g.get_bool_setting("skip.recap"),
            "credits": g.get_bool_setting("skip.credits"),
            "preview": g.get_bool_setting("skip.preview"),
        }
        self._skip_auto = {
            "intro":   g.get_bool_setting("skip.autoIntro"),
            "recap":   g.get_bool_setting("skip.autoRecap"),
            "credits": g.get_bool_setting("skip.autoCredits"),
            "preview": g.get_bool_setting("skip.autoPreview"),
        }
        self._skip_offset = g.get_int_setting("skip.offset")

        # Anime-only fallback timer (used when AniSkip/Anime-Skip have no data)
        self._skip_fallback_delay = g.get_int_setting("anime.skipFallbackDelay")
        self._skip_fallback_duration = g.get_int_setting("anime.skipFallbackDuration")
        self._skip_fallback_offset = g.get_int_setting("anime.skipFallbackOffset")

    @cached_property
    def _trakt_api(self):
        return trakt.TraktAPI()

    @cached_property
    def _mdblist_api(self):
        from resources.lib.indexers.mdblist import MDBListAPI

        return MDBListAPI()

    @cached_property
    def _simkl_api(self):
        from resources.lib.indexers.simkl import SimklAPI

        return SimklAPI()

    @cached_property
    def bookmark_sync(self):
        return bookmark.TraktSyncDatabase()

    def play_source(self, stream_link, item_information, resume_time=None):
        """Method for handling playing of sources.

        :param stream_link: Direct link of source to be played or dict containing more information about the stream
        to play
        :type stream_link: str|dict
        :param item_information: Information about the item to be played
        :type item_information:dict
        :param resume_time:Time to resume the source at
        :type resume_time:int
        :rtype:None
        """
        self.pre_scrape_initiated = False
        if resume_time:
            self.offset = float(resume_time)

        if not stream_link:
            g.cancel_playback()
            return

        self.playing_file = stream_link
        self.item_information = item_information
        self.smart_module = smartPlay.SmartPlay(item_information)
        self.mediatype = self.item_information["info"]["mediatype"]
        self.trakt_id = self.item_information["info"]["trakt_id"]

        self._locale_backup = locale_playback.apply_catalog_locale(
            catalog_profiles.resolve_catalog_from_item_information(self.item_information)
        )

        if self.item_information.get("resume", "false") == "true":
            self._try_get_bookmark()

        self._handle_bookmark()
        self._add_support_for_external_trakt_scrobbling()

        self.playing_next_time = max(self.playing_next_time, (self.item_information["info"].get("duration") or 0) * (1 - (g.get_int_setting("playingnext.percent") / 100)))

        self._playback_marker = g.set_playback_marker(item_information)
        xbmcplugin.setResolvedUrl(g.PLUGIN_HANDLE, True, self._create_list_item(stream_link))

        # Start skip-segment handler in background for episodes and movies
        if any(self._skip_enabled.values()) and self.mediatype in (g.MEDIA_EPISODE, g.MEDIA_MOVIE):
            try:
                from resources.lib.modules.skip.skip_handler import SkipHandler
                episode_number = self.item_information["info"].get("episode", 0) if self.mediatype == g.MEDIA_EPISODE else 0
                if self.mediatype == g.MEDIA_MOVIE or episode_number:
                    self._skip_handler = SkipHandler(self.item_information, episode_number)
                    self._skip_handler.start()
            except Exception as e:
                g.log(f"Skip handler init failed: {e}", "debug")

        self._keep_alive()

    def attach_to_playing(self, stream_link, item_information, resume_time=None):
        """Attach lifecycle management to an already-playing stream.

        Used by PlaybackWatchdog — the stream is already playing via
        xbmc.Player().play(). This sets up Trakt scrobbling, bookmarks,
        Playing Next dialogs, anime skip, and enters _keep_alive() —
        everything play_source() does except setResolvedUrl.

        :param stream_link: URL of the currently playing stream
        :param item_information: Metadata on the playing item
        :param resume_time: Time to seek to (if resuming)
        """
        self.pre_scrape_initiated = False
        if resume_time:
            self.offset = float(resume_time)
            # Watchdog already seeked to the resume position before the
            # monitoring window. Mark as resumed so _keep_alive() doesn't
            # do a second seek 30s later.
            self.resumed = True

        if not stream_link:
            return

        self.playing_file = stream_link
        self.item_information = item_information
        self.smart_module = smartPlay.SmartPlay(item_information)
        self.mediatype = self.item_information["info"]["mediatype"]
        self.trakt_id = self.item_information["info"]["trakt_id"]

        self._locale_backup = locale_playback.apply_catalog_locale(
            catalog_profiles.resolve_catalog_from_item_information(self.item_information)
        )

        if self.item_information.get("resume", "false") == "true":
            self._try_get_bookmark()

        self._handle_bookmark()
        self._add_support_for_external_trakt_scrobbling()
        self._playback_marker = g.set_playback_marker(item_information)

        self.playing_next_time = max(
            self.playing_next_time,
            (self.item_information["info"].get("duration") or 0)
            * (1 - (g.get_int_setting("playingnext.percent") / 100)),
        )

        # Stream is already playing via watchdog's Player.play().
        # Do NOT call setResolvedUrl here — when TMDb Helper is the
        # launching player, setResolvedUrl(True) causes Kodi to route
        # the resolution back through TMDb Helper, which opens a new
        # VideoPlayer and kills the watchdog's working stream.
        # The plugin handle is released by g.cancel_playback() in the
        # router before the watchdog starts.

        # Manually trigger start state
        self.playback_started = True
        self.playback_timestamp = time.time()
        try:
            self._running_path = self.getPlayingFile()
        except Exception:
            self._running_path = stream_link

        g.close_busy_dialog()
        g.close_all_dialogs()

        # Smart playlist handling
        if self.smart_playlists and self.mediatype == "episode":
            if g.PLAYLIST.size() == 1 and not self.smart_module.is_season_final():
                self.smart_module.build_playlist()
            elif g.PLAYLIST.size() == g.PLAYLIST.getposition() + 1:
                self.smart_module.append_next_season()

        # Start skip-segment handler in background for episodes and movies
        if any(self._skip_enabled.values()) and self.mediatype in (g.MEDIA_EPISODE, g.MEDIA_MOVIE):
            try:
                from resources.lib.modules.skip.skip_handler import SkipHandler
                episode_number = self.item_information["info"].get("episode", 0) if self.mediatype == g.MEDIA_EPISODE else 0
                if self.mediatype == g.MEDIA_MOVIE or episode_number:
                    self._skip_handler = SkipHandler(self.item_information, episode_number)
                    self._skip_handler.start()
            except Exception as e:
                g.log(f"Skip handler init failed: {e}", "debug")

        self._keep_alive()

    # region Kodi player overrides
    def getTotalTime(self):
        """
        Returns total time for playing file if user is playing a file
        :return: Total length of file else 0 if not playing an item
        :rtype: int
        """
        try:
            return super().getTotalTime()
        except RuntimeError:
            g.log("Trying to get player total time while not playing", "warning")
            return 0

    def getTime(self):
        """
        Gets current position in seconds from start of item
        :return: Current position or 0 if not playing a file
        :rtype: int
        """
        try:
            return current_time if (current_time := super().getTime()) > 0 else 0
        except RuntimeError:
            g.log("Trying to get player time while not playing", "warning")
            return 0

    def isPlayingVideo(self):
        """
        Returns true if currently playing item is a video file
        :return: True if playing a file and it is video else False
        :rtype: bool
        """
        return super().isPlayingVideo()

    def seekTime(self, time):
        """
        Seeks the specified amount of time as fractional seconds if playing a file. The time specified is relative to
        the beginning of the currently. playing media file.
        :param time: Time to seek as fractional seconds
        :type time: float
        :return: None
        :rtype: None
        """
        try:
            super().seekTime(time)
        except RuntimeError:
            g.log("Trying to seek player when not playing a file", "warning")

    def getSubtitles(self):
        """
        Get subtitle stream name if playing a file
        :return: Stream Name if playing a file else None
        :rtype: str, None
        """
        return subtitles if (subtitles := super().getSubtitles()) else None

    def getAvailableSubtitleStreams(self):
        """
        Get Subtitle stream names.
        :return: List of available subtitle streams
        :rtype: list, None
        """
        return super().getAvailableSubtitleStreams() if self.isPlaying() else None

    def setSubtitles(self, subtitle):
        """
        Set subtitle file and enable subtitles if currently playing an item.
        :param subtitle:  Path to file to use as source of subtitles
        :type subtitle: str
        :return: None
        :rtype: None
        """
        if self.isPlaying():
            super().setSubtitles(subtitle)
        else:
            g.log("Trying to set subtitles when not playing a file", "warning")

    def getPlayingFile(self):
        """
        Fetches the path to the playing file else returns None
        :return: Path to file
        :rtype: str/None
        """
        try:
            return super().getPlayingFile()
        except RuntimeError:
            # seems that we have a racing condition between isPlaying() and getPlayingFile()
            g.log("Trying to get playing file when not playing a file", "warning")

    # endregion

    # region Kodi player callbacks
    def onAVStarted(self):
        """
        Callback method from Kodi to advise that AV stream has started
        :return: None
        :rtype: None
        """
        self._start_playback()

    def onAVChange(self):
        """
        Callback method from Kodi to advise that AV stream has started
        This is being used as a fallback for instances where AVStarted fails
        :return: None
        :rtype: None
        """
        self._start_playback()

    def onPlayBackSeek(self, time, seekOffset):
        """
        Callback method from Kodi when a seek event has occured
        :param time: Time to seek to
        :type time: int
        :param seekOffset: Offset from previous position
        :type seekOffset: int
        :return: None
        :rtype: None
        """
        seekOffset /= 1000
        self._trakt_start_watching(offset=seekOffset, re_scrobble=True)

    def onPlayBackSeekChapter(self, chapter):
        """
        Callback method from Kodi when user performs a chapter seek.
        :param chapter: Chapter seeked to
        :type chapter: int
        :return: None
        :rtype: None
        """
        self._trakt_start_watching(re_scrobble=True)

    def onPlayBackResumed(self):
        """
        Callback method from Kodi when user resumes a paused file.
        :return: None
        :rtype: None
        """
        self._trakt_start_watching(re_scrobble=True)
        self._simkl_start_watching(re_scrobble=True)

    def onPlayBackEnded(self):
        """
        Callback method from Kodi when playback has finished
        :return: None
        :rtype: None
        """
        self.playback_ended = bool(self.playback_started)
        self._end_playback()
        if g.PLAYLIST.getposition() == g.PLAYLIST.size() or g.PLAYLIST.size() == 1:
            g.PLAYLIST.clear()

    def onPlayBackStopped(self):
        """
        Callback method from Kodi when user stops a file.
        :return: None
        :rtype: None
        """
        self.playback_stopped = bool(self.playback_started)
        self.stop_event_received = True
        g.PLAYLIST.clear()
        g.close_busy_dialog()
        g.close_all_dialogs()
        self._end_playback()

    def onPlayBackPaused(self):
        """
        Callback method from Kodi when user pauses a file.
        :return: None
        :rtype: None
        """
        self._handle_bookmark()
        self._trakt_stop_watching()
        self._mdblist_stop_watching()
        self._simkl_stop_watching()

    def onPlayBackError(self):
        """
        Callback method from Kodi when playback stops due to an error
        :return: None
        :rtype: None
        """
        g.log("Kodi has reported an error and has stopped playback!", "warning")
        self.playback_error = True
        g.PLAYLIST.clear()
        g.close_busy_dialog()
        g.close_all_dialogs()
        self._end_playback()

    # endregion

    def _start_playback(self):
        if self.playback_started:
            return

        self.playback_started = True
        self.playback_timestamp = time.time()
        self._running_path = self.getPlayingFile()

        g.close_busy_dialog()
        g.close_all_dialogs()

        if self.smart_playlists and self.mediatype == "episode":
            if g.PLAYLIST.size() == 1 and not self.smart_module.is_season_final():
                self.smart_module.build_playlist()
            elif g.PLAYLIST.size() == g.PLAYLIST.getposition() + 1:
                self.smart_module.append_next_season()

    def _end_playback(self):
        if self._end_playback_done:
            return
        self._end_playback_done = True
        g.clear_playback_marker(self._playback_marker)
        locale_playback.restore_catalog_locale(self._locale_backup)
        self._handle_bookmark()
        self._trakt_stop_watching()
        self._mdblist_stop_watching()
        self._simkl_stop_watching()
        self._trakt_mark_playing_item_watched()
        self._debrid_post_playback_cleanup()
        if g.get_bool_setting("general.force.widget.refresh.playback"):
            # trigger_widget_refresh() has a blocking wait loop — never call it directly
            # from within a Kodi player callback (onPlayBackStopped fires inside
            # g.wait_for_abort(), so a nested wait_for_abort() inside the refresh loop
            # deadlocks the thread permanently). Run it on a daemon thread instead.
            import threading
            threading.Thread(target=g.trigger_widget_refresh, daemon=True).start()

    def _debrid_post_playback_cleanup(self):
        """Unified smart auto-delete for all debrid services.
        Deletes the resolved torrent/transfer from cloud if fully watched.
        Keeps in cloud if stopped early (for later viewing).
        Works for Real-Debrid, Premiumize, AllDebrid, TorBox, and Debrid-Link."""
        try:
            from resources.lib.debrid.debrid_utils import get_pending_cleanup

            pending = get_pending_cleanup()
            if not pending:
                return

            # If playback never started (CDN failed, stream error, etc.),
            # silently discard the cleanup record — nothing to decide on.
            if not self.playback_started:
                g.log(
                    f"Smart delete ({pending['service']}): Discarding cleanup for "
                    f"{pending['item_id']} — playback never started",
                    "debug",
                )
                return

            service = pending["service"]
            item_id = pending["item_id"]
            delete_method = pending["delete_method"]

            # Check if fully watched using same threshold as Trakt scrobbling
            if self.watched_percentage >= self.playCountMinimumPercent:
                # Fully watched — delete from cloud
                debrid_module = self._get_debrid_module(service)
                if debrid_module:
                    getattr(debrid_module, delete_method)(item_id)
                    g.log(
                        f"Smart delete ({service}): Deleted item {item_id} "
                        f"(watched {self.watched_percentage}%)",
                        "info",
                    )
            else:
                # Stopped early — keep in cloud for later
                g.log(
                    f"Smart delete ({service}): Keeping item {item_id} "
                    f"in cloud (watched {self.watched_percentage}%)",
                    "info",
                )
        except Exception as e:
            g.log(f"Smart delete cleanup error: {e}", "warning")

    @staticmethod
    def _get_debrid_module(service):
        """Lazy-load the appropriate debrid module by service name."""
        if service == "real_debrid":
            from resources.lib.debrid.real_debrid import RealDebrid
            return RealDebrid()
        elif service == "premiumize":
            from resources.lib.debrid.premiumize import Premiumize
            return Premiumize()
        elif service == "all_debrid":
            from resources.lib.debrid.all_debrid import AllDebrid
            return AllDebrid()
        elif service == "torbox":
            from resources.lib.debrid.torbox import TorBox
            return TorBox()
        elif service == "debrid_link":
            from resources.lib.debrid.debrid_link import DebridLink
            return DebridLink()
        return None

    def _get_kodi_preferred_subtitle_language(self):
        language = g.get_kodi_preferred_subtitle_language(True)
        if language == "original":
            audio_streams = self.getAvailableAudioStreams()
            if not audio_streams or len(audio_streams) == 0:
                return None
            return audio_streams[0]
        elif language == "default":
            return xbmc.getLanguage(xbmc.ISO_639_2)
        elif language in ["none", "forced_only"]:
            return None
        else:
            return language

    def _create_list_item(self, stream_link):
        info = copy.deepcopy(self.item_information["info"])
        g.clean_info_keys(info)
        g.convert_info_dates(info)

        if isinstance(stream_link, dict) and stream_link["type"] == "adaptive":
            if g.ADDON_USERDATA_PATH not in sys.path:
                sys.path.append(g.ADDON_USERDATA_PATH)
            provider = stream_link["provider_imports"]
            provider_module = importlib.import_module(f"{provider[0]}.{provider[1]}")
            if not hasattr(provider_module, "get_listitem") and hasattr(provider_module, "sources"):
                provider_module = provider_module.sources()
            item = provider_module.get_listitem(stream_link)
            g.set_video_info(item, info)
        else:
            item = xbmcgui.ListItem(path=stream_link)
            info["FileNameAndPath"] = parse.unquote(self.playing_file)
            g.set_video_info(item, info)
            item.setProperty("IsPlayable", "true")

        art = self.item_information.get("art", {})
        item.setArt(art if isinstance(art, dict) else {})
        cast = self.item_information.get("cast", [])
        g.set_video_cast(item, cast if isinstance(cast, list) else [])
        # Same ids as add_directory_item gives the list row: the show's ids for episodes and seasons. Read from the
        # uncleaned info, since clean_info_keys drops every *_id key.
        raw_info = self.item_information["info"]
        id_prefix = "tvshow." if raw_info.get("mediatype") in g._EPISODE_SEASON_TYPES else ""
        g.set_video_unique_ids(
            item,
            {
                unique_id_key: raw_info[f"{id_prefix}{id_key}"]
                for id_key, unique_id_key in g._ID_KEYS.items()
                if raw_info.get(f"{id_prefix}{id_key}")
            },
        )
        return item

    def _add_support_for_external_trakt_scrobbling(self):
        trakt_meta = {}
        keys = {
            "tmdb_id": "tmdb",
            "imdb_id": "imdb",
            "trakt_slug": "slug",
            "tvdb_id": "tvdb",
            "trakt_id": "trakt",
        }

        info = self.item_information.get("info", {})
        for id in keys:
            meta_id = info.get(f"tvshow.{id}" if info.get("mediatype") == "episode" else id)
            if meta_id:
                trakt_meta[keys[id]] = meta_id

        g.HOME_WINDOW.setProperty("script.trakt.ids", json.dumps(trakt_meta, sort_keys=True))

    def _update_progress(self, offset=None):
        if not self._is_file_playing():
            return

        self.current_time = self.getTime()

        if offset is not None:
            self.current_time += offset

        if self.total_time > 0:
            try:
                self.watched_percentage = tools.safe_round(float(self.current_time) / float(self.total_time) * 100, 2)
                self.watched_percentage = min(self.watched_percentage, 100)
            except TypeError:
                pass

    def _log_debug_information(self):
        g.log(f"PlaybackIdentifedAt: {self.getTime()}", "debug")
        g.log(f"IgnoringSecondsAtStart: {self.ignoreSecondsAtStart}", "debug")
        g.log(f"PreScrapeSeconds: {self.min_time_before_scrape}", "debug")
        g.log(f"PlayCountMin: {self.playCountMinimumPercent}", "debug")
        g.log(f"DialogsEnabled: {self.dialogs_enabled}", "debug")
        g.log(f"TraktEnabled: {self.trakt_enabled}", "debug")
        g.log(f"DialogSeconds: {self.playing_next_time}", "debug")
        g.log(f"TotalMediaLength: {self.getTotalTime()}", "debug")

    # region Trakt
    def _trakt_start_watching(self, offset=None, re_scrobble=False):
        if (
            not self.trakt_enabled
            or not self.scrobbling_enabled
            or (self.scrobbled and not re_scrobble)
            or (self.scrobble_started and not re_scrobble)
        ):
            return

        if self.watched_percentage >= self.playCountMinimumPercent or self.current_time < self.ignoreSecondsAtStart:
            return

        try:
            post_data = self._build_trakt_object(offset=offset)

            self._trakt_api.post("scrobble/start", post_data)
        except Exception:
            g.log_stacktrace()
        self.scrobble_started = True

    def _trakt_stop_watching(self):
        if (
            not self.trakt_enabled
            or not self.scrobbling_enabled
            or self.scrobbled
            or self.current_time < self.ignoreSecondsAtStart
        ):
            return

        post_data = self._build_trakt_object()

        if post_data["progress"] >= self.playCountMinimumPercent:
            if time.time() - self.last_attempted_scrobble_stop < 30 and not g.abort_requested():
                return
            post_data["progress"] = max(post_data["progress"], 80)
            try:
                scrobble_response = self._trakt_api.post("scrobble/stop", post_data)
            except Exception:
                g.log_stacktrace()
                return
            finally:
                self.last_attempted_scrobble_stop = time.time()
            if scrobble_response.status_code in (201, 409):
                self.scrobbled = True
                self._trakt_mark_playing_item_watched()
                if scrobble_response.status_code == 201:
                    try:
                        action = scrobble_response.json()["action"]
                        if action != "scrobble":
                            g.log(f"Trakt scrobble/stop returned action: {action}", "warning")
                    except Exception:
                        g.log_stacktrace()
                return
            else:
                g.log(f"Trakt scrobble/stop returned status code: {scrobble_response.status_code}", "warning")
        elif self.current_time > self.ignoreSecondsAtStart:
            if (pause_time := time.time() - self.last_attempted_scrobble_pause) < 5:
                g.log(f"Trakt scrobble/pause repeat called: {pause_time}s", "warning")
            try:
                scrobble_response = self._trakt_api.post("scrobble/pause", post_data)
            except Exception:
                g.log_stacktrace()
                return
            finally:
                self.last_attempted_scrobble_pause = time.time()
            if scrobble_response.status_code != 201:
                g.log(f"Trakt scrobble/pause returned status code: {scrobble_response.status_code}", "warning")

    def _trakt_mark_playing_item_watched(self):
        if (
            not self.trakt_enabled
            or self.marked_watched
            or not self.playback_started
            or not self.watched_percentage >= self.playCountMinimumPercent
        ):
            return

        self.marked_watched = True

        if self.mediatype == "episode":
            from resources.lib.database.trakt_sync.shows import TraktSyncDatabase

            TraktSyncDatabase().mark_episode_watched(
                self.item_information["info"]["trakt_show_id"],
                self.item_information["info"]["season"],
                self.item_information["info"]["episode"],
            )
        if self.mediatype == "movie":
            from resources.lib.database.trakt_sync.movies import TraktSyncDatabase

            TraktSyncDatabase().mark_movie_watched(self.trakt_id)

        # Clear L1 list cache so watched status reflects immediately on next list build
        try:
            from resources.lib.database.trakt_sync import clear_list_cache
            clear_list_cache()
        except Exception:
            pass

    def _build_trakt_object(self, offset=None):
        post_data = {self.mediatype: {"ids": {"trakt": self.trakt_id}}}
        if offset:
            self._update_progress(offset)
        post_data["app_version"] = g.VERSION

        post_data["progress"] = self.watched_percentage
        return post_data

    # endregion

    # region MDBList
    def _build_mdblist_object(self):
        info = self.item_information["info"]
        if self.mediatype == "movie":
            tmdb_id = info.get("tmdb_id")
            if not tmdb_id:
                return None
            return {"movie": {"ids": {"tmdb": tmdb_id}}, "progress": self.watched_percentage}
        if self.mediatype == "episode":
            tmdb_show_id = info.get("tmdb_show_id")
            season = info.get("season")
            episode = info.get("episode")
            if not tmdb_show_id or season is None or episode is None:
                return None
            return {
                "show": {
                    "ids": {"tmdb": tmdb_show_id},
                    "season": {"number": season, "episode": {"number": episode}},
                },
                "progress": self.watched_percentage,
            }
        return None

    def _mdblist_stop_watching(self):
        if (
            not self.mdblist_enabled
            or not self.mdblist_scrobbling_enabled
            or self.mdblist_scrobbled
            or self.current_time < self.mdblist_ignoreSecondsAtStart
        ):
            return

        post_data = self._build_mdblist_object()
        if post_data is None:
            return

        if post_data["progress"] >= self.mdblist_playCountMinimumPercent:
            if time.time() - self.last_attempted_mdblist_stop < 30 and not g.abort_requested():
                return
            post_data["progress"] = max(post_data["progress"], 80)
            try:
                response = self._mdblist_api.post("scrobble/stop", post_data)
            except Exception:
                g.log_stacktrace()
                return
            finally:
                self.last_attempted_mdblist_stop = time.time()
            if response is not None and response.ok:
                self.mdblist_scrobbled = True
                try:
                    action = response.json().get("action")
                    if action != "scrobble":
                        g.log(f"MDBList scrobble/stop returned action: {action}", "warning")
                except Exception:
                    g.log_stacktrace()
                self._mdblist_write_watched_locally()
            else:
                g.log(
                    f"MDBList scrobble/stop returned status code: {response.status_code if response is not None else 'no response'}",
                    "warning",
                )
        elif self.current_time > self.mdblist_ignoreSecondsAtStart:
            if (pause_time := time.time() - self.last_attempted_mdblist_pause) < 5:
                g.log(f"MDBList scrobble/pause repeat called: {pause_time}s", "warning")
            try:
                response = self._mdblist_api.post("scrobble/pause", post_data)
            except Exception:
                g.log_stacktrace()
                return
            finally:
                self.last_attempted_mdblist_pause = time.time()
            if response is None or not response.ok:
                g.log(
                    f"MDBList scrobble/pause returned status code: {response.status_code if response is not None else 'no response'}",
                    "warning",
                )

    def _mdblist_write_watched_locally(self):
        from resources.lib.database.mdblist_sync import MDBListSyncDatabase

        MDBListSyncDatabase().write_watched_locally(self.mediatype, self.item_information["info"])

        # Clear L1 list cache so watched status reflects immediately on next list build
        try:
            from resources.lib.database.trakt_sync import clear_list_cache
            clear_list_cache()
        except Exception:
            pass

    # endregion

    # region Simkl
    def _build_simkl_object(self):
        info = self.item_information["info"]
        if self.mediatype == "movie":
            tmdb_id = info.get("tmdb_id")
            if not tmdb_id:
                return None
            return {"progress": self.watched_percentage, "movie": {"ids": {"tmdb": tmdb_id}}}
        if self.mediatype == "episode":
            tmdb_show_id = info.get("tmdb_show_id")
            season = info.get("season")
            episode = info.get("episode")
            if not tmdb_show_id or season is None or episode is None:
                return None
            return {
                "progress": self.watched_percentage,
                "show": {"ids": {"tmdb": tmdb_show_id}},
                "episode": {"season": season, "number": episode},
            }
        return None

    def _simkl_start_watching(self, re_scrobble=False):
        # Never call this from a seek callback - Simkl's docs explicitly forbid
        # scrobble/start on seek events, and the 20s per-user write lock would
        # 400 on rapid seeks. Only wire this to real play/resume events.
        if (
            not self.simkl_enabled
            or not self.simkl_scrobbling_enabled
            or (self.simkl_scrobbled and not re_scrobble)
            or (self.simkl_scrobble_started and not re_scrobble)
        ):
            return

        if (
            self.watched_percentage >= self.simkl_playCountMinimumPercent
            or self.current_time < self.simkl_ignoreSecondsAtStart
        ):
            return

        post_data = self._build_simkl_object()
        if post_data is not None:
            try:
                self._simkl_post_scrobble("scrobble/start", post_data)
            except Exception:
                g.log_stacktrace()
        # Set even on failure/missing-metadata so the keep_alive loop doesn't
        # retry this every 0.5s for the rest of the playback.
        self.simkl_scrobble_started = True

    def _simkl_stop_watching(self):
        if (
            not self.simkl_enabled
            or not self.simkl_scrobbling_enabled
            or self.simkl_scrobbled
            or self.current_time < self.simkl_ignoreSecondsAtStart
        ):
            return

        post_data = self._build_simkl_object()
        if post_data is None:
            return

        if post_data["progress"] >= self.simkl_playCountMinimumPercent:
            if time.time() - self.last_attempted_simkl_stop < 30 and not g.abort_requested():
                return
            post_data["progress"] = max(post_data["progress"], 80)
            try:
                # an anime episode goes out as its entry first, with the TMDb numbers (then the IMDb / TVDB ids) as the
                # fallback when Simkl does not know the entry
                response = self._simkl_post_scrobble("scrobble/stop", post_data, retry_other_ids=True)
            except Exception:
                g.log_stacktrace()
                return
            finally:
                self.last_attempted_simkl_stop = time.time()
            # simkl.apib doesn't pin the write endpoints to one status code the way
            # Trakt's does (201) - check .ok rather than hardcoding a number. 409
            # means "already marked watched in the last hour" - treat as success.
            if response.ok or response.status_code == 409:
                self.simkl_scrobbled = True
                response_json = {}
                if response.ok:
                    try:
                        response_json = response.json() or {}
                        action = response_json.get("action")
                        if action != "scrobble":
                            g.log(f"Simkl scrobble/stop returned action: {action}", "warning")
                    except Exception:
                        g.log_stacktrace()
                        response_json = {}
                self._simkl_write_watched_locally(response_json)
            else:
                g.log(f"Simkl scrobble/stop returned status code: {response.status_code}", "warning")
        elif self.current_time > self.simkl_ignoreSecondsAtStart:
            if (pause_time := time.time() - self.last_attempted_simkl_pause) < 5:
                g.log(f"Simkl scrobble/pause repeat called: {pause_time}s", "warning")
            try:
                response = self._simkl_post_scrobble("scrobble/pause", post_data)
            except Exception:
                g.log_stacktrace()
                return
            finally:
                self.last_attempted_simkl_pause = time.time()
            if not response.ok:
                g.log(f"Simkl scrobble/pause returned status code: {response.status_code}", "warning")

    def _simkl_anime_body(self, post_data):
        """The scrobble body for the anime entry (cour) a TMDb episode belongs to, in the anime-native form Simkl documents
        (``anime`` + anidb / mal / anilist ids, ``episode.number`` counted inside the entry, no season); None when
        the episode is not a mapped anime episode.  Simkl places TMDb season / episode numbers by TVDB coordinates, so
        S01E49 of Apothecary Diaries (TVDB S4E1, Simkl entry of cour 3, episode 1) is a 404 under the TMDb numbers.
        The entry comes from ``resolve_episode_entry`` (Fribb offset confirmed by the air date), resolved once.  The entry's
        Simkl id is NOT sent: Simkl tries it first and Fribb's value is wrong for some rows (the row of Apothecary Diaries
        cour 3 carries the id of cour 4, a 2027 title), while the anime-native ids alone find the right entry."""
        if self.mediatype != "episode":
            return None
        if self.simkl_anime_target is None:
            self.simkl_anime_target = False
            try:
                from resources.lib.modules.anime.anilist_mapping import resolve_episode_entry

                resolved = resolve_episode_entry(self.item_information)
            except Exception:
                g.log_stacktrace()
                resolved = None
            if resolved:
                entry, number = resolved
                ids = {
                    key: entry[field]
                    for key, field in (("anidb", "anidb_id"), ("mal", "mal_id"), ("anilist", "anilist_id"))
                    if entry.get(field)
                }
                if ids and number:
                    self.simkl_anime_target = (ids, int(number))
        if not self.simkl_anime_target:
            return None
        ids, number = self.simkl_anime_target
        body = {key: value for key, value in post_data.items() if key not in ("show", "movie", "episode")}
        body["anime"] = {"ids": dict(ids)}
        body["episode"] = {"number": number}
        return body

    def _simkl_post_scrobble(self, path, post_data, retry_other_ids=False):
        """POST a scrobble.  An anime episode that resolves to its entry (cour) is sent as that entry FIRST: Simkl places
        TMDb season / episode numbers by TVDB coordinates, so under them a merged season can be refused (404) or - worse -
        accepted into the wrong cour with a success answer that no fallback could notice.  When Simkl does not know the
        entry (404) the request goes out once more with the TMDb numbers and, for the final stop (``retry_other_ids``),
        with the IMDb / TVDB ids, as before; the entry-based request is then not tried again in this playback.  Any other
        failure of the entry-based request (429 / 5xx) is returned as it is, without a second request (Simkl allows one
        scrobble per user every 20 s).  Episodes that do not resolve use the TMDb numbers only."""
        if not self.simkl_anime_failed:
            body = self._simkl_anime_body(post_data)
            if body:
                response = self._simkl_api.post(path, body)
                if response.status_code != 404:
                    self.simkl_anime_used = response.ok or response.status_code == 409
                    return response
                self.simkl_anime_failed = True
                g.log(
                    f"Simkl {path}: unknown anime {body['anime']['ids']} episode {body['episode']['number']} (HTTP 404), "
                    "sending the TMDb numbers instead",
                    "warning",
                )
        self.simkl_anime_used = False
        response = self._simkl_api.post(path, post_data)
        if response.status_code == 404 and retry_other_ids:
            response = self._simkl_retry_by_other_ids(path, post_data, response)
        return response

    def _simkl_alt_ids(self):
        """The IMDb / TVDB ids of the playing movie, or of the show for an episode (those are the ids Simkl knows a
        show by), for a retry after Simkl did not know the TMDb id."""
        info = self.item_information["info"]
        if self.mediatype == "movie":
            pairs = (("imdb", info.get("imdb_id")), ("tvdb", info.get("tvdb_id")))
        else:
            pairs = (
                ("imdb", info.get("tvshow.imdb_id")),
                ("tvdb", info.get("tvshow.tvdb_id") or info.get("tvdb_show_id")),
            )
        return {key: value for key, value in pairs if value}

    def _simkl_retry_by_other_ids(self, path, post_data, response):
        """Simkl 404s a scrobble whose TMDb id it does not know (a finished episode then never reached Simkl). Sends
        the same request once more with the IMDb / TVDB ids added; returns the new response, or the old one when there
        is nothing to retry with or the retry could not be made."""
        ids = self._simkl_alt_ids()
        key = "movie" if self.mediatype == "movie" else "show"
        if not ids or not isinstance(post_data.get(key), dict):
            g.log(f"Simkl {path}: unknown TMDb id and no IMDb or TVDB id to try instead", "warning")
            return response
        retry = {**post_data, key: {**post_data[key], "ids": {**post_data[key].get("ids", {}), **ids}}}
        try:
            retried = self._simkl_api.post(path, retry)
        except Exception:
            g.log_stacktrace()
            return response
        g.log(
            f"Simkl {path}: unknown TMDb id, retried with {'/'.join(ids)}: HTTP {retried.status_code}",
            "info" if retried.ok else "warning",
        )
        return retried

    def _simkl_write_watched_locally(self, response_json):
        """Write-through counterpart to _mdblist_write_watched_locally, closing the gap
        where Simkl's scrobbler never wrote local state at all (unlike MDBList/Trakt).
        Prefers the simkl id echoed back in the scrobble/stop response - simkl.apib
        documents its body shape as identical to /scrobble/start, whose own response
        includes the media object's ids, but /stop's response shape isn't
        independently confirmed in the docs, hence the debug log (to settle it via
        live test) and the safe fallback to the existing UPDATE-only mark methods
        when no id comes back."""
        from resources.lib.database.simkl_sync import SimklSyncDatabase

        info = self.item_information["info"]
        media_key = "movie" if self.mediatype == "movie" else "show"
        ids = (response_json.get(media_key) or response_json.get("anime") or {}).get("ids") or {}
        simkl_id = ids.get("simkl") or ids.get("simkl_id")
        if self.simkl_anime_used:
            # the echoed id is the id of the cour, not of the show the local table is keyed by: only count the episode
            # on a show row that already exists (UPDATE branch), never insert the cour id as the show
            simkl_id = None
        g.log(f"Simkl scrobble/stop response ids: {ids}", "debug")

        db = SimklSyncDatabase()
        if self.mediatype == "movie":
            tmdb_id = info.get("tmdb_id")
            if simkl_id:
                db.upsert_movie_watched_locally(simkl_id, tmdb_id, ids.get("imdb") or info.get("imdb_id"))
            else:
                db.mark_movie_watched_locally(tmdb_id)
        elif self.mediatype == "episode":
            tmdb_show_id = info.get("tmdb_show_id")
            if simkl_id or self.simkl_anime_used:
                db.upsert_show_episode_watched_locally(tmdb_show_id, simkl_id, ids.get("imdb"), ids.get("tvdb"))
            else:
                g.log("Simkl scrobble/stop response carried no show ids - skipping local episode write", "warning")

        try:
            from resources.lib.database.trakt_sync import clear_list_cache

            clear_list_cache()
        except Exception:
            pass

    # endregion

    def _keep_alive(self):
        for _ in range(480):
            if self._is_file_playing() or self._playback_has_stopped() or g.wait_for_abort(0.25):
                break

        self.total_time = self.getTotalTime()
        self.min_time_before_scrape = max(self.total_time * 0.2, self.min_time_before_scrape)

        if self.offset and not self.resumed:
            self.seekTime(self.offset)
            self.resumed = True

        self._log_debug_information()

        while not g.wait_for_abort(0.5) and self._is_file_playing():  # This order is correct! Wait then check.
            self._update_progress()

            if not self.scrobble_started:
                self._trakt_start_watching()

            if not self.simkl_scrobble_started:
                self._simkl_start_watching()

            time_left = int(self.total_time) - int(self.current_time)

            # Skip-segment check (intro/recap/credits/preview)
            self._check_skip()

            if self.min_time_before_scrape > time_left and not self.pre_scrape_initiated:
                self._handle_pre_scrape()

            if self.watched_percentage >= self.playCountMinimumPercent and self.scrobble_started and not self.scrobbled:
                self._handle_bookmark()
                self._trakt_stop_watching()

            if (
                self.watched_percentage >= self.mdblist_playCountMinimumPercent
                and self.mdblist_enabled
                and not self.mdblist_scrobbled
            ):
                self._mdblist_stop_watching()

            if (
                self.watched_percentage >= self.simkl_playCountMinimumPercent
                and self.simkl_scrobble_started
                and not self.simkl_scrobbled
            ):
                self._simkl_stop_watching()

            if self.dialogs_enabled and not self.dialogs_triggered and time_left <= self.playing_next_time:
                xbmc.executebuiltin('RunPlugin("plugin://plugin.video.seren/?action=runPlayerDialogs")')
                self.dialogs_triggered = True

        if not self._playback_has_stopped():
            # Kodi fires onPlayBackStopped/onPlayBackEnded asynchronously — wait up to 2s
            # for the callback to arrive before falling back to a direct _end_playback() call.
            for _i in range(40):  # 40 × 50 ms = 2 s max
                if self._playback_has_stopped() or g.wait_for_abort(0.05):
                    break
            if not self._playback_has_stopped():
                # Kodi did not fire any callback — call _end_playback() directly
                # (guard inside prevents double-execution if callback races in later)
                self._end_playback()

    def _playback_has_stopped(self):
        return self.playback_stopped or self.playback_error or self.playback_ended or self.stop_event_received

    def _check_skip(self):
        """Check if current playback position is in any enabled skip segment.

        Handles up to four segment types in chronological order:
        - intro:   start..end → "Skip Intro" overlay (or auto-skip when enabled)
        - recap:   start..end → "Skip Recap" overlay
        - credits: start..end → mid-file credits "Skip Credits" overlay
                   start..None (runs to end of media) → trigger Playing Next
        - preview: same dual behaviour as credits

        Re-entry on seek-back is detected and re-shows the overlay once per entry.
        Anime fallback timer (anime.skipFallback*) still applies when no API data
        is available and the underlying handler reports anime content.
        """
        if not self._skip_handler or not self._skip_handler.ready:
            return

        current = int(self.current_time)
        segments = self._skip_handler.segments

        # Walk segment types in chronological order so the right overlay fires when
        # ranges overlap. A real episode plays as: recap → intro → … → credits → preview.
        for seg_type in ("recap", "intro", "credits", "preview"):
            if not self._skip_enabled.get(seg_type):
                continue

            seg_list = segments.get(seg_type) or []
            base_offset = self._skip_offset

            # Anime intro fallback: AniSkip/Anime-Skip miss → use timer
            if (
                seg_type == "intro"
                and not seg_list
                and self._skip_handler.is_anime
                and self._skip_fallback_duration > 0
            ):
                seg_list = [(self._skip_fallback_delay,
                             self._skip_fallback_delay + self._skip_fallback_duration)]
                base_offset = self._skip_fallback_offset

            for idx, seg_tup in enumerate(seg_list):
                offset = base_offset
                start, end = seg_tup

                # credits/preview with end=None means "runs to end of media" — handle below
                ends_at_media_end = end is None
                if ends_at_media_end:
                    try:
                        end = max(0, int(self.total_time) - 10)
                    except Exception:
                        continue

                if start is None or end is None or end <= start:
                    continue

                if not self._segment_entry_check((seg_type, idx), current, start, end):
                    continue

                # We've entered the segment for the first time (or re-entered after seek-back)
                self._dispatch_segment(seg_type, start, end, offset, ends_at_media_end)

    def _segment_entry_check(self, state_key, current, seg_start, seg_end, margin=0.25):
        """One-shot-per-entry guard. Mirrors TheIntroDB addon's re-entry logic.

        Returns True the first poll after the playhead enters the segment range,
        and False on every subsequent poll until the playhead leaves it. If the
        user seeks back into the segment, the next entry yields True again.
        """
        state = self._skip_state.setdefault(
            state_key, {"inside": False, "shown": False, "last_t": None}
        )

        inside = seg_start <= current < (seg_end - margin)
        prev_t = state.get("last_t")

        if not inside:
            state["inside"] = False
            state["shown"] = False
            state["last_t"] = current
            return False

        reentered = (not state["inside"])
        if prev_t is not None and current + margin < prev_t:
            reentered = True

        if reentered:
            state["shown"] = False

        state["inside"] = True
        state["last_t"] = current

        if state["shown"]:
            return False

        state["shown"] = True
        return True

    def _dispatch_segment(self, seg_type, start, end, offset, ends_at_media_end):
        """Auto-skip, fire Playing Next, or show the Skip overlay for a segment."""
        target = end + offset
        src = self._skip_handler.sources.get(seg_type, "?")

        if self._skip_auto.get(seg_type, False):
            # credits/preview at end-of-media with auto-skip on → trigger Playing Next silently
            if seg_type in ("credits", "preview") and ends_at_media_end:
                if self.dialogs_enabled and not self.dialogs_triggered:
                    g.set_runtime_setting("anime.skipOutroEnd", str(int(end)))
                    xbmc.executebuiltin('RunPlugin("plugin://plugin.video.seren/?action=runPlayerDialogs")')
                    self.dialogs_triggered = True
                    g.log(f"Skip: auto-triggered Playing Next from {seg_type} ({src})", "debug")
            else:
                self.seekTime(target)
                g.log(f"Skip: auto-skipped {seg_type} ({src}) → {target}s", "debug")
            return

        # credits/preview that run to the end of media → use Playing Next dialog
        if seg_type in ("credits", "preview") and ends_at_media_end:
            if self.dialogs_enabled and not self.dialogs_triggered:
                g.set_runtime_setting("anime.skipOutroEnd", str(int(end)))
                xbmc.executebuiltin('RunPlugin("plugin://plugin.video.seren/?action=runPlayerDialogs")')
                self.dialogs_triggered = True
                g.log(f"Skip: triggered Playing Next from {seg_type} ({src})", "debug")
            return

        # Otherwise show the Skip overlay (intro/recap, or mid-file credits/preview)
        g.set_runtime_setting("seren.skipSegmentEnd", str(int(target)))
        g.set_runtime_setting("seren.skipSegmentType", seg_type)
        xbmc.executebuiltin('RunPlugin("plugin://plugin.video.seren/?action=showSkipIntro")')
        g.log(f"Skip: showing {seg_type} overlay (target={target}s, src={src})", "debug")

    def _handle_pre_scrape(self):
        if self.pre_scrape_enabled and not self.pre_scrape_initiated:
            self.smart_module.pre_scrape()
            self.pre_scrape_initiated = True

    def _try_get_bookmark(self):
        bm = self.bookmark_sync.get_bookmark(self.trakt_id)
        self.offset = bm.get("resumeTime") if bm else None

    def _handle_bookmark(self):
        try:
            g.clear_kodi_bookmarks()
        except Exception:
            g.log_stacktrace()
        try:
            if self.current_time == 0 or self.total_time == 0:
                self.bookmark_sync.remove_bookmark(self.trakt_id)
                return

            if self.watched_percentage < self.playCountMinimumPercent and self.current_time >= self.ignoreSecondsAtStart:
                self.bookmark_sync.set_bookmark(
                    self.trakt_id,
                    int(self.current_time),
                    self.mediatype,
                    self.watched_percentage,
                )
            else:
                self.bookmark_sync.remove_bookmark(self.trakt_id)
        except Exception:
            g.log("_handle_bookmark: DB unavailable at teardown — skipping bookmark sync", "warning")

    def _is_file_playing(self):
        if not self.playback_started or self._playback_has_stopped() or self._running_path is None:
            return False

        return self.isPlayingVideo()


class PlayerDialogs(xbmc.Player):
    """
    Handles dialogs that appear over playing items
    """

    def __init__(self):
        super().__init__()
        self._min_time = g.get_int_setting("playingnext.time")
        self.playing_file = None

    def display_dialog(self):
        """
        Handles the initiating of dialogs and deciding which dialog to display if required
        :return: None
        :rtype: None
        """
        try:
            self.playing_file = self.getPlayingFile()
        except RuntimeError:
            g.log("Kodi did not return a playing file, killing playback dialogs", "error")
            return
        if g.PLAYLIST.size() > 0 and g.PLAYLIST.getposition() != (g.PLAYLIST.size() - 1):
            if g.get_bool_setting("smartplay.stillwatching") and self._still_watching_calc():
                target = self._show_still_watching
            elif g.get_bool_setting("smartplay.playingnextdialog"):
                target = self._show_playing_next
            else:
                return

            if self.playing_file != self.getPlayingFile():
                return

            if not self.isPlayingVideo():
                return

            if not self._is_video_window_open():
                return

            target()

    @staticmethod
    def _still_watching_calc():
        calculation = float(g.PLAYLIST.getposition() + 1) / g.get_float_setting("stillwatching.numepisodes")

        return False if calculation == 0 else calculation.is_integer()

    def _show_playing_next(self):
        from resources.lib.gui.windows.playing_next import PlayingNext
        from resources.lib.database.skinManager import SkinManager

        try:
            window = PlayingNext(
                *SkinManager().confirm_skin_path("playing_next.xml"),
                item_information=self._get_next_item_item_information(),
            )
            window.doModal()
        finally:
            del window

    def _show_still_watching(self):
        from resources.lib.gui.windows.still_watching import StillWatching
        from resources.lib.database.skinManager import SkinManager

        try:
            window = StillWatching(
                *SkinManager().confirm_skin_path("still_watching.xml"),
                item_information=self._get_next_item_item_information(),
            )
            window.doModal()
        finally:
            del window

    @staticmethod
    def _get_next_item_item_information():
        current_position = g.PLAYLIST.getposition()
        url = g.PLAYLIST[current_position + 1].getPath()  # pylint: disable=unsubscriptable-object
        params = dict(parse.parse_qsl(parse.unquote(url.split("?")[1])))
        return tools.get_item_information(tools.deconstruct_action_args(params.get("action_args")))

    @staticmethod
    def _is_video_window_open():
        return xbmcgui.getCurrentWindowId() == 12005


def show_skip_intro_dialog():
    """Module-level function called via RunPlugin to show the Skip overlay.

    Reads the segment end-time and type from runtime settings and forwards them
    to the SkipIntro window so it can render the correct button label.
    """
    try:
        # Prefer new generic key; fall back to legacy anime-only key for compatibility.
        skip_end = g.get_runtime_setting("seren.skipSegmentEnd")
        seg_type = g.get_runtime_setting("seren.skipSegmentType") or "intro"
        if not skip_end:
            skip_end = g.get_runtime_setting("anime.skipIntroEnd")
            seg_type = "intro"
        if not skip_end:
            return
        skip_end = int(float(skip_end))
        g.clear_runtime_setting("seren.skipSegmentEnd")
        g.clear_runtime_setting("seren.skipSegmentType")
        g.clear_runtime_setting("anime.skipIntroEnd")

        from resources.lib.database.skinManager import SkinManager
        from resources.lib.gui.windows.skip_intro import SkipIntro

        window = SkipIntro(
            *SkinManager().confirm_skin_path("skip_intro.xml"),
            skip_end=skip_end,
            segment_type=seg_type,
        )
        window.doModal()
        del window
    except Exception:
        g.log_stacktrace()
