import contextlib
import threading
import time
from functools import cached_property
from functools import wraps
from urllib import parse

import xbmc
import xbmcgui

from . import valid_id_or_none
from resources.lib.common import tools
from resources.lib.database.cache import use_cache
from resources.lib.indexers.apibase import ApiBase
from resources.lib.indexers.apibase import handle_single_item_or_list
from resources.lib.modules.exceptions import AuthFailure
from resources.lib.modules.exceptions import RanOnceAlready
from resources.lib.modules.global_lock import GlobalLock
from resources.lib.modules.globals import g

CLOUDFLARE_ERROR_MSG = "Service Unavailable - Cloudflare error"


class _Headers(dict):
    """Case-insensitive read access to the response headers (keys are stored lower case)."""

    def __getitem__(self, key):
        return super().__getitem__(str(key).lower())

    def __contains__(self, key):
        return super().__contains__(str(key).lower())

    def get(self, key, default=None):
        return super().get(str(key).lower(), default)


class _CachedResponse:
    """What Seren reads from a cached Trakt page (status, headers, body) without holding a requests.Response:
    loading a cached requests.Response imports `requests` (and urllib3), a large share of the time a cached list took."""

    __slots__ = ("status_code", "headers", "content", "url")

    def __init__(self, status_code, headers, content, url):
        self.status_code = status_code
        self.headers = _Headers((str(k).lower(), v) for k, v in dict(headers).items())
        self.content = content
        self.url = url

    @classmethod
    def from_response(cls, response):
        if response is None:
            return None
        return cls(response.status_code, response.headers, response.content, response.url)

    @property
    def ok(self):
        return self.status_code < 400

    def __bool__(self):
        return self.ok

    def json(self):
        import json

        return json.loads(self.content)

TRAKT_STATUS_CODES = {
    200: "Success",
    201: "Success - new resource created (POST)",
    204: "Success - no content to return (DELETE)",
    400: "Bad Request - request couldn't be parsed",
    401: "Unauthorized - OAuth must be provided",
    403: "Forbidden - invalid API key or unapproved app",
    404: "Not Found - method exists, but no record found",
    405: "Method Not Found - method doesn't exist",
    409: "Conflict - resource already created",
    412: "Precondition Failed - use application/json content type",
    420: "Limit Exceeded - reached max allowed items (e.g. Favorites cap)",
    422: "Unprocessable Entity - validation errors",
    423: "Locked User Account - Contact Trakt support",
    426: "VIP Only - user must upgrade to VIP",
    429: "Rate Limit Exceeded",
    500: "Server Error - please open a support issue",
    502: "Service Unavailable - server overloaded (try again in 30s)",
    503: "Service Unavailable - server overloaded (try again in 30s)",
    504: "Service Unavailable - server overloaded (try again in 30s)",
    520: CLOUDFLARE_ERROR_MSG,
    521: CLOUDFLARE_ERROR_MSG,
    522: CLOUDFLARE_ERROR_MSG,
    524: CLOUDFLARE_ERROR_MSG,
    530: CLOUDFLARE_ERROR_MSG,
}


def _log_connection_error(args, kwarg, e):
    g.log(f"Connection Error to Trakt: {args} - {kwarg}", "error")
    g.log(e, "error")


def _connection_failure_dialog():
    if (
        g.get_float_setting("general.trakt.failure.timeout") + (2 * 60 * (60 * 60)) < time.time()
        and not xbmc.Player().isPlaying()
    ):
        xbmcgui.Dialog().notification(g.ADDON_NAME, g.get_language_string(30024).format("Trakt"))
        g.set_setting("general.trakt.failure.timeout", str(time.time()))


def _reset_trakt_auth(notify=True):
    settings = ["trakt.refresh", "trakt.auth", "trakt.expires", "trakt.username"]
    for i in settings:
        g.clear_setting(i)
    if notify and g.get_bool_setting("general.watchAccountNotifications", True):
        xbmcgui.Dialog().ok(g.ADDON_NAME, g.get_language_string(30536))


def trakt_guard_response(func):
    """
    Decorator for Trakt API requests, handles retries and error responses
    :param func:
    :return:
    """

    @wraps(func)
    def wrapper(*args, **kwargs):
        """
        Wrapper method for decorator
        :param args: method args
        :param kwargs: method kwargs
        :return:
        """
        method_class = args[0]
        method_class._load_settings()
        import requests

        try:
            response = func(*args, **kwargs)
            if response.status_code in [200, 201, 204]:
                return response

            if response.status_code == 400 and response.url == "https://api.trakt.tv/oauth/device/token":
                return response
            if response.status_code == 400 and response.url == "https://api.trakt.tv/oauth/token":
                _reset_trakt_auth()
                raise AuthFailure("Unable to refresh Trakt auth")

            if response.status_code == 403:
                g.log("Trakt: invalid API key or unapproved app, resetting auth", "error")
                _reset_trakt_auth()
                g.cancel_directory()
                return None

            if response.status_code == 401:
                import inspect

                if inspect.stack(1)[1][3] == "try_refresh_token":
                    if g.get_bool_setting("general.watchAccountNotifications", True):
                        xbmcgui.Dialog().notification(g.ADDON_NAME, g.get_language_string(30340))
                    g.log(
                        "Attempts to refresh Trakt token have failed. User intervention is required",
                        "error",
                    )
                else:
                    with contextlib.suppress(RanOnceAlready):
                        with GlobalLock("trakt.oauth", run_once=True, check_sum=method_class.access_token):
                            if method_class.refresh_token is not None:
                                method_class.try_refresh_token(True)
                            if method_class.refresh_token is None and method_class.username is not None:
                                if g.get_bool_setting("general.watchAccountNotifications", True):
                                    xbmcgui.Dialog().ok(g.ADDON_NAME, g.get_language_string(30340))
                    if method_class.refresh_token is not None:
                        return func(*args, **kwargs)

            if response.status_code == 423:
                xbmcgui.Dialog().notification(g.ADDON_NAME, TRAKT_STATUS_CODES.get(response.status_code))
                g.log(
                    "Locked User Account - Contact Trakt support",
                    "error",
                )

            g.log(
                f"Trakt returned a {response.status_code} "
                f"({TRAKT_STATUS_CODES.get(response.status_code, '*Unknown status code*')}): "
                f"while requesting {response.url}",
                "error",
            )

            return response
        except requests.exceptions.ConnectionError as e:
            _log_connection_error(args, kwargs, e)
            raise
        except Exception as e:
            _connection_failure_dialog()
            _log_connection_error(args, kwargs, e)
            raise

    return wrapper


class TraktAPI(ApiBase):
    """
    Class to handle interactions with Trakt API
    """

    ApiUrl = "https://api.trakt.tv/"

    username_setting_key = "trakt.username"

    TranslationNormalization = [
        ("title", ("title", "originaltitle", "sorttitle"), None),
        ("language", "language", None),
        ("overview", ("plot", "plotoutline"), None),
    ]

    ReleaseNormalization = [
        ("country", "country", lambda c: c.upper()),
        ("release_date", "release_date", lambda rd: g.validate_date(rd)),
        ("release_type", "release_type", None),
        ("certification", "mpaa", None),
    ]

    UserRatingNormalization = [
        (
            "rating",
            "user_rating",
            lambda t: tools.safe_round(tools.get_clean_number(t), 2),
        ),
        ("rated_at", "rated_at", lambda t: g.validate_date(t)),
    ]

    PlayBackNormalization = [
        ("progress", "percentplayed", None),
        ("paused_at", "paused_at", lambda t: g.validate_date(t)),
        ("id", "playback_id", None),
    ]

    PlayBackHistoryNormalization = [
        ("action", "action", None),
        ("watched_at", "watched_at", lambda t: g.validate_date(t)),
        ("id", "playback_id", None),
    ]

    CalendarNormalization = [("first_aired", "first_aired", lambda t: g.validate_date(t))]

    Normalization = tools.extend_array(
        [
            ("certification", "mpaa", None),
            ("genres", "genre", None),
            (("ids", "imdb"), ("imdbnumber", "imdb_id"), lambda i: valid_id_or_none(i)),
            (("ids", "trakt"), "trakt_id", None),
            (("ids", "slug"), "trakt_slug", None),
            (("ids", "tvdb"), "tvdb_id", lambda i: valid_id_or_none(i)),
            (("ids", "tmdb"), "tmdb_id", lambda i: valid_id_or_none(i)),
            ("playback_id", "playback_id", None),
            (("show", "ids", "trakt"), "trakt_show_id", None),
            ("network", "studio", lambda n: [n]),
            ("runtime", "duration", lambda d: d * 60),
            ("progress", "percentplayed", None),
            ("percentplayed", "percentplayed", None),
            ("updated_at", "dateadded", lambda t: g.validate_date(t)),
            ("last_updated_at", "dateadded", lambda t: g.validate_date(t)),
            ("last_watched_at", "last_watched_at", lambda t: g.validate_date(t)),
            ("watched_at", "watched_at", lambda t: g.validate_date(t)),
            ("paused_at", "paused_at", lambda t: g.validate_date(t)),
            (
                "rating",
                "rating",
                lambda t: tools.safe_round(tools.get_clean_number(t), 2),
            ),
            ("votes", "votes", lambda t: tools.get_clean_number(t)),
            (
                None,
                "rating.trakt",
                (
                    ("rating", "votes"),
                    lambda r, v: {
                        "rating": tools.safe_round(tools.get_clean_number(r), 2),
                        "votes": tools.get_clean_number(v),
                    },
                ),
            ),
            ("tagline", "tagline", None),
            (
                "trailer",
                "trailer",
                lambda t: tools.youtube_url.format(t.split("?v=")[-1]) if t else None,
            ),
            ("type", "mediatype", lambda t: t if "show" not in t else "tvshow"),
            ("available_translations", "available_translations", None),
            ("score", "score", None),
            ("action", "action", None),
            ("added", "added", None),
            ("rank", "rank", None),
            ("listed_at", "listed_at", None),
            (
                "country",
                "country_origin",
                lambda t: t.upper() if t is not None else None,
            ),
            ("user_rating", "user_rating", None),
            ("rated_at", "rated_at", None),
        ],
        TranslationNormalization,
    )

    MoviesNormalization = tools.extend_array(
        [
            ("plays", "playcount", None),
            ("year", "year", None),
            ("released", ("premiered", "aired"), lambda t: g.validate_date(t)),
            ("collected_at", "collected_at", lambda t: g.validate_date(t)),
        ],
        Normalization,
    )

    ShowNormalization = tools.extend_array(
        [
            ("status", "status", None),
            ("status", "is_airing", lambda t: not t == "ended"),
            ("title", "tvshowtitle", None),
            ("first_aired", "year", lambda t: g.validate_date(t)[:4] if g.validate_date(t) else None),
            (
                "first_aired",
                ("premiered", "aired"),
                lambda t: g.validate_date(t),
            ),
            ("last_collected_at", "last_collected_at", lambda t: g.validate_date(t)),
            ("reset_at", "reset_at", lambda t: g.validate_date(t)),
        ],
        Normalization,
    )

    SeasonNormalization = tools.extend_array(
        [
            ("number", ("season", "sortseason"), None),
            ("episode_count", "episode_count", None),
            ("aired_episodes", "aired_episodes", None),
            ("first_aired", "year", lambda t: g.validate_date(t)[:4] if g.validate_date(t) else None),
            (
                "first_aired",
                ("premiered", "aired"),
                lambda t: g.validate_date(t),
            ),
            ("last_collected_at", "last_collected_at", lambda t: g.validate_date(t)),
        ],
        Normalization,
    )

    EpisodeNormalization = tools.extend_array(
        [
            ("number", ("episode", "sortepisode"), None),
            ("season", ("season", "sortseason"), None),
            ("collected_at", "collected", lambda t: 1),
            ("plays", "playcount", None),
            ("first_aired", "year", lambda t: g.validate_date(t)[:4] if g.validate_date(t) else None),
            (
                "first_aired",
                ("premiered", "aired"),
                lambda t: g.validate_date(t),
            ),
            ("collected_at", "collected_at", lambda t: g.validate_date(t)),
        ],
        Normalization,
    )

    ListNormalization = [
        ("updated_at", "dateadded", lambda t: g.validate_date(t)),
        (("ids", "trakt"), "trakt_id", None),
        (("ids", "slug"), "slug", None),
        ("sort_by", "sort_by", None),
        ("sort_how", "sort_how", None),
        (("user", "ids", "slug"), "username", None),
        ("name", ("name", "title"), None),
        ("type", "mediatype", None),
    ]

    MixedEpisodeNormalization = [
        (("show", "ids", "trakt"), "trakt_show_id", None),
        (("episode", "ids", "trakt"), "trakt_id", None),
    ]

    MixedSeasonNormalization = [
        (("show", "ids", "trakt"), "trakt_show_id", None),
        (("season", "ids", "trakt"), "trakt_id", None),
    ]

    MetaNormalization = {
        "movie": MoviesNormalization,
        "list": ListNormalization,
        "show": ShowNormalization,
        "season": SeasonNormalization,
        "episode": EpisodeNormalization,
        "mixedepisode": MixedEpisodeNormalization,
        "mixedseason": MixedSeasonNormalization,
        "playback": PlayBackNormalization,
        "playbackhistory": PlayBackHistoryNormalization,
        "user_rating": UserRatingNormalization,
        "calendar": CalendarNormalization,
        "releases": ReleaseNormalization,
    }

    MetaObjects = ("movie", "tvshow", "show", "season", "episode", "list")

    MetaCollections = ("movies", "shows", "seasons", "episodes", "cast")

    def __init__(self):
        self.access_token = None
        self.refresh_token = None
        self.token_expires = 0
        self.username = None
        self._load_settings()
        self.redirect_uri = "urn:ietf:wg:oauth:2.0:oob"
        self.try_refresh_token()
        self.language = g.get_language_code()
        self.country = g.get_language_code(True).split("-")[-1].lower()

    @cached_property
    def meta_hash(self):
        return tools.md5_hash((self.language, self.ApiUrl, self.username))

    @cached_property
    def trakt_db(self):
        from resources.lib.database import trakt_sync

        return trakt_sync.TraktSyncDatabase()

    @cached_property
    def session(self):
        import requests
        from requests.adapters import HTTPAdapter
        from urllib3 import Retry

        session = requests.Session()
        retries = Retry(
            total=4,
            backoff_factor=0.3,
            status_forcelist=[429, 500, 502, 503, 504, 520, 521, 522, 524, 530],
        )
        session.mount("https://", HTTPAdapter(max_retries=retries, pool_maxsize=100))
        return session

    # region Auth
    def _get_headers(self):
        headers = {
            "Content-Type": "application/json",
            "trakt-api-key": self.client_id,
            "trakt-api-version": "2",
            "User-Agent": g.USER_AGENT,
        }
        if self.access_token:
            headers["Authorization"] = f"Bearer {self.access_token}"
        return headers

    def revoke_auth(self):
        """
        Revokes current authorisation if present
        :return:
        """
        post_data = {"token": self.access_token, "client_id": self.client_id, "client_secret": self.client_secret}
        if self.access_token:
            url = "oauth/revoke"
            self.post(url, post_data)
        _reset_trakt_auth(notify=False)
        self.access_token = None
        self.refresh_token = None
        self.token_expires = 0
        self.username = None
        xbmcgui.Dialog().ok(g.ADDON_NAME, g.get_language_string(30021))

    def auth(self):
        """
        Performs OAuth with Trakt
        :return: None
        """
        self.username = None
        response = self.post("oauth/device/code", data={"client_id": self.client_id})
        if not response.ok:
            xbmcgui.Dialog().ok(g.ADDON_NAME, g.get_language_string(30162))
            return
        try:
            response = response.json()
            user_code = response["user_code"]
            device = response["device_code"]
            interval = int(response["interval"])
            token_ttl = int(response["expires_in"])
        except (KeyError, ValueError):
            xbmcgui.Dialog().ok(g.ADDON_NAME, g.get_language_string(30023))
            raise

        tools.copy2clip(user_code)

        verification_url = "https://trakt.tv/activate"
        qr_image = tools.make_qr(verification_url, "trakt_qr.png")

        from resources.lib.gui.windows.qr_auth_window import QRAuthWindow

        window = QRAuthWindow("qr_auth_window.xml", g.ADDON_PATH)
        window.set_title(g.get_language_string(30022))
        window.set_qr_image(qr_image)
        window.set_details(
            g.get_language_string(30018).format(verification_url),
            g.get_language_string(30019).format(user_code),
        )
        window_thread = threading.Thread(target=window.doModal)
        window_thread.start()

        failed = False
        try:
            while not failed and self.username is None and token_ttl > 0 and not window.canceled_by_user:
                xbmc.sleep(1000)
                if token_ttl % interval == 0:
                    failed = self._auth_poll(device)
                minutes, seconds = divmod(max(token_ttl, 0), 60)
                window.set_status(f"{minutes:02d}:{seconds:02d}")
                token_ttl -= 1
        finally:
            window.close()
            window_thread.join(5)
            del window

        if not failed and self.username:
            xbmcgui.Dialog().ok(g.ADDON_NAME, g.get_language_string(30273))
            self._sync_trakt_user_data_if_required()

    def _auth_poll(self, device):
        response = self.post(
            "oauth/device/token",
            data={
                "code": device,
                "client_id": self.client_id,
                "client_secret": self.client_secret,
            },
        )
        if response.status_code == 200:
            return self._auth_success(response)
        elif response.status_code in [404, 410]:
            xbmcgui.Dialog().ok(g.ADDON_NAME, g.get_language_string(30023))
            return True
        elif response.status_code == 409:
            return True
        elif response.status_code == 429:
            xbmc.sleep(1 * 1000)
        return False

    def _auth_success(self, response):
        response = response.json()
        self._save_settings(response)
        username = self.get_username()
        self.username = username
        g.set_setting(self.username_setting_key, username)
        return False

    def _sync_trakt_user_data_if_required(self):
        # Synchronise Trakt Database with new user
        from resources.lib.database.trakt_sync import activities

        database = activities.TraktSyncDatabase()
        if database.activities["trakt_username"] != self.username:
            database.clear_user_information(bool(database.activities["trakt_username"]))
            database.flush_activities(False)
            database.set_trakt_user(self.username)
            xbmc.executebuiltin(f'RunPlugin("{g.BASE_URL}?action=syncTraktActivities")')

    def try_refresh_token(self, force=False):
        """
        Attempts to refresh current Trakt Auth Token
        :param force: Set to True to force refresh
        :return: None
        """
        if not self.refresh_token:
            return
        if not force and self.token_expires > float(time.time()):
            return

        try:
            with GlobalLock(self.__class__.__name__, True, self.access_token):
                g.log("Trakt Token requires refreshing...")
                response = self.post(
                    "/oauth/token",
                    {
                        "refresh_token": self.refresh_token,
                        "client_id": self.client_id,
                        "client_secret": self.client_secret,
                        "redirect_uri": "urn:ietf:wg:oauth:2.0:oob",
                        "grant_type": "refresh_token",
                    },
                ).json()
                self._save_settings(response)
                g.log("Refreshed Trakt Token")
        except RanOnceAlready:
            self._load_settings()
            return

    # endregion

    # region settings
    def _save_settings(self, response):
        if "access_token" in response:
            g.set_setting("trakt.auth", response["access_token"])
            self.access_token = response["access_token"]
        if "refresh_token" in response:
            g.set_setting("trakt.refresh", response["refresh_token"])
            self.refresh_token = response["refresh_token"]
        if "expires_in" in response and "created_at" in response:
            g.set_setting("trakt.expires", str(response["created_at"] + response["expires_in"]))
            self.token_expires = float(response["created_at"] + response["expires_in"])

    def _load_settings(self):
        self.client_id = g.get_setting(
            "trakt.clientid",
            "264f8ecd14c879e372548c61545f1d27ff56fccfc043c4fa2a49346df4b6e36f",
        )
        self.client_secret = g.get_setting(
            "trakt.secret",
            "435917b748d065e26786f5f9af20d1279269eb25aa16d51f4af14ee311d0247c",
        )
        self.access_token = g.get_setting("trakt.auth")
        self.refresh_token = g.get_setting("trakt.refresh")
        self.token_expires = g.get_float_setting("trakt.expires")
        self.default_limit = g.get_int_setting("item.limit")
        self.username = g.get_setting(self.username_setting_key)

    # endregion

    @trakt_guard_response
    def get(self, url, **params):
        """
        Performs a GET request to specified endpoint and returns response
        :param url: endpoint to perform request against
        :param params: URL params for request
        :return: request response
        """
        timeout = params.pop("timeout", 10)
        self._try_add_default_paging(params)
        self._clean_params(params)
        return self.session.get(
            parse.urljoin(self.ApiUrl, url),
            params=params,
            headers=self._get_headers(),
            timeout=timeout,
        )

    def _try_add_default_paging(self, params):
        if "page" not in params and "limit" in params:
            params.update({"page": 1})
        if "page" in params and "limit" not in params:
            params.update({"limit": self.default_limit})

    @staticmethod
    def _clean_params(params):
        if "hide_watched" in params:
            del params["hide_watched"]
        if "hide_unaired" in params:
            del params["hide_unaired"]
        if "no_paging" in params:
            del params["no_paging"]
        if "pull_all" in params:
            del params["pull_all"]

    def get_json(self, url, **params):
        """
        Performs a GET request to specified endpoint, sorts results and returns JSON response
        :param url: endpoint to perform request against
        :param params: URL params for request
        :return: JSON response
        """
        response = self.get(url=url, **params)
        if response is None:
            return None
        try:
            return self._handle_response(
                self._try_sort(
                    response.headers.get("X-Sort-By"),
                    response.headers.get("X-Sort-How"),
                    response.json(),
                )
            )
        except (ValueError, AttributeError) as e:
            g.log(
                f"Failed to receive JSON from Trakt response - response: {response} - error - {e}",
                "error",
            )
            return None

    @use_cache()
    def get_cached(self, url, **params):
        """
        Performs a GET request to specified endpoint, caches and returns response
        :param url: endpoint to perform request against
        :param params: URL params for request
        :return: request response (a _CachedResponse: status, headers, json())
        """
        return _CachedResponse.from_response(self.get(url, **params))

    @handle_single_item_or_list
    def _handle_response(self, item):
        item = self._try_detect_type(item)
        item = self._try_flatten_if_single_type(item)

        if isinstance(item, list):
            return self._handle_response(item)

        if not item.get("type") or item.get("type") not in self.MetaNormalization:
            return item

        if item["type"].startswith("mixed"):
            return self._handle_mixed_type(item)

        result = self._handle_single_type(item)
        return (
            self._create_trakt_object(result)
            if result.get("type", result.get("mediatype")) in self.MetaObjects
            else result
        )

    @staticmethod
    def _create_trakt_object(item):
        result = {"trakt_object": {"info": item}}
        [result.update({key: value}) for key, value in item.items() if key.endswith("_id")]
        return result

    def _handle_single_type(self, item):
        translated = self._handle_translation(item)
        collections = {key: self._handle_response(translated[key]) for key in self.MetaCollections if key in translated}
        normalized = self._normalize_info(self.MetaNormalization[item["type"]], translated)
        normalized.update(collections)
        return normalized

    def _handle_mixed_type(self, item):
        mixed_type = item["type"].replace("mixed", "")
        result = self._handle_single_type(item)
        [
            result.update({meta: self._handle_response(item.pop(meta, {}))})
            for meta in self.MetaNormalization
            if meta in item
        ]
        single_type = self._try_detect_type(item)
        single_type = self._handle_single_type(single_type)
        result.update(single_type)
        result[mixed_type]["trakt_object"]["info"].update(single_type)
        result[mixed_type]["trakt_object"]["info"].update({"trakt_show_id": result.get("trakt_show_id")})
        return result

    @staticmethod
    def _get_all_pages(func, url, **params):
        progress_callback = params.pop("progress", None)
        response = func(url, **params)
        yield response
        if "X-Pagination-Page-Count" not in response.headers:
            return
        for i in range(2, int(response.headers["X-Pagination-Page-Count"]) + 1):
            params["page"] = i
            if "limit" not in params:
                params["limit"] = int(response.headers["X-Pagination-Limit"])
            if callable(progress_callback):
                progress_callback(  # pylint: disable=not-callable
                    (i / (int(response.headers["X-Pagination-Page-Count"]) + 1)) * 100
                )
            yield func(url, **params)

    def get_all_pages_json(self, url, **params):
        """
        Iterates of all available pages from a trakt endpoint and yields the normalised results
        :param url: endpoint to call against
        :param params: any params for the url
        :return: Yields trakt pages
        """
        ignore_cache = params.pop("ignore_cache", False)
        get_method = self.get if ignore_cache else self.get_cached

        for response in self._get_all_pages(get_method, url, **params):
            if not response:
                return
            yield self._handle_response(
                self._try_sort(
                    response.headers.get("X-Sort-By"),
                    response.headers.get("X-Sort-How"),
                    response.json(),
                )
            )

    def get_all_pages_json_complete(self, url, **params):
        """
        Like get_all_pages_json, but tells a page that could not be read from the end of the list. get_all_pages_json just stops on
        a failed page, so a caller that clears a local table first and refills it from the pages cannot tell "Trakt has nothing" from
        "the request failed".
        :param url: endpoint to call against
        :param params: any params for the url (ignore_cache as in get_all_pages_json)
        :return: list of the normalised pages when every page was read (a 200 with an empty list gives [[]]), None when any page
        failed: no answer, an error status, or a body that is not JSON. An exception from the request is not caught here.
        """
        ignore_cache = params.pop("ignore_cache", False)
        get_method = self.get if ignore_cache else self.get_cached
        pages = []
        for response in self._get_all_pages(get_method, url, **params):
            if not response:
                return None
            try:
                pages.append(
                    self._handle_response(
                        self._try_sort(
                            response.headers.get("X-Sort-By"),
                            response.headers.get("X-Sort-How"),
                            response.json(),
                        )
                    )
                )
            except (ValueError, AttributeError) as e:
                g.log(f"Failed to receive JSON from Trakt page of {url} - {e}", "error")
                return None
        return pages

    def get_page_json(self, url, **params):
        """
        Reads ONE page of a paged trakt endpoint without the cache and returns (normalised page, number of pages).
        (None, 0) when the request failed, so a caller can tell "nothing there" from "could not read it".
        :param url: endpoint to call against
        :param params: any params for the url (page and limit included)
        :return: tuple of the normalised page and the page count the endpoint reports (1 when it does not page)
        """
        response = self.get(url, **params)
        if not response:
            return None, 0
        try:
            page = self._handle_response(
                self._try_sort(
                    response.headers.get("X-Sort-By"),
                    response.headers.get("X-Sort-How"),
                    response.json(),
                )
            )
            return page, int(response.headers.get("X-Pagination-Page-Count") or 1)
        except (ValueError, AttributeError, TypeError) as e:
            g.log(f"Failed to read a page of {url} from Trakt: {e}", "warning")
            return None, 0

    @use_cache()
    def get_json_cached(self, url, **params):
        """
        Performs a get request to endpoint, caches and returns a json response from a trakt enpoint
        :param url: URL endpoint to perform request to
        :param params: url parameters
        :return: json response from Trakt
        """
        return self.get_json(url, **params)

    @trakt_guard_response
    def post(self, url, data):
        """
        Performs a post request to the specified endpoint and returns response
        :param url: URL endpoint to perform request to
        :param data: POST Data to send to endpoint
        :return: requests response
        """
        return self.session.post(
            parse.urljoin(self.ApiUrl, url), json=data, headers=self._get_headers(), timeout=10
        )

    def post_json(self, url, data):
        """
        Performs a post request to the specified endpoint and returns response
        :param url: URL endpoint to perform request to
        :param data: POST Data to send to endpoint
        :return: JSON response from trakt endpoint
        """
        return self.post(url, data).json()

    @trakt_guard_response
    def put(self, url, data):
        """
        Performs a put request to the specified endpoint and returns response
        :param url: URL endpoint to perform request to
        :param data: PUT Data to send to endpoint
        :return: requests response
        """
        return self.session.put(
            parse.urljoin(self.ApiUrl, url), json=data, headers=self._get_headers(), timeout=10
        )

    @trakt_guard_response
    def delete_request(self, url):
        """
        Performs a delete request to the specified endpoint and returns response
        :param url: URL endpoint to perform request to
        :return: requests response
        """
        return self.session.delete(parse.urljoin(self.ApiUrl, url), headers=self._get_headers(), timeout=10)

    def account_info_to_dialog(self):
        """
        Shows the signed-in Trakt account (username, time zone, join date, private/VIP flags and, when the profile
        is public, ratings/movie/show/episode stats) in a select dialog. Mirrors Account Manager's Trakt Account Info.
        A private profile returns HTTP 204 (no body) for the stats call, so the stats rows are simply left out.
        """
        title = f"{g.ADDON_NAME}: Trakt Account"
        saved_user = g.get_setting(self.username_setting_key)

        def _fetch(path):
            response = self.get(path)
            if response is None:
                return None, "no response from Trakt"
            if response.status_code != 200:
                return None, f"HTTP {response.status_code} from Trakt"
            try:
                return response.json(), None
            except ValueError:
                return None, "unreadable response from Trakt"

        def _offline(reason):
            items = [f"Username:  {saved_user}"] if saved_user else []
            items.append(f"Status:  Offline ({reason})")
            xbmcgui.Dialog().select(title, items)

        def _duration(minutes):
            days, rest = divmod(int(minutes or 0), 1440)
            hours, mins = divmod(rest, 60)
            return f"{days} days {hours:02d} hours {mins:02d} minutes"

        try:
            if not self.access_token:
                xbmcgui.Dialog().ok(g.ADDON_NAME, "Trakt: Not authorized - authorize from settings.")
                return
            settings, error = _fetch("users/settings")
            if not isinstance(settings, dict) or not isinstance(settings.get("user"), dict):
                g.log(f"Trakt account info unavailable: {error}", "warning")
                _offline(error or "unexpected response from Trakt")
                return
            user = settings["user"]
            joined = str(user.get("joined_at") or "N/A")[:19].replace("T", " ")
            vip = f"Yes ({user.get('vip_years')} years)" if user.get("vip") and user.get("vip_years") else (
                "Yes" if user.get("vip") else "No"
            )
            items = [
                f"Username:  {user.get('username') or saved_user or 'N/A'}",
                f"Timezone:  {(settings.get('account') or {}).get('timezone') or 'N/A'}",
                f"Joined:  {joined}",
                f"Private:  {'Yes' if user.get('private') else 'No'}",
                f"VIP:  {vip}",
            ]
            stats, stats_error = _fetch("users/me/stats")
            if isinstance(stats, dict):
                movies = stats.get("movies") or {}
                shows = stats.get("shows") or {}
                episodes = stats.get("episodes") or {}
                items += [
                    f"Ratings given:  {(stats.get('ratings') or {}).get('total', 0):,}",
                    f"Movies:  {movies.get('collected', 0):,} collected, {movies.get('watched', 0):,} watched "
                    f"for {_duration(movies.get('minutes'))}",
                    f"Shows:  {shows.get('collected', 0):,} collected, {shows.get('watched', 0):,} watched",
                    f"Episodes:  {episodes.get('watched', 0):,} watched for {_duration(episodes.get('minutes'))}",
                ]
            else:
                g.log(f"Trakt stats unavailable: {stats_error}", "info")
            items.append("Status:  Online")
            xbmcgui.Dialog().select(title, items)
        except Exception as e:
            g.log(f"Trakt account_info_to_dialog error: {type(e).__name__}: {e}", "error")
            _offline("Trakt unreachable")

    def get_username(self):
        """
        Fetch current signed in users username
        :return: string username
        """
        user_details = self.get_json("users/me")
        return user_details["username"]

    # region Sorting
    def _try_sort(self, sort_by, sort_how, items):
        if not items or not isinstance(items, (set, list)):
            return items

        if sort_by is None or sort_how is None:
            return items

        supported_sorts = [
            "added",
            "rank",
            "title",
            "released",
            "runtime",
            "popularity",
            "votes",
            "random",
            "runtime",
            "percentage",
            "watched",
            "collected",
            "my_rating",
        ]

        if sort_by not in supported_sorts:
            g.log(f"Error sorting trakt response: Unsupported sort_by ({sort_by})", "error")
            return items

        if sort_by == "added":
            items = sorted(items, key=lambda x: x.get("listed_at"))
        elif sort_by == "rank":
            items = sorted(items, key=lambda x: x.get("rank"))
        elif sort_by == "title":
            items = sorted(items, key=self._title_sorter)
        elif sort_by == "released":
            items = sorted(items, key=self._released_sorter)
        elif sort_by == "runtime":
            items = sorted(items, key=lambda x: x[x["type"]].get("runtime"))
        elif sort_by == "popularity":
            items = sorted(
                items,
                key=lambda x: float(x[x["type"]].get("rating", 0) * int(x[x["type"]].get("votes", 0))),
            )
        elif sort_by == "votes":
            items = sorted(items, key=lambda x: x[x["type"]].get("votes"))
        elif sort_by == "percentage":
            items = sorted(items, key=lambda x: x[x["type"]].get("rating"))
        elif sort_by == "random":
            import random

            random.shuffle(items)
        elif sort_by == "watched":
            items = self._watched_sort(items)
        elif sort_by == "collected":
            items = self._collected_sort(items)
        elif sort_by == "my_rating":
            items = self._rating_sort(items)

        if sort_how == "desc":
            items.reverse()

        return items

    @staticmethod
    def _title_sorter(item):
        return tools.SORT_TOKEN_REGEX.sub("", item[item["type"]].get("title", "").lower())

    @staticmethod
    def _released_sorter(item):
        if item_type := item.get("type"):
            return item[item_type].get("released") or item[item_type].get("first_aired") or ""
        return ""

    def __get_sorted_items(self, sort_field, item_type, items, default_sort_key):
        sort_items = self.trakt_db.fetchall(
            f"""
            SELECT trakt_id, COALESCE({sort_field}, {repr(default_sort_key)}) AS {sort_field}
            FROM {item_type}s
            WHERE trakt_id IN ({','.join(map(lambda i: str(i[item_type]['ids']['trakt']), items))})
            """
        )
        sort_items = {i['trakt_id']: i[sort_field] for i in sort_items}
        return sorted(items, key=lambda i: sort_items.get(i[item_type]["ids"]["trakt"], default_sort_key))

    def _watched_sort(self, items):
        item_type = items[0]["type"]
        return self.__get_sorted_items("last_watched_at", item_type, items, "")

    def _collected_sort(self, items):
        item_type = items[0]["type"]
        collected_field = "last_collected_at" if item_type in ["show", "season"] else "collected_at"
        return self.__get_sorted_items(collected_field, item_type, items, "")

    def _rating_sort(self, items):
        item_type = items[0]["type"]
        return self.__get_sorted_items("user_rating", item_type, items, 0)

    # endregion

    @handle_single_item_or_list
    def _try_flatten_if_single_type(self, item):
        media_type = item.get("type")
        if media_type and media_type in item:
            key = media_type
        else:
            keys = [meta for meta in self.MetaNormalization if meta in item]
            if len(keys) == 1:
                key = keys[0]
            else:
                return item

        if isinstance(item[key], dict):
            single_item = item.pop(key)
            if media_type and media_type in self.MetaNormalization:
                item = self._normalize_info(self.MetaNormalization[media_type], item)
            item.update(single_item)
            item.update({"type": key})
        elif isinstance(item[key], list):
            return item[key]
        return item

    @handle_single_item_or_list
    def _try_detect_type(self, item):
        item_types = [
            ("list", lambda x: "item_count" in x and "sort_by" in x),
            ("mixedepisode", lambda x: "show" in x and "episode" in x),
            ("mixedseason", lambda x: "show" in x and "season" in x),
            (
                "movie",
                lambda x: "title" in x and "year" in x and "network" not in x,
            ),
            ("show", lambda x: "title" in x and "year" in x and "network" in x),
            (
                "episode",
                lambda x: "number" in x
                and ("season" in x or ("last_watched_at" in x and "plays" in x) or ("collected_at" in x)),
            ),
            ("season", lambda x: "number" in x),
            ("playback", lambda x: "paused_at" in x),
            ("playbackhistory", lambda x: "action" in x),
            ("user_rating", lambda x: "rated_at" in x),
            ("calendar", lambda x: "first_aired" in x),
            ("cast", lambda x: "cast" in x),
            ("genre", lambda x: "name" in x and "slug" in x),
            ("network", lambda x: "name" in x),
            ("alias", lambda x: "title" in x and "country" in x),
            ("translation", lambda x: "title" in x and "language" in x),
            ("people", lambda x: "character" in x and "characters" in x),
            ("anticipated", lambda x: "list_count" in x),
            ("box_office", lambda x: "revenue" in x),
            ("collected", lambda x: "watcher_count" in x and "collected_count" in x and "play_count" in x),
            ("lists", lambda x: "like_count" in x and "comment_count" in x),
            ("updated", lambda x: "updated_at" in x and ("movie" in x or "show" in x)),
            ("trending", lambda x: "watchers" in x),
            ("sync_activities", lambda x: "all" in x),
            ("sync_watched", lambda x: "last_watched_at" in x),
            ("sync_collected", lambda x: "last_collected_at" in x),
            ("releases", lambda x: "country" in x and "release_date" in x),
        ]
        for item_type in item_types:
            if item_type[1](item):
                item.update({"type": item_type[0]})
                break
        if "type" not in item:
            # A single wrapped meta object (e.g. {"movie": {...}, "released": ...} from calendars/all/movies) gets its
            # type from _try_flatten_if_single_type() right after this, so it is not an unrecognised item.
            wrapped = [meta for meta in self.MetaNormalization if meta in item]
            if not (len(wrapped) == 1 and isinstance(item[wrapped[0]], dict)):
                g.log(f"Error detecting trakt item type for: {item}", "error")
        return item

    # Asian drama countries for alias inclusion (Sessions 38-47 added JP for anime;
    # Session 48 extends to all CJK/SEA countries for drama content)
    ASIAN_ALIAS_COUNTRIES = {'cn', 'kr', 'tw', 'th', 'hk', 'vn', 'ph', 'my', 'in', 'sg', 'id'}

    def search_by_tmdb_id(self, tmdb_id, media_type):
        """
        Resolves an external TMDb ID to a Trakt object via Trakt's ID lookup search.
        Does not require personal OAuth - works with just the app client_id, so it
        resolves items regardless of the user's own trakt.auth state.
        :param tmdb_id: TMDb ID of the movie or show
        :param media_type: "movie" or "show"
        :return: Normalized trakt object dict (same shape get_movie_list/get_show_list
                 expect as input), or None if Trakt has no match for this ID
        """
        results = self.get_json_cached(f"search/tmdb/{tmdb_id}", type=media_type)
        return results[0] if results else None

    def get_show_aliases(self, trakt_show_id):
        """
        Fetches aliases for a show
        :param trakt_show_id: Trakt ID of show item
        :return: list of aliases
        """
        return sorted(
            {
                i["title"]
                for i in self.get_json_cached(f"/shows/{trakt_show_id}/aliases")
                if i["country"] in {self.country, 'us', 'jp'} | self.ASIAN_ALIAS_COUNTRIES
            }
        )

    def get_show_translation(self, trakt_id):
        return self._normalize_info(
            self.TranslationNormalization,
            self.get_json_cached(f"shows/{trakt_id}/translations/{self.language}")[0],
        )

    def get_movie_translation(self, trakt_id):
        return self._normalize_info(
            self.TranslationNormalization,
            self.get_json_cached(f"movies/{trakt_id}/translations/{self.language}")[0],
        )

    @handle_single_item_or_list
    def _handle_translation(self, item):
        if "language" in item and item.get("language") == self.language:
            return item

        if "translations" in item:
            for translation in item.get("translations", []):
                self._apply_translation(item, translation)
        return item

    def _apply_translation(self, item, translation):
        if not item or not translation:
            return
        if translation.get("language") == self.language:
            [
                item.update({k: v})
                for k, v in list(translation.items())
                if v
                and str(item.get("number", 0)) not in v
                and item.get("title")
                and str(item.get("number", 0)) not in item.get("title")
            ]

    def get_movie_release_info(self, trakt_id):
        release_list = self.get_json_cached(f"movies/{trakt_id}/releases")
        return {
            country.upper(): [i for i in release_list if i['country'] == country]
            for country in {c['country'] for c in release_list}
        }
