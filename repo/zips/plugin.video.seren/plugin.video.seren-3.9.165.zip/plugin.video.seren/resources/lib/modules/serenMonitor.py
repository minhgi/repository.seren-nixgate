import time

import xbmc

from resources.lib.modules.globals import g

ONWAKE_NETWORK_UP_DELAY = 5


class SerenMonitor(xbmc.Monitor):
    def onSettingsChanged(self):
        callback_time = int(time.time())
        if g.get_int_runtime_setting("onSettingsChangedLastCalled") == callback_time:
            g.log("Debouncing onSettingsChange call", "debug")
            # This check is to debounce multiple onSettingsChange calls to the nearest second as the callbacks
            # can come a bit late after setting multiple settings programmatically and cause
            # the settings persisted flag to be cleared
            return
        g.set_runtime_setting("onSettingsChangedLastCalled", callback_time)
        g.log("SETTINGS UPDATED", "info")
        if g.SETTINGS_CACHE.get_settings_persisted_flag():
            return
        g.log("FLUSHING SETTINGS CACHE", "info")
        g.SETTINGS_CACHE.clear_cache()
        g.SETTINGS_CACHE.pre_warm_settings(g.SETTINGS_PATH)
        g.clear_cached_settings_properties()
        try:
            from resources.lib.modules.metadataHandler import MetadataHandler
            MetadataHandler.invalidate()
        except Exception:
            pass
        try:
            from resources.lib.database.trakt_sync import clear_list_cache
            clear_list_cache()
        except Exception:
            pass
        # Bump a generation counter the plugin-invoker path watches. Under
        # reuselanguageinvoker the plugin interpreter is reused across calls and never
        # runs this callback (SerenMonitor is instantiated only in service.py), so
        # g.init_globals() -> reconcile_settings_derived_caches() compares this counter
        # and flushes the same trio (cached settings props, MetadataHandler, list cache).
        g.set_runtime_setting(
            "settings_derived_cache_generation",
            g.get_int_runtime_setting("settings_derived_cache_generation", 0) + 1,
        )
        g.trigger_widget_refresh(if_playing=False, bridge=False)  # a settings change is not a change of the user's data

    def onNotification(self, sender, method, data):
        if method == "System.OnWake":
            g.log("System.OnWake notification received", "info")
            if not g.wait_for_abort(ONWAKE_NETWORK_UP_DELAY):  # Sleep for 5 seconds to make sure network is up
                if g.PLATFORM == "android":
                    g.clear_runtime_setting("system.sleeping")
                xbmc.executebuiltin('RunPlugin("plugin://plugin.video.seren/?action=runMaintenance")')
            # Stagger onto its own tick - firing this alongside runMaintenance meant two plugin
            # interpreters created in the same instant, a deadlock risk under reuselanguageinvoker.
            if not g.wait_for_abort(15):
                xbmc.executebuiltin('RunPlugin("plugin://plugin.video.seren/?action=torrentCacheCleanup")')
            if not g.wait_for_abort(15):  # Sleep to make sure tokens refreshed during maintenance
                xbmc.executebuiltin('RunPlugin("plugin://plugin.video.seren/?action=syncTraktActivities")')

        if method == "System.OnSleep":
            g.log("System.OnSleep notification received", "info")
            if g.PLATFORM == "android":
                g.set_runtime_setting("system.sleeping", True)
