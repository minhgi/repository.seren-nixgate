# Import Thread lock workaround
# noinspection PyUnresolvedReferences
import contextlib
import json
import os
import re
import time
import traceback
import unicodedata
from functools import cached_property
from urllib import parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from resources.lib.common import tools
from resources.lib.modules.settings_cache import PersistedSettingsCache
from resources.lib.modules.settings_cache import RuntimeSettingsCache

# trigger_widget_refresh() waits for Kodi's home window; give up after this many seconds
WIDGET_REFRESH_MAX_WAIT = 120

viewTypes = [
    ("Default", 50),
    ("Poster", 51),
    ("Icon Wall", 52),
    ("Shift", 53),
    ("Info Wall", 54),
    ("Wide List", 55),
    ("Wall", 500),
    ("Banner", 501),
    ("Fanart", 502),
]

colorChart = [
    "black",
    "white",
    "whitesmoke",
    "gainsboro",
    "lightgray",
    "silver",
    "darkgray",
    "gray",
    "dimgray",
    "snow",
    "floralwhite",
    "ivory",
    "beige",
    "cornsilk",
    "antiquewhite",
    "bisque",
    "blanchedalmond",
    "burlywood",
    "darkgoldenrod",
    "ghostwhite",
    "azure",
    "aliveblue",
    "lightsaltegray",
    "lightsteelblue",
    "powderblue",
    "lightblue",
    "skyblue",
    "lightskyblue",
    "deepskyblue",
    "dodgerblue",
    "royalblue",
    "blue",
    "mediumblue",
    "midnightblue",
    "navy",
    "darkblue",
    "cornflowerblue",
    "slateblue",
    "slategray",
    "yellowgreen",
    "springgreen",
    "seagreen",
    "steelblue",
    "teal",
    "fuchsia",
    "deeppink",
    "darkmagenta",
    "blueviolet",
    "darkviolet",
    "darkorchid",
    "darkslateblue",
    "darkslategray",
    "indigo",
    "cadetblue",
    "darkcyan",
    "darkturquoise",
    "turquoise",
    "cyan",
    "paleturquoise",
    "lightcyan",
    "mintcream",
    "honeydew",
    "aqua",
    "aquamarine",
    "chartreuse",
    "greenyellow",
    "palegreen",
    "lawngreen",
    "lightgreen",
    "lime",
    "mediumspringgreen",
    "mediumturquoise",
    "lightseagreen",
    "mediumaquamarine",
    "mediumseagreen",
    "limegreen",
    "darkseagreen",
    "forestgreen",
    "green",
    "darkgreen",
    "darkolivegreen",
    "olive",
    "olivedab",
    "darkkhaki",
    "khaki",
    "gold",
    "goldenrod",
    "lightyellow",
    "lightgoldenrodyellow",
    "lemonchiffon",
    "yellow",
    "seashell",
    "lavenderblush",
    "lavender",
    "lightcoral",
    "indianred",
    "darksalmon",
    "lightsalmon",
    "pink",
    "lightpink",
    "hotpink",
    "magenta",
    "plum",
    "violet",
    "orchid",
    "palevioletred",
    "mediumvioletred",
    "purple",
    "marron",
    "mediumorchid",
    "mediumpurple",
    "mediumslateblue",
    "thistle",
    "linen",
    "mistyrose",
    "palegoldenrod",
    "oldlace",
    "papayawhip",
    "moccasin",
    "navajowhite",
    "peachpuff",
    "sandybrown",
    "peru",
    "chocolate",
    "orange",
    "darkorange",
    "tomato",
    "orangered",
    "red",
    "crimson",
    "salmon",
    "coral",
    "firebrick",
    "brown",
    "darkred",
    "tan",
    "rosybrown",
    "sienna",
    "saddlebrown",
]

info_labels = {
    "genre",
    "country",
    "year",
    "episode",
    "season",
    "sortepisode",
    "sortseason",
    "episodeguide",
    "showlink",
    "top250",
    "setid",
    "tracknumber",
    "rating",
    "userrating",
    "watched",
    "playcount",
    "overlay",
    "castandrole",
    "director",
    "mpaa",
    "plot",
    "plotoutline",
    "title",
    "originaltitle",
    "sorttitle",
    "duration",
    "studio",
    "tagline",
    "writer",
    "tvshowtitle",
    "premiered",
    "status",
    "set",
    "setoverview",
    "tag",
    "imdbnumber",
    "code",
    "aired",
    "credits",
    "lastplayed",
    "album",
    "artist",
    "votes",
    "path",
    "trailer",
    "dateadded",
    "mediatype",
    "dbid",
}

info_dates = {
    "premiered",
    "aired",
    "lastplayed",
    "dateadded",
}

# ListItem.setInfo("video", ...) is deprecated in favour of the InfoTagVideo setters. setInfo stringified every
# value and parsed it with strtol/strtod/ReturnDigits, so it never raised; the helpers below keep that leniency.
_INT_PREFIX = re.compile(r"\s*[+-]?\d+")
_FLOAT_PREFIX = re.compile(r"\s*[+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?")
_VIDEO_ITEM_SEPARATOR = " / "


def _tag_str(value):
    return "" if isinstance(value, (list, tuple, set, dict)) else str(value)


def _tag_int(value):
    if isinstance(value, (int, float)):
        return int(value)
    match = _INT_PREFIX.match(_tag_str(value))
    return int(match.group()) if match else 0


def _tag_float(value):
    if isinstance(value, (int, float)):
        return float(value)
    match = _FLOAT_PREFIX.match(_tag_str(value))
    return float(match.group()) if match else 0.0


def _tag_votes(value):
    digits = "".join(c for c in _tag_str(value) if c.isdigit())
    return int(digits) if digits else 0


def _tag_list(value):
    if isinstance(value, (list, tuple, set)):
        return [str(i) for i in value if isinstance(i, (str, int, float))]
    return [i for i in _tag_str(value).split(_VIDEO_ITEM_SEPARATOR) if i]


# setInfo key -> (InfoTagVideo setter, value converter). Keys absent here (overlay, castandrole) have no setter
# and still go through setInfo.
_VIDEO_INFOTAG_SETTERS = {
    "dbid": ("setDbId", _tag_int),
    "year": ("setYear", _tag_int),
    "episode": ("setEpisode", _tag_int),
    "season": ("setSeason", _tag_int),
    "sortepisode": ("setSortEpisode", _tag_int),
    "sortseason": ("setSortSeason", _tag_int),
    "episodeguide": ("setEpisodeGuide", _tag_str),
    "showlink": ("setShowLinks", _tag_list),
    "top250": ("setTop250", _tag_int),
    "setid": ("setSetId", _tag_int),
    "tracknumber": ("setTrackNumber", _tag_int),
    "rating": ("setRating", _tag_float),
    "userrating": ("setUserRating", _tag_int),
    "watched": ("setPlaycount", _tag_int),
    "playcount": ("setPlaycount", _tag_int),
    "artist": ("setArtists", _tag_list),
    "genre": ("setGenres", _tag_list),
    "country": ("setCountries", _tag_list),
    "director": ("setDirectors", _tag_list),
    "mpaa": ("setMpaa", _tag_str),
    "plot": ("setPlot", _tag_str),
    "plotoutline": ("setPlotOutline", _tag_str),
    "title": ("setTitle", _tag_str),
    "originaltitle": ("setOriginalTitle", _tag_str),
    "sorttitle": ("setSortTitle", _tag_str),
    "duration": ("setDuration", _tag_int),
    "studio": ("setStudios", _tag_list),
    "tagline": ("setTagLine", _tag_str),
    "writer": ("setWriters", _tag_list),
    "credits": ("setWriters", _tag_list),
    "tvshowtitle": ("setTvShowTitle", _tag_str),
    "premiered": ("setPremiered", _tag_str),
    "status": ("setTvShowStatus", _tag_str),
    "set": ("setSet", _tag_str),
    "setoverview": ("setSetOverview", _tag_str),
    "tag": ("setTags", _tag_list),
    "imdbnumber": ("setIMDBNumber", _tag_str),
    "code": ("setProductionCode", _tag_str),
    "aired": ("setFirstAired", _tag_str),
    "lastplayed": ("setLastPlayed", _tag_str),
    "album": ("setAlbum", _tag_str),
    "votes": ("setVotes", _tag_votes),
    "trailer": ("setTrailer", _tag_str),
    "path": ("setPath", _tag_str),
    "filenameandpath": ("setFilenameAndPath", _tag_str),
    "dateadded": ("setDateAdded", _tag_str),
    "mediatype": ("setMediaType", _tag_str),
}

listitem_properties = [
    (("awards",), "Awards"),
    (("oscar_wins",), "Oscar_Wins"),
    (("oscar_nominations",), "Oscar_Nominations"),
    (("award_wins",), "Award_Wins"),
    (("award_nominations",), "Award_Nominations"),
    (("metacritic_rating",), "Metacritic_Rating"),
    (("rating.tmdb", "rating"), "TMDb_Rating"),
    (("rating.tmdb", "votes"), "TMDb_Votes"),
    (("rating.tvdb", "rating"), "Tvdb_Rating"),
    (("rating.tvdb", "votes"), "Tvdb_Votes"),
    (("rating.imdb", "rating"), "IMDb_Rating"),
    (("rating.imdb", "votes"), "IMDb_Votes"),
    (("rating.trakt", "rating"), "Trakt_Rating"),
    (("rating.trakt", "votes"), "Trakt_Votes"),
    (("rottentomatoes_rating",), "RottenTomatoes_Rating"),
    (("rottentomatoes_image",), "RottenTomatoes_Image"),
    (("rottentomatoes_reviewstotal",), "RottenTomatoes_ReviewsTotal"),
    (("rottentomatoes_reviewsfresh",), "RottenTomatoes_ReviewsFresh"),
    (("rottentomatoes_reviewsrotten",), "RottenTomatoes_ReviewsRotten"),
    (("rottentomatoes_consensus",), "RottenTomatoes_Consensus"),
    (("rottentomatoes_usermeter",), "RottenTomatoes_UserMeter"),
    (("rottentomatoes_userreviews",), "RottenTomatoes_UserReviews"),
]


_SKIN_COLOR_LOOKUP = {
    "skin.arctic.horizon": "ff0385b5",
    "skin.arctic.horizon.2": "ff0385b5",
    "skin.arctic.zephyr": "ff0385b5",
    "skin.arctic.zephyr.2": "ff0385b5",
    "skin.aura": "ff0385b5",
    "skin.auramod": "deepskyblue",
    "skin.confluence": "ffeb9e17",
    "skin.eminence": {
        "default": "ff33b5e5",
        "crimson": "ffdc143c",
        "emerald": "ffdc143c",
        "lilac": "ffa682a6",
        "lime": "ffb5e533",
        "magenta": "ffe533b5",
        "orange": "ffd76c38",
    },
    "skin.eminence.2": "ff287ba8",
    "skin.estouchy": "ff11e7b1",
    "skin.estuary": {
        "default": "ff11e7b1",
        "brown": "ffff4400",
        "charcoal": "ff11e7b1",
        "chartreuse": "ff24c6c9",
        "concrete": "ffff8c00",
        "gold": "fffff000",
        "green": "ff14d519",
        "maroon": "ff24c6c9",
        "midnight": "ff5be5ee",
        "orange": "fffff100",
        "pink": "ff94d800",
        "rose": "ffff0261",
        "teal": "ffc67f03",
        "violet": "ffff0054",
    },
    "skin.fuse.neue": "ffe53564",
}


class GlobalVariables:
    CONTENT_MENU = ""
    CONTENT_FILES = "files"
    CONTENT_MOVIE = "movies"
    CONTENT_SHOW = "tvshows"
    CONTENT_SEASON = "seasons"
    CONTENT_EPISODE = "episodes"
    CONTENT_GENRES = "genres"
    CONTENT_YEARS = "years"
    MEDIA_MENU = ""
    MEDIA_FOLDER = "file"
    MEDIA_MOVIE = "movie"
    MEDIA_SHOW = "tvshow"
    MEDIA_SEASON = "season"
    MEDIA_EPISODE = "episode"

    SEMVER_REGEX = re.compile(r"^((?:\d+\.){2}\d+)")
    _SERVICE_STATE_KEY = "seren.service_state"
    _ID_KEYS = {"tmdb_id": "tmdb", "imdb_id": "imdb", "tvdb_id": "tvdb"}
    _EPISODE_SEASON_TYPES = frozenset({"episode", "season"})

    # cached_property names that depend on settings and must be cleared when settings change
    # (with reuselanguageinvoker, these persist across plugin calls)
    _CACHED_SETTING_PROPS = (
        "_debrid_available", "_premiumize_enabled", "_real_debrid_enabled",
        "_all_debrid_enabled", "_torbox_enabled", "_debridlink_enabled", "_offcloud_enabled",
        "menu_caching_enabled", "set_views_enabled", "disable_notification_sound",
        "fanart_fallback_disabled", "studio_limit", "_local_is_utc",
    )

    def __init__(self):
        self.IS_ADDON_FIRSTRUN = None
        self.ADDON = None
        self.ADDON_DATA_PATH = None
        self.ADDON_ID = None
        self.ADDON_NAME = None
        self.VERSION = None
        self.CLEAN_VERSION = None
        self.USER_AGENT = None
        self.DEFAULT_FANART = None
        self.DEFAULT_ICON = None
        self.DEFAULT_LOGO = None
        self.DEFAULT_POSTER = None
        self.NEXT_PAGE_ICON = None
        self.ADDON_USERDATA_PATH = None
        self.SETTINGS_CACHE = None
        self.RUNTIME_SETTINGS_CACHE = None
        self.LANGUAGE_CACHE = {}
        self.PLAYLIST = None
        self.HOME_WINDOW = None
        self.KODI_DATE_LONG_FORMAT = None
        self.KODI_DATE_SHORT_FORMAT = None
        self.KODI_TIME_FORMAT = None
        self.KODI_TIME_NO_SECONDS_FORMAT = None
        self.KODI_FULL_VERSION = None
        self.KODI_VERSION = None
        self.PLATFORM = None
        self.UTC_TIMEZONE = None
        self.LOCAL_TIMEZONE = None
        self.URL = None
        self.PLUGIN_HANDLE = 0
        self.IS_SERVICE = True
        self.BASE_URL = None
        self.PATH = None
        self.PARAM_STRING = None
        self.REQUEST_PARAMS = None
        self.FROM_WIDGET = False
        self.PAGE = 1
        # Last-seen value of the 'settings_derived_cache_generation' runtime counter
        # (bumped by SerenMonitor.onSettingsChanged). See reconcile_settings_derived_caches().
        self._settings_derived_cache_generation_seen = None

    def __del__(self):
        self.deinit()

    def deinit(self):
        self.ADDON = None
        del self.ADDON
        self.PLAYLIST = None
        del self.PLAYLIST
        self.HOME_WINDOW = None
        del self.HOME_WINDOW
        # Release the singleton Monitor so Kodi's Python invoker can clean up.
        # Without this, xbmc.Monitor objects accumulate across plugin calls
        # and Kodi warns "has left several classes in memory".
        GlobalVariables._MONITOR = None

    def clear_cached_settings_properties(self):
        """Clear all cached_property values that depend on settings.

        Must be called when settings change (onSettingsChanged) so that
        with reuselanguageinvoker enabled, stale cached values are discarded.
        Next access recalculates from the fresh settings cache.
        """
        for prop in self._CACHED_SETTING_PROPS:
            self.__dict__.pop(prop, None)

    def reconcile_settings_derived_caches(self):
        """Mirror SerenMonitor.onSettingsChanged()'s cache flush on the plugin-invoker path.

        SerenMonitor is instantiated only in service.py, so under reuselanguageinvoker
        (the plugin interpreter is reused across calls) a Kodi-GUI settings change never
        invalidates g's settings-derived cached_property values, the MetadataHandler
        singleton, or the trakt_sync L1 list cache on the plugin side until Kodi restarts.
        onSettingsChanged() bumps the 'settings_derived_cache_generation' runtime counter;
        this compares it and flushes the same trio when it moves. No-op when nothing
        changed, and when reuselanguageinvoker is off (fresh interpreter, cold caches).
        """
        try:
            generation = self.get_int_runtime_setting("settings_derived_cache_generation", 0)
        except Exception:
            return
        if self._settings_derived_cache_generation_seen is None:
            self._settings_derived_cache_generation_seen = generation
            return
        if generation == self._settings_derived_cache_generation_seen:
            return
        self.log(
            f"RLI settings-derived cache reconcile: generation "
            f"{self._settings_derived_cache_generation_seen} -> {generation}, flushing",
            "debug",
        )
        self._settings_derived_cache_generation_seen = generation
        self.clear_cached_settings_properties()
        try:
            from resources.lib.modules.metadataHandler import MetadataHandler

            MetadataHandler.invalidate()
        except Exception:
            pass
        try:
            from resources.lib.database.trakt_sync import clear_list_cache

            clear_list_cache()
        except Exception:
            pass

    def init_globals(self, argv=None, addon_id=None):
        self.IS_ADDON_FIRSTRUN = self.IS_ADDON_FIRSTRUN is None
        self.ADDON = xbmcaddon.Addon()

        # Lazy-load pytz only when needed (first call per session)
        if self.UTC_TIMEZONE is None:
            from resources.lib.third_party import pytz
            self.UTC_TIMEZONE = pytz.utc

        if self._load_service_state():
            # Fast path: immutable state loaded from window properties set by service.py
            self.PLAYLIST = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            self.HOME_WINDOW = xbmcgui.Window(10000)
            self._init_settings_cache()
        else:
            # Full init: service hasn't stored state yet (first boot or service restart)
            self.ADDON_ID = addon_id or self.ADDON.getAddonInfo("id")
            self.ADDON_NAME = self.ADDON.getAddonInfo("name")
            self.VERSION = self.ADDON.getAddonInfo("version")
            self.CLEAN_VERSION = self.SEMVER_REGEX.findall(self.VERSION)[0]
            self.USER_AGENT = f"{self.ADDON_NAME} - {self.CLEAN_VERSION}"
            self.PLATFORM = self._get_system_platform()
            self._init_kodi()
            self._init_settings_cache()
            self._init_local_timezone()
            self._init_paths()
            self.DEFAULT_FANART = self.ADDON.getAddonInfo("fanart")
            self.DEFAULT_ICON = self.ADDON.getAddonInfo("icon")
            self.DEFAULT_LOGO = f"{self.IMAGES_PATH}logo-seren-3.png"
            self.DEFAULT_POSTER = f"{self.IMAGES_PATH}poster-seren-3.png"
            self.NEXT_PAGE_ICON = f"{self.IMAGES_PATH}next.png"

        self.init_request(argv)
        self._init_cache()
        self.reconcile_settings_derived_caches()

    def _store_service_state(self):
        """
        Store all immutable state as a single JSON blob in a window property.
        Called once from service.py after full init_globals().
        Plugin-side init_globals() reads this back via _load_service_state().
        """
        state = {
            "ADDON_ID": self.ADDON_ID,
            "ADDON_NAME": self.ADDON_NAME,
            "VERSION": self.VERSION,
            "CLEAN_VERSION": self.CLEAN_VERSION,
            "USER_AGENT": self.USER_AGENT,
            "PLATFORM": self.PLATFORM,
            "KODI_DATE_LONG_FORMAT": self.KODI_DATE_LONG_FORMAT,
            "KODI_DATE_SHORT_FORMAT": self.KODI_DATE_SHORT_FORMAT,
            "KODI_TIME_FORMAT": self.KODI_TIME_FORMAT,
            "KODI_TIME_NO_SECONDS_FORMAT": self.KODI_TIME_NO_SECONDS_FORMAT,
            "KODI_FULL_VERSION": self.KODI_FULL_VERSION,
            "KODI_VERSION": self.KODI_VERSION,
            "LOCAL_TIMEZONE_ZONE": self.LOCAL_TIMEZONE.zone if self.LOCAL_TIMEZONE else "UTC",
            "ADDONS_PATH": self.ADDONS_PATH,
            "ADDON_PATH": self.ADDON_PATH,
            "ADDON_DATA_PATH": self.ADDON_DATA_PATH,
            "ADDON_USERDATA_PATH": self.ADDON_USERDATA_PATH,
            "SETTINGS_PATH": self.SETTINGS_PATH,
            "ADVANCED_SETTINGS_PATH": self.ADVANCED_SETTINGS_PATH,
            "KODI_DATABASE_PATH": self.KODI_DATABASE_PATH,
            "GUI_PATH": self.GUI_PATH,
            "IMAGES_PATH": self.IMAGES_PATH,
            "ICONS_PATH": self.ICONS_PATH,
            "GENRES_PATH": self.GENRES_PATH,
            "SKINS_PATH": self.SKINS_PATH,
            "CACHE_DB_PATH": self.CACHE_DB_PATH,
            "TORRENT_CACHE": self.TORRENT_CACHE,
            "TORRENT_ASSIST": self.TORRENT_ASSIST,
            "PROVIDER_CACHE_DB_PATH": self.PROVIDER_CACHE_DB_PATH,
            "PREMIUMIZE_DB_PATH": self.PREMIUMIZE_DB_PATH,
            "DEBRID_CACHE_DB_PATH": self.DEBRID_CACHE_DB_PATH,
            "PROVIDER_PERF_DB_PATH": self.PROVIDER_PERF_DB_PATH,
            "TV_SCHEDULE_DB_PATH": self.TV_SCHEDULE_DB_PATH,
            "MOVIE_CALENDAR_DB_PATH": self.MOVIE_CALENDAR_DB_PATH,
            "UNDESIRABLES_DB_PATH": self.UNDESIRABLES_DB_PATH,
            "TITLE_SUBS_DB_PATH": self.TITLE_SUBS_DB_PATH,
            "TRAKT_SYNC_DB_PATH": self.TRAKT_SYNC_DB_PATH,
            "MDBLIST_SYNC_DB_PATH": self.MDBLIST_SYNC_DB_PATH,
            "SIMKL_SYNC_DB_PATH": self.SIMKL_SYNC_DB_PATH,
            "BRIDGE_SYNC_DB_PATH": self.BRIDGE_SYNC_DB_PATH,
            "SEARCH_HISTORY_DB_PATH": self.SEARCH_HISTORY_DB_PATH,
            "SKINS_DB_PATH": self.SKINS_DB_PATH,
            "ANIME_CACHE_DB_PATH": self.ANIME_CACHE_DB_PATH,
            "DEFAULT_FANART": self.DEFAULT_FANART,
            "DEFAULT_ICON": self.DEFAULT_ICON,
            "DEFAULT_LOGO": self.DEFAULT_LOGO,
            "DEFAULT_POSTER": self.DEFAULT_POSTER,
            "NEXT_PAGE_ICON": self.NEXT_PAGE_ICON,
        }
        self.HOME_WINDOW.setProperty(self._SERVICE_STATE_KEY, json.dumps(state))

    def _load_service_state(self):
        """
        Load immutable state from window property set by service.py.
        Returns True if state was loaded (fast path), False if not available (full init needed).
        """
        try:
            window = xbmcgui.Window(10000)
            state_json = window.getProperty(self._SERVICE_STATE_KEY)
            if not state_json:
                return False

            state = json.loads(state_json)

            # Version check: if the cached version doesn't match the actual addon version,
            # reject the cached state so do_version_change() detects the upgrade.
            # This prevents stale state from a previous version persisting after a zip install.
            actual_version = self.ADDON.getAddonInfo("version")
            if state.get("VERSION") != actual_version:
                window.clearProperty(self._SERVICE_STATE_KEY)
                return False

            # Addon info
            self.ADDON_ID = state["ADDON_ID"]
            self.ADDON_NAME = state["ADDON_NAME"]
            self.VERSION = state["VERSION"]
            self.CLEAN_VERSION = state["CLEAN_VERSION"]
            self.USER_AGENT = state["USER_AGENT"]
            self.PLATFORM = state["PLATFORM"]

            # Kodi info
            self.KODI_DATE_LONG_FORMAT = state["KODI_DATE_LONG_FORMAT"]
            self.KODI_DATE_SHORT_FORMAT = state["KODI_DATE_SHORT_FORMAT"]
            self.KODI_TIME_FORMAT = state["KODI_TIME_FORMAT"]
            self.KODI_TIME_NO_SECONDS_FORMAT = state["KODI_TIME_NO_SECONDS_FORMAT"]
            self.KODI_FULL_VERSION = state["KODI_FULL_VERSION"]
            self.KODI_VERSION = int(state["KODI_VERSION"])

            # Timezone
            tz_zone = state.get("LOCAL_TIMEZONE_ZONE", "UTC")
            try:
                from resources.lib.third_party import pytz
                self.LOCAL_TIMEZONE = pytz.timezone(tz_zone)
            except Exception:
                self.LOCAL_TIMEZONE = self.UTC_TIMEZONE

            # Paths
            self.ADDONS_PATH = state["ADDONS_PATH"]
            self.ADDON_PATH = state["ADDON_PATH"]
            self.ADDON_DATA_PATH = state["ADDON_DATA_PATH"]
            self.ADDON_USERDATA_PATH = state["ADDON_USERDATA_PATH"]
            self.SETTINGS_PATH = state["SETTINGS_PATH"]
            self.ADVANCED_SETTINGS_PATH = state["ADVANCED_SETTINGS_PATH"]
            self.KODI_DATABASE_PATH = state["KODI_DATABASE_PATH"]
            self.GUI_PATH = state["GUI_PATH"]
            self.IMAGES_PATH = state["IMAGES_PATH"]
            self.ICONS_PATH = state["ICONS_PATH"]
            self.GENRES_PATH = state["GENRES_PATH"]
            self.SKINS_PATH = state["SKINS_PATH"]
            self.CACHE_DB_PATH = state["CACHE_DB_PATH"]
            self.TORRENT_CACHE = state["TORRENT_CACHE"]
            self.TORRENT_ASSIST = state["TORRENT_ASSIST"]
            self.PROVIDER_CACHE_DB_PATH = state["PROVIDER_CACHE_DB_PATH"]
            self.PREMIUMIZE_DB_PATH = state["PREMIUMIZE_DB_PATH"]
            self.DEBRID_CACHE_DB_PATH = state["DEBRID_CACHE_DB_PATH"]
            self.PROVIDER_PERF_DB_PATH = state["PROVIDER_PERF_DB_PATH"]
            self.TV_SCHEDULE_DB_PATH = state["TV_SCHEDULE_DB_PATH"]
            self.MOVIE_CALENDAR_DB_PATH = state["MOVIE_CALENDAR_DB_PATH"]
            self.UNDESIRABLES_DB_PATH = state["UNDESIRABLES_DB_PATH"]
            self.TITLE_SUBS_DB_PATH = state["TITLE_SUBS_DB_PATH"]
            self.TRAKT_SYNC_DB_PATH = state["TRAKT_SYNC_DB_PATH"]
            self.MDBLIST_SYNC_DB_PATH = state["MDBLIST_SYNC_DB_PATH"]
            self.SIMKL_SYNC_DB_PATH = state["SIMKL_SYNC_DB_PATH"]
            self.BRIDGE_SYNC_DB_PATH = state["BRIDGE_SYNC_DB_PATH"]
            self.SEARCH_HISTORY_DB_PATH = state["SEARCH_HISTORY_DB_PATH"]
            self.SKINS_DB_PATH = state["SKINS_DB_PATH"]
            self.ANIME_CACHE_DB_PATH = state["ANIME_CACHE_DB_PATH"]

            # Assets
            self.DEFAULT_FANART = state["DEFAULT_FANART"]
            self.DEFAULT_ICON = state["DEFAULT_ICON"]
            self.DEFAULT_LOGO = state["DEFAULT_LOGO"]
            self.DEFAULT_POSTER = state["DEFAULT_POSTER"]
            self.NEXT_PAGE_ICON = state["NEXT_PAGE_ICON"]

            return True
        except (KeyError, ValueError, TypeError):
            return False

    def _init_kodi(self):
        self.PLAYLIST = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        self.HOME_WINDOW = xbmcgui.Window(10000)
        self.KODI_DATE_LONG_FORMAT = xbmc.getRegion("datelong")
        self.KODI_DATE_SHORT_FORMAT = xbmc.getRegion("dateshort")
        self.KODI_TIME_FORMAT = xbmc.getRegion("time")
        self.KODI_TIME_NO_SECONDS_FORMAT = self.KODI_TIME_FORMAT.replace(":%S", "")
        self.KODI_FULL_VERSION = xbmc.getInfoLabel("System.BuildVersion")
        if version := re.findall(r'(?:(?:((?:\d+\.?){1,3}\S+))?\s+\(((?:\d+\.?){2,3})\))', self.KODI_FULL_VERSION):
            self.KODI_FULL_VERSION = version[0][1]
            if len(version[0][0]) > 1:
                pre_ver = version[0][0][:2]
                full_ver = version[0][1][:2]
                if pre_ver > full_ver:
                    self.KODI_VERSION = int(pre_ver[:2])
                else:
                    self.KODI_VERSION = int(full_ver[:2])
            else:
                self.KODI_VERSION = int(version[0][1][:2])
        else:
            self.KODI_FULL_VERSION = self.KODI_FULL_VERSION.split(' ')[0]
            self.KODI_VERSION = int(self.KODI_FULL_VERSION[:2])

    def _init_settings_cache(self):
        self.RUNTIME_SETTINGS_CACHE = RuntimeSettingsCache()
        self.SETTINGS_CACHE = PersistedSettingsCache()

    def _init_local_timezone(self):
        from resources.lib.third_party import pytz
        try:
            timezone_string = self.get_setting("general.localtimezone")
            if timezone_string:
                self.LOCAL_TIMEZONE = pytz.timezone(timezone_string)
        except pytz.UnknownTimeZoneError:
            self.log(f"Invalid local timezone '{timezone_string}' in settings.xml", "debug")
        except Exception as e:
            self.log(f"Error using local timezone '{timezone_string}' in settings.xml: {e}", "warning")
        finally:
            if not self.LOCAL_TIMEZONE or self.LOCAL_TIMEZONE == self.UTC_TIMEZONE:
                self.init_local_timezone()

    def init_local_timezone(self):
        """
        Attempts to detect the local timezone via a variety of approaches
        Initializes LOCAL_TIMEZONE to correct tzinfo value
        If this fails we should just use UTC as lack of any LOCAL_TIMEZONE will cause many failures
        :return: None
        """
        from resources.lib.third_party import pytz
        timezone_string = None
        try:
            try:
                response = self.json_rpc("Settings.GetSettingValue", {"setting": "locale.timezone"})
                timezone_string = response.get("value", '')

                self.LOCAL_TIMEZONE = pytz.timezone(timezone_string)
            except pytz.UnknownTimeZoneError:
                if timezone_string:
                    self.log(
                        f"Kodi provided an invalid local timezone '{timezone_string}', trying a different approach",
                        "warning",
                    )
                else:
                    self.log(
                        "Kodi does not support locale.timezone JSON RPC call on your platform, trying a different "
                        "approach",
                        "debug",
                    )
            except Exception as e:
                self.log(f"Error detecting local timezone with Kodi, trying a different approach: {e}", "warning")
            # If Kodi detection failed, fall back on tzlocal
            try:
                if not self.LOCAL_TIMEZONE or self.LOCAL_TIMEZONE == self.UTC_TIMEZONE:
                    from resources.lib.third_party import tzlocal

                    self.LOCAL_TIMEZONE = tzlocal.get_localzone()
            except Exception as e:
                self.log(f"Error detecting local timezone with alternative approach: {e}", "warning")
            # If we still don't have a timezone, try manual setting
            try:
                if not self.LOCAL_TIMEZONE or self.LOCAL_TIMEZONE == self.UTC_TIMEZONE:
                    g.set_setting("general.manualtimezone", True)
                    timezone_string = self.get_setting("general.localtimezone")
                    if timezone_string:
                        self.LOCAL_TIMEZONE = pytz.timezone(timezone_string)
                else:
                    g.set_setting("general.manualtimezone", False)
            except pytz.UnknownTimeZoneError:
                self.log(f"Invalid local timezone '{timezone_string}' in settings.xml", "debug")
            except Exception as e:
                self.log(f"Error using local timezone '{timezone_string}' in settings.xml: {e}", "warning")
        finally:
            # If Kodi and tzocal detection fails and we don't have a valid manual setting, fallback to UTC
            if not self.LOCAL_TIMEZONE:
                self.LOCAL_TIMEZONE = self.UTC_TIMEZONE
            if self.LOCAL_TIMEZONE == self.UTC_TIMEZONE:
                self.log(
                    "Unable to detect local timezone, defaulting to UTC for displayed dates/times. "
                    "Note that this does not affect filtering or sorting, only display",
                    "debug",
                )
            self.set_setting("general.localtimezone", self.LOCAL_TIMEZONE.zone)

    @staticmethod
    def _get_system_platform():
        """
        get platform on which xbmc run
        """
        platform = "unknown"
        if xbmc.getCondVisibility("system.platform.android"):
            platform = "android"
        elif xbmc.getCondVisibility("system.platform.linux"):
            platform = "linux"
        elif xbmc.getCondVisibility("system.platform.xbox"):
            platform = "xbox"
        elif xbmc.getCondVisibility("system.platform.windows"):
            platform = "xbox" if "Users\\UserMgr" in os.environ.get("TMP") else "windows"
        elif xbmc.getCondVisibility("system.platform.osx"):
            platform = "osx"

        return platform

    def _init_cache(self):
        from resources.lib.database.cache import Cache

        self.CACHE = Cache()

    def init_request(self, argv):
        if argv is None:
            return

        self.URL = parse.urlparse(argv[0])
        try:
            self.PLUGIN_HANDLE = int(argv[1])
            self.IS_SERVICE = False
        except IndexError:
            self.PLUGIN_HANDLE = 0
            self.IS_SERVICE = True

        self.BASE_URL = f"{self.URL[0]}://{self.URL[1]}" if self.URL[1] != "" else ""
        self.PATH = parse.unquote(self.URL[2])
        try:
            self.PARAM_STRING = argv[2].lstrip('?/')
        except IndexError:
            self.PARAM_STRING = ""
        self.REQUEST_PARAMS = self.legacy_params_converter(dict(parse.parse_qsl(self.PARAM_STRING)))
        if "action_args" in self.REQUEST_PARAMS:
            self.REQUEST_PARAMS["action_args"] = tools.deconstruct_action_args(self.REQUEST_PARAMS["action_args"])
            if isinstance(self.REQUEST_PARAMS["action_args"], dict):
                self.REQUEST_PARAMS["action_args"] = self.legacy_action_args_converter(
                    self.REQUEST_PARAMS["action_args"]
                )
        self.FROM_WIDGET = not self.is_addon_visible()
        self.PAGE = int(g.REQUEST_PARAMS.get("page", 1))

    @staticmethod
    def legacy_action_args_converter(action_args):
        if "item_type" not in action_args:
            return action_args

        if not action_args.get("trakt_id"):
            g.log("legacy_action_args_converter: trakt_id is missing or None, cannot resolve", "warning")
            action_args["mediatype"] = action_args.pop("item_type")
            return action_args

        if "season" in action_args["item_type"]:
            from resources.lib.database.trakt_sync import shows

            resolved = shows.TraktSyncDatabase().get_season_action_args(action_args["trakt_id"], action_args["season"])
            if not resolved:
                return g._unresolvable_action_args(action_args, f"season {action_args.get('season')}")
            action_args.update(resolved)

        if "episode" in action_args["item_type"]:
            from resources.lib.database.trakt_sync import shows

            # Resolving the episode makes the sync database mill the show, which waits for a background sync that is
            # milling the same show (a play once sat 22 s here before any window). For an interactive play of an
            # episode that is already stored locally, cap that wait so playback goes ahead with the stored data.
            wait_cap = None
            if g.REQUEST_PARAMS.get("action") == "getSources":
                try:
                    from resources.lib.modules.sync_lock import SYNC_WAIT_CAP_SECONDS, BoundedSyncWait

                    if shows.TraktSyncDatabase().fetchone(
                        "SELECT 1 FROM episodes WHERE trakt_show_id = "
                        f"{int(action_args['trakt_id'])} AND season = {int(action_args['season'])} "
                        f"AND number = {int(action_args['episode'])}"
                    ):
                        wait_cap = BoundedSyncWait(SYNC_WAIT_CAP_SECONDS)
                except Exception as e:
                    g.log(f"Bounded sync wait unavailable for episode resolve: {e}", "warning")
            with wait_cap or contextlib.nullcontext():
                resolved = shows.TraktSyncDatabase().get_episode_action_args(
                    action_args["trakt_id"],
                    action_args["season"],
                    action_args["episode"],
                )
            if not resolved:
                return g._unresolvable_action_args(
                    action_args, f"season {action_args.get('season')} episode {action_args.get('episode')}"
                )
            action_args.update(resolved)

        if "show" in action_args["item_type"]:
            action_args["item_type"] = "shows"

        action_args["mediatype"] = action_args.pop("item_type")
        return action_args

    @staticmethod
    def _unresolvable_action_args(action_args, what):
        """The season or episode asked for is not in Trakt's data for this show (Trakt can number a long-running or split show
        differently from TMDb, e.g. One Piece season 21 is episodes 892-1088 there). Before this the failed lookup returned
        None into dict.update() and the whole script died with Kodi's generic 'Python callback returned an error' and nothing
        shown. Same shape as the 'trakt_id is missing' branch above: mediatype is set and the trakt_id is dropped, so the play
        request ends in getSources' 'Unable to identify item' path (clean cancel + a message) and everything else sees an
        item it cannot resolve. The show id is logged before it is dropped."""
        g.log(
            f"legacy_action_args_converter: {what} of Trakt show {action_args.get('trakt_id')} (TMDb "
            f"{action_args.get('tmdb_id')}) is not in the Trakt data, cannot resolve",
            "warning",
        )
        action_args["mediatype"] = action_args.pop("item_type")
        action_args.pop("trakt_id", None)
        return action_args

    @staticmethod
    def legacy_params_converter(params):
        if "actionArgs" in params:
            params["action_args"] = params.pop("actionArgs")
        if "action" in params:
            if params["action"] == "moviesTrending":
                params["action"] = "genericEndpoint"
                params["endpoint"] = "trending"
                params["mediatype"] = "movies"
            if params["action"] == "moviesPopular":
                params["action"] = "genericEndpoint"
                params["endpoint"] = "popular"
                params["mediatype"] = "movies"
            if params["action"] == "moviesWatched":
                params["action"] = "genericEndpoint"
                params["endpoint"] = "watched"
                params["mediatype"] = "movies"
            if params["action"] == "moviesCollected":
                params["action"] = "genericEndpoint"
                params["endpoint"] = "collected"
                params["mediatype"] = "movies"
            if params["action"] == "moviesAnticipated":
                params["action"] = "genericEndpoint"
                params["endpoint"] = "anticipated"
                params["mediatype"] = "movies"
            if params["action"] == "moviesBoxOffice":
                params["action"] = "genericEndpoint"
                params["endpoint"] = "boxoffice"
                params["mediatype"] = "movies"
            if params["action"] == "showsTrending":
                params["action"] = "genericEndpoint"
                params["endpoint"] = "trending"
                params["mediatype"] = "shows"
            if params["action"] == "showsPopular":
                params["action"] = "genericEndpoint"
                params["endpoint"] = "popular"
                params["mediatype"] = "shows"
            if params["action"] == "showsWatched":
                params["action"] = "genericEndpoint"
                params["endpoint"] = "watched"
                params["mediatype"] = "shows"
            if params["action"] == "showsCollected":
                params["action"] = "genericEndpoint"
                params["endpoint"] = "collected"
                params["mediatype"] = "shows"
            if params["action"] == "showsAnticipated":
                params["action"] = "genericEndpoint"
                params["endpoint"] = "anticipated"
                params["mediatype"] = "shows"
            if params["action"] == "showsBoxOffice":
                params["action"] = "genericEndpoint"
                params["endpoint"] = "boxoffice"
                params["mediatype"] = "shows"
        return params

    def _init_paths(self):
        self.ADDONS_PATH = tools.translate_path(os.path.join("special://home/", "addons/"))
        self.ADDON_PATH = tools.translate_path(os.path.join("special://home/", f"addons/{self.ADDON_ID.lower()}"))
        self.ADDON_DATA_PATH = tools.translate_path(self.ADDON.getAddonInfo("path"))  # Addon folder
        self.ADDON_USERDATA_PATH = tools.translate_path(
            f"special://profile/addon_data/{self.ADDON_ID}/"
        )  # Addon user data folder
        self.SETTINGS_PATH = tools.translate_path(os.path.join(self.ADDON_USERDATA_PATH, "settings.xml"))
        self.ADVANCED_SETTINGS_PATH = tools.translate_path("special://profile/advancedsettings.xml")
        self.KODI_DATABASE_PATH = tools.translate_path("special://database/")
        self.GUI_PATH = tools.translate_path(os.path.join(self.ADDON_DATA_PATH, "resources", "lib", "gui"))
        self.IMAGES_PATH = f"{self.ADDON.getAddonInfo('path')}/resources/images/"
        self.ICONS_PATH = f"{self.IMAGES_PATH}icons/"
        self.GENRES_PATH = f"{self.IMAGES_PATH}genres/"
        self.SKINS_PATH = tools.translate_path(os.path.join(self.ADDON_USERDATA_PATH, "skins"))
        self.CACHE_DB_PATH = tools.translate_path(os.path.join(self.ADDON_USERDATA_PATH, "cache.db"))
        self.TORRENT_CACHE = tools.translate_path(os.path.join(self.ADDON_USERDATA_PATH, "torrentCache.db"))
        self.TORRENT_ASSIST = tools.translate_path(os.path.join(self.ADDON_USERDATA_PATH, "torentAssist.db"))
        self.PROVIDER_CACHE_DB_PATH = tools.translate_path(os.path.join(self.ADDON_USERDATA_PATH, "providers.db"))
        self.PREMIUMIZE_DB_PATH = tools.translate_path(os.path.join(self.ADDON_USERDATA_PATH, "premiumize.db"))
        self.DEBRID_CACHE_DB_PATH = tools.translate_path(os.path.join(self.ADDON_USERDATA_PATH, "debridCache.db"))
        self.PROVIDER_PERF_DB_PATH = tools.translate_path(os.path.join(self.ADDON_USERDATA_PATH, "providerPerf.db"))
        self.TV_SCHEDULE_DB_PATH = tools.translate_path(os.path.join(self.ADDON_USERDATA_PATH, "tvSchedule.db"))
        self.MOVIE_CALENDAR_DB_PATH = tools.translate_path(os.path.join(self.ADDON_USERDATA_PATH, "movieCalendar.db"))
        self.UNDESIRABLES_DB_PATH = tools.translate_path(os.path.join(self.ADDON_USERDATA_PATH, "undesirables.db"))
        self.TITLE_SUBS_DB_PATH = tools.translate_path(os.path.join(self.ADDON_USERDATA_PATH, "titleSubs.db"))
        self.TRAKT_SYNC_DB_PATH = tools.translate_path(os.path.join(self.ADDON_USERDATA_PATH, "traktSync.db"))
        self.MDBLIST_SYNC_DB_PATH = tools.translate_path(os.path.join(self.ADDON_USERDATA_PATH, "mdblistSync.db"))
        self.SIMKL_SYNC_DB_PATH = tools.translate_path(os.path.join(self.ADDON_USERDATA_PATH, "simklSync.db"))
        self.BRIDGE_SYNC_DB_PATH = tools.translate_path(os.path.join(self.ADDON_USERDATA_PATH, "bridgeSync.db"))
        self.SEARCH_HISTORY_DB_PATH = tools.translate_path(os.path.join(self.ADDON_USERDATA_PATH, "search.db"))
        self.SKINS_DB_PATH = tools.translate_path(os.path.join(self.ADDON_USERDATA_PATH, "skins.db"))
        self.ANIME_CACHE_DB_PATH = tools.translate_path(os.path.join(self.ADDON_USERDATA_PATH, "animeCache.db"))

    def get_kodi_video_db_connection(self):
        config = self.get_kodi_video_db_config()
        if config["type"] == "sqlite3":
            from resources.lib.database import SQLiteConnection

            return SQLiteConnection(os.path.join(self.KODI_DATABASE_PATH, f"{config['database']}.db"))
        elif config["type"] == "mysql":
            from resources.lib.database import MySqlConnection

            return MySqlConnection(config)

    def get_kodi_database_version(self):
        kodi_myvideos_version_map = {
            17: 107,
            18: 116,
            19: 119,
            20: 121,
            21: 131,
            22: 149,
        }

        if (db_version := kodi_myvideos_version_map.get(self.KODI_VERSION)) is None:
            raise KeyError("Unsupported kodi version")

        return db_version

    def get_kodi_video_db_config(self):
        result = {"type": "sqlite3", "database": f"MyVideos{self.get_kodi_database_version()}"}

        if xbmcvfs.exists(self.ADVANCED_SETTINGS_PATH):
            if advanced_settings_text := g.read_all_text(self.ADVANCED_SETTINGS_PATH):
                from xml.etree import ElementTree
                try:
                    advanced_settings = ElementTree.fromstring(advanced_settings_text)
                    if settings := advanced_settings.find("videodatabase"):
                        for setting in settings:
                            if setting.tag == 'type':
                                result["type"] = setting.text
                            elif setting.tag == 'host':
                                result["host"] = setting.text
                            elif setting.tag == 'port':
                                result["port"] = setting.text
                            elif setting.tag == 'name':
                                result["database"] = setting.text
                            elif setting.tag == 'user':
                                result["user"] = setting.text
                            elif setting.tag == 'pass':
                                result["password"] = setting.text
                except ElementTree.ParseError as pe:
                    g.log(f"Failed to parse advanced settings.xml: {pe}", "warning")
        if result["type"] == "sqlite3" and self.KODI_VERSION is not None and self.KODI_VERSION >= 22:
            # Kodi 22+ bumps the MyVideos schema number between builds (132, 143, 146, 149, ...),
            # so a fixed number cannot be trusted: use the newest MyVideos DB that has a files table.
            if detected := self._detect_kodi_video_db_name():
                result["database"] = detected
        return result

    def _detect_kodi_video_db_name(self):
        """Name (without .db) of the newest Kodi MyVideos sqlite DB that contains a `files` table, or None.

        Empty or table-less MyVideos files (left behind by older opens of a path Kodi never used) are skipped.
        The result is cached for the life of the process."""
        if cached := getattr(self, "_kodi_video_db_name_cache", None):
            return cached
        try:
            import sqlite3
            from pathlib import Path

            candidates = []
            for name in os.listdir(self.KODI_DATABASE_PATH):
                if match := re.fullmatch(r"MyVideos(\d+)\.db", name):
                    candidates.append((int(match.group(1)), name))
            for _, name in sorted(candidates, reverse=True):
                path = os.path.join(self.KODI_DATABASE_PATH, name)
                if os.path.getsize(path) == 0:
                    continue
                connection = None
                try:
                    connection = sqlite3.connect(f"{Path(path).as_uri()}?mode=ro", uri=True, timeout=5)
                    if connection.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='files'").fetchone():
                        self._kodi_video_db_name_cache = name[:-3]
                        return self._kodi_video_db_name_cache
                except sqlite3.Error:
                    continue
                finally:
                    if connection is not None:
                        connection.close()
        except Exception as e:
            g.log(f"Could not detect the Kodi video database: {e}", "warning")
        return None

    def clear_kodi_bookmarks(self):
        try:
            with self.get_kodi_video_db_connection() as video_database:
                if file_ids := [
                    str(i["idFile"])
                    for i in video_database.fetchall("SELECT * FROM files WHERE strFilename LIKE '%plugin.video.seren%'")
                ]:
                    video_database.execute_sql(
                        [
                            f"DELETE FROM {table} WHERE idFile IN ({','.join(file_ids)})"
                            for table in ["bookmark", "streamdetails", "files"]
                        ]
                    )
                else:
                    return
        except Exception as e:
            g.log(f"Failed to clear Kodi bookmarks: {e}", "warning")

    # region runtime settings
    def set_runtime_setting(self, setting_id, value):
        """
        Set a runtime setting value

        Lists and Dict may only contain simple types

        :param setting_id: The name of the setting
        :type setting_id: str
        :param value: The value to store in settings
        :type value: str|float|int|bool|list|dict
        """
        self.RUNTIME_SETTINGS_CACHE.set_setting(setting_id, value)

    def clear_runtime_setting(self, setting_id):
        """
        Clear a runtime setting from the cache.

        :param setting_id: The name of the setting
        :type setting_id: str
        """
        self.RUNTIME_SETTINGS_CACHE.clear_setting(setting_id)

    def get_runtime_setting(self, setting_id, default_value=None):
        """
        Get a runtime setting value

        :param setting_id: The name of the setting
        :type setting_id: str
        :param default_value: An optional default value to provide if the setting is not stored
        :type default_value: str|float|int|bool
        :return: The value of the setting.
                 If the setting is not stored, the optional default_value if provided or None
        :rtype: str|float|int|bool|list|dict
        """
        return self.RUNTIME_SETTINGS_CACHE.get_setting(setting_id, default_value)

    def get_float_runtime_setting(self, setting_id, default_value=None):
        """
        Get a runtime setting as a float value

        :param setting_id: The name of the setting
        :type setting_id: str
        :param default_value: An optional default value to provide if the setting is not stored
        :type default_value: float
        :return: The value of the setting.
                 If the setting is not stored, the optional default_value if provided or 0.0
        :rtype: float
        """
        return self.RUNTIME_SETTINGS_CACHE.get_float_setting(setting_id, default_value)

    def get_int_runtime_setting(self, setting_id, default_value=None):
        """
        Get a runtime setting as an int value

        :param setting_id: The name of the setting
        :type setting_id: str
        :param default_value: An optional default value to provide if the setting is not stored
        :type default_value: int
        :return: The value of the setting.
                 If the setting is not stored, the optional default_value if provided or 0
        :rtype: int
        """
        return self.RUNTIME_SETTINGS_CACHE.get_int_setting(setting_id, default_value)

    def get_bool_runtime_setting(self, setting_id, default_value=None):
        """
        Get a runtime setting as a bool value

        :param setting_id: The name of the setting
        :type setting_id: str
        :param default_value: An optional default value to provide if the setting is not stored
        :type default_value: bool
        :return: The value of the setting.
                 If the setting is not stored, the optional default_value if provided or False
        :rtype: bool
        """
        return self.RUNTIME_SETTINGS_CACHE.get_bool_setting(setting_id, default_value)

    # endregion

    # region KODI setting
    def set_setting(self, setting_id, value):
        """
        Set a setting value

        :param setting_id: The name of the setting
        :type setting_id: str
        :param value: The value to store in settings
        :type value: str|float|int|bool
        """
        self.SETTINGS_CACHE.set_setting(setting_id, value)

    def clear_setting(self, setting_id):
        """
        Clear a setting from the cache and settings.xml

        :param setting_id: The name of the setting
        :type setting_id: str
        """
        self.SETTINGS_CACHE.clear_setting(setting_id)

    def get_setting(self, setting_id, default_value=None):
        """
        Get a setting value

        :param setting_id: The name of the setting
        :type setting_id: str
        :param default_value:
        :type default_value: str
        :return: The value of the setting as a string
                 If the setting is not stored, the optional default_value if provided or None
        :rtype: str
        """
        return self.SETTINGS_CACHE.get_setting(setting_id, default_value)

    def get_float_setting(self, setting_id, default_value=None):
        """
        Get a setting as a float value

        :param setting_id: The name of the setting
        :type setting_id: str
        :param default_value: An optional default value to provide if the setting is not stored
        :type default_value: float
        :return: The value of the setting.
                 If the setting is not stored, the optional default_value if provided or 0.0
        :rtype: float
        """
        return self.SETTINGS_CACHE.get_float_setting(setting_id, default_value)

    def get_int_setting(self, setting_id, default_value=None):
        """
        Get a setting as an int value

        :param setting_id: The name of the setting
        :type setting_id: str
        :param default_value: An optional default value to provide if the setting is not stored
        :type default_value: int
        :return: The value of the setting.
                 If the setting is not stored, the optional default_value if provided or 0
        :rtype: int
        """
        return self.SETTINGS_CACHE.get_int_setting(setting_id, default_value)

    def get_bool_setting(self, setting_id, default_value=None):
        """
        Get a setting as a bool value

        :param setting_id: The name of the setting
        :type setting_id: str
        :param default_value: An optional default value to provide if the setting is not stored
        :type default_value: bool
        :return: The value of the setting.
                 If the setting is not stored, the optional default_value if provided or False
        :rtype: bool
        """
        return self.SETTINGS_CACHE.get_bool_setting(setting_id, default_value)

    # endregion

    def get_language_string(self, localization_id, addon=True):
        """
        Gets a localized string from cache if feasible, if not from localization files
        Will retrieve from addon localizations by default but can be requested from Kodi localizations

        :param localization_id: The id of the localization to retrieve
        :type localization_id: int
        :param addon: True to retrieve from addon, False from Kodi localizations.  Default True
        :type addon bool
        :return: The localized text matching the localization_id from the appropriate localization files.
        :rtype: str
        """
        cache_id = f"A{str(localization_id)}" if addon else f"K{str(localization_id)}"
        text = self.LANGUAGE_CACHE.get(cache_id)
        if not text:
            text = self.ADDON.getLocalizedString(localization_id) if addon else xbmc.getLocalizedString(localization_id)
            self.LANGUAGE_CACHE.update({cache_id: text})

        return text

    def get_view_type(self, content_type):
        view_type = None

        if not self.get_bool_setting("general.viewidswitch"):
            if content_type == self.CONTENT_MENU:
                view_type = self.get_setting("addon.view")
            if content_type == self.CONTENT_SHOW:
                view_type = self.get_setting("show.view")
            if content_type == self.CONTENT_MOVIE:
                view_type = self.get_setting("movie.view")
            if content_type == self.CONTENT_EPISODE:
                view_type = self.get_setting("episode.view")
            if content_type == self.CONTENT_SEASON:
                view_type = self.get_setting("season.view")
            if view_type is not None and view_type.isdigit() and int(view_type) > 0:
                view_name, view_type = viewTypes[int(view_type)]
                return view_type
        else:
            if content_type == self.CONTENT_MENU:
                view_type = self.get_setting("addon.view.id")
            if content_type == self.CONTENT_SHOW:
                view_type = self.get_setting("show.view.id")
            if content_type == self.CONTENT_MOVIE:
                view_type = self.get_setting("movie.view.id")
            if content_type == self.CONTENT_EPISODE:
                view_type = self.get_setting("episode.view.id")
            if content_type == self.CONTENT_SEASON:
                view_type = self.get_setting("season.view.id")
            if view_type is not None and view_type.isdigit() and int(view_type) > 0:
                return int(view_type)

        return 0

    def log(self, msg, level="info"):
        msg = msg
        msg = f"{self.ADDON_NAME.upper()} ({self.PLUGIN_HANDLE}): {msg}"
        if level == "error":
            xbmc.log(msg, level=xbmc.LOGERROR)
        elif level == "info":
            xbmc.log(msg, level=xbmc.LOGINFO)
        elif level == "notice":
            if self.KODI_VERSION >= 19:
                xbmc.log(msg, level=xbmc.LOGINFO)
            else:
                xbmc.log(msg, level=xbmc.LOGNOTICE)  # pylint: disable=no-member
        elif level == "warning":
            xbmc.log(msg, level=xbmc.LOGWARNING)
        else:
            xbmc.log(msg)

    def log_stacktrace(self):
        """Gets the latest traceback stacktrace and logs it."""
        self.log(traceback.format_exc(), "error")

    def color_picker(self):
        """Method that generates color list and handles the popup."""
        select_list = [self.color_string("inherit")]
        select_list.extend(self.color_string(i, i) for i in colorChart)
        color = xbmcgui.Dialog().select(f"{self.ADDON_NAME}: {self.get_language_string(30016)}", select_list)
        if color == -1:
            return
        if color == 0:
            self.set_setting("general.textColor", "inherit")
            self.set_setting("general.displayColor", "inherit")
        else:
            color -= 1
            self.set_setting("general.textColor", colorChart[color])
            self.set_setting("general.displayColor", colorChart[color])
        self.open_addon_settings(1, 1)

    @staticmethod
    def _try_get_color_from_skin():
        if focus_color := xbmc.getInfoLabel("Skin.String(focuscolor.name)"):  # jurial based skins.
            return focus_color

        if skin_dir := xbmc.getSkinDir():
            if isinstance(skin_color := _SKIN_COLOR_LOOKUP.get(skin_dir), dict):
                skin_color = skin_color.get(
                    xbmc.getInfoLabel("Skin.CurrentTheme").lower(), skin_color.get("default", None)
                )
            return skin_color
        return None

    def get_user_text_color(self):
        """Get the user selected color setting when nothing is selecting it returns
        the default value (deepskyblue) or the default form the installed skin.

        :return:Selected color from the user or the default from the skin or the Seren default (deepskyblue)
        :rtype:str
        """
        color = self.get_setting("general.displayColor")
        if not color or color == "None" or color == "inherit":
            color = self._try_get_color_from_skin() or "deepskyblue"

        return color

    def color_string(self, text, color=None):
        """Method that wraps the text with the supplied color, or takes the user default.

        :param text:Text that needs to be wrapped
        :type text:str|int|float
        :param color:Color name used in the Kodi color tag
        :type color:str
        :return:Text wrapped in a Kodi color tag.
        :rtype:str
        """
        if color == "default" or not color or color == "inherit":
            color = self.get_user_text_color()

        return f"[COLOR {color}]{text}[/COLOR]"

    def clear_cache(self, silent=False):
        if not silent:
            confirm = xbmcgui.Dialog().yesno(self.ADDON_NAME, self.get_language_string(30029))
            if confirm != 1:
                return
        g.show_busy_dialog()
        try:
            try:
                g.CACHE.clear_all()
                g._init_cache()
                self.log("Clear All Cache: metadata cache cleared", "info")
            except Exception as e:
                self.log(f"Clear All Cache: metadata cache error: {e}", "warning")
            try:
                from resources.lib.database.debridCache import DebridCache
                DebridCache().clear_all()
                self.log("Clear All Cache: debrid cache cleared", "info")
            except Exception as e:
                self.log(f"Clear All Cache: debrid cache error: {e}", "warning")
            try:
                from resources.lib.database.torrentCache import TorrentCache
                TorrentCache().rebuild_database()
                self.log("Clear All Cache: torrent cache cleared", "info")
            except Exception as e:
                self.log(f"Clear All Cache: torrent cache error: {e}", "warning")
            try:
                from resources.lib.database.providerPerformance import ProviderPerformance
                ProviderPerformance().clear_all()
                self.log("Clear All Cache: provider stats cleared", "info")
            except Exception as e:
                self.log(f"Clear All Cache: provider stats error: {e}", "warning")
            try:
                from resources.lib.database.searchHistory import SearchHistory
                SearchHistory().execute_sql("DELETE FROM search_history")
                self.log("Clear All Cache: search history cleared", "info")
            except Exception as e:
                self.log(f"Clear All Cache: search history error: {e}", "warning")
            # TorrentAssist is only cleared on manual button press (silent=False).
            # Excluded from install/version-change clears (silent=True) so that
            # in-progress transfers are not orphaned mid-upgrade.
            if not silent:
                try:
                    from resources.lib.database.torrentAssist import TorrentAssist
                    TorrentAssist().clear_all()
                    self.log("Clear All Cache: torrent assist cleared", "info")
                except Exception as e:
                    self.log(f"Clear All Cache: torrent assist error: {e}", "warning")
        finally:
            g.close_busy_dialog()
        self.log(f"{self.ADDON_NAME}: All caches cleared", "info")
        if not silent:
            xbmcgui.Dialog().notification(self.ADDON_NAME, self.get_language_string(30052))

    def cancel_playback(self):
        self.PLAYLIST.clear()
        xbmcplugin.setResolvedUrl(self.PLUGIN_HANDLE, False, xbmcgui.ListItem(offscreen=True))
        self.close_busy_dialog()
        self.close_all_dialogs()

    def show_busy_dialog(self):
        xbmc.executebuiltin("ActivateWindow(busydialognocancel)")

    def close_all_dialogs(self):
        xbmc.executebuiltin("Dialog.Close(all,true)")

    def close_ok_dialog(self):
        xbmc.executebuiltin("Dialog.Close(okdialog, true)")

    _PLAYBACK_MARKER_KEY = "seren.playback"

    def set_playback_marker(self, item_information):
        """Tell other add-ons (TMDb Helper's scrobbling observer) that this play is Seren's.

        Kodi shows no plugin:// origin for a Seren stream, so Seren names itself in a Home property, set before the
        stream is handed to Kodi on every attempt. Carries the TMDb ids of the item (the show's for an episode) so a
        reader accepts it only for the item that is actually playing. Returns the value written, for clear_playback_marker.
        """
        marker = ""
        try:
            info = item_information["info"]
            if info.get("mediatype") == self.MEDIA_EPISODE:
                tmdb_id = info.get("tmdb_show_id") or info.get("tvshow.tmdb_id")
                marker = {"mediatype": "episode", "tmdb_id": str(tmdb_id or ""), "season": info.get("season"), "episode": info.get("episode")}
            elif info.get("mediatype") == self.MEDIA_MOVIE:
                marker = {"mediatype": "movie", "tmdb_id": str(info.get("tmdb_id") or "")}
            marker = json.dumps(marker, sort_keys=True) if marker and marker["tmdb_id"] else ""
        except (KeyError, TypeError, AttributeError):
            marker = ""
        if marker:
            self.HOME_WINDOW.setProperty(self._PLAYBACK_MARKER_KEY, marker)
        else:
            self.HOME_WINDOW.clearProperty(self._PLAYBACK_MARKER_KEY)
        return marker

    def clear_playback_marker(self, marker):
        """Clear the marker only if it is still the one this play wrote (a newer play may have replaced it)."""
        if marker and self.HOME_WINDOW.getProperty(self._PLAYBACK_MARKER_KEY) == marker:
            self.HOME_WINDOW.clearProperty(self._PLAYBACK_MARKER_KEY)

    _PLAY_START_KEY = "seren.play_start"
    # How long a play request counts as "still starting". A normal start (scrape + up to three source attempts) is over well inside
    # this; the cap only protects against a claim that was never released (the Python process died), so a later request is never
    # ignored for longer than this.
    _PLAY_START_WINDOW = 180

    def _play_start_key(self, item_information):
        """Identity of the item a play request is for: media type, TMDb id (the show's for an episode), season, episode."""
        try:
            info = item_information["info"]
            if info.get("mediatype") == self.MEDIA_EPISODE:
                tmdb_id = info.get("tmdb_show_id") or info.get("tvshow.tmdb_id")
                key = f"episode:{tmdb_id}:{info.get('season')}:{info.get('episode')}"
            elif info.get("mediatype") == self.MEDIA_MOVIE:
                tmdb_id = info.get("tmdb_id")
                key = f"movie:{tmdb_id}"
            else:
                return ""
            return key if tmdb_id else ""
        except (KeyError, TypeError, AttributeError):
            return ""

    def duplicate_play_age(self, item_information):
        """Read-only: seconds since the claim of an earlier request for the SAME item that has not released it yet, or None when
        there is no such claim (a different item, an unidentifiable item, no claim, or a claim older than _PLAY_START_WINDOW)."""
        key = self._play_start_key(item_information)
        if not key:
            return None
        try:
            held = json.loads(self.HOME_WINDOW.getProperty(self._PLAY_START_KEY) or "null")
        except (TypeError, ValueError):
            return None
        if not (isinstance(held, dict) and held.get("key") == key):
            return None
        try:
            age = time.time() - float(held.get("ts", 0))
        except (TypeError, ValueError):
            return None
        return age if 0 <= age < self._PLAY_START_WINDOW else None

    def claim_play_start(self, item_information):
        """Register this play request as the one that is starting playback of its item.

        Returns (token, age): a token to hand to release_play_start when the stream is playing (or the request ended), or
        (None, seconds) when another request for the SAME item claimed it less than _PLAY_START_WINDOW seconds ago and has not
        released it yet - that one is a duplicate (double click, impatient second press, a second add-on asking again) and
        must not start a second scrape/watchdog on the item. A different item, an unidentifiable item and an old claim are
        all allowed through. The check and the write are not atomic across Python interpreters; two requests landing within
        the same few milliseconds could still both pass, a limit accepted because real duplicates arrive hundreds of ms or more apart.
        """
        key = self._play_start_key(item_information)
        if not key:
            return "", 0.0
        age = self.duplicate_play_age(item_information)
        if age is not None:
            return None, age
        now = time.time()
        token = f"{now:.3f}:{key}"
        self.HOME_WINDOW.setProperty(self._PLAY_START_KEY, json.dumps({"key": key, "ts": now, "token": token}))
        return token, 0.0

    def release_play_start(self, token):
        """The request that claimed the start is done starting (stream playing, or it ended without one). Only the claim this
        request wrote is cleared, never a newer request's."""
        if not token:
            return
        try:
            held = json.loads(self.HOME_WINDOW.getProperty(self._PLAY_START_KEY) or "null")
        except (TypeError, ValueError):
            held = None
        if isinstance(held, dict) and held.get("token") == token:
            self.HOME_WINDOW.clearProperty(self._PLAY_START_KEY)

    def reject_duplicate_play(self):
        """Answer a duplicate play request: resolve only its own plugin handle as failed. Deliberately NOT cancel_playback(), which
        would clear the playlist and close the windows of the request that is really starting."""
        xbmcplugin.setResolvedUrl(self.PLUGIN_HANDLE, False, xbmcgui.ListItem(offscreen=True))

    _PLAYBACK_RESULT_KEY = "seren.playback_result"
    playback_user_canceled = False

    def reset_playback_result(self):
        """Start of a play attempt: forget the last attempt's outcome and any user cancel."""
        self.playback_user_canceled = False
        self.HOME_WINDOW.clearProperty(self._PLAYBACK_RESULT_KEY)

    def note_user_cancel(self):
        """The user backed out of one of Seren's play windows (scrape, resolver, cache assist, source select)."""
        self.playback_user_canceled = True

    def set_playback_result(self, item_information, result):
        """Say in a Home property how a play attempt ended without a stream: "no_sources" (nothing playable was found) or
        "failed" (every source failed to resolve). Lets another add-on (OpenInfo's playback watchdog) tell Seren giving up from
        the user backing out, which look the same from outside. Never written once the user cancelled. Carries the item's TMDb
        id (the show's for an episode), season, episode and a time stamp; nothing else. Returns the value written."""
        if self.playback_user_canceled:
            return ""
        try:
            info = item_information["info"]
            if info.get("mediatype") == self.MEDIA_EPISODE:
                tmdb_id = info.get("tmdb_show_id") or info.get("tvshow.tmdb_id")
                payload = {"mediatype": "episode", "tmdb_id": str(tmdb_id or ""), "season": info.get("season"), "episode": info.get("episode")}
            elif info.get("mediatype") == self.MEDIA_MOVIE:
                payload = {"mediatype": "movie", "tmdb_id": str(info.get("tmdb_id") or "")}
            else:
                return ""
            if not payload["tmdb_id"]:
                return ""
            payload["result"] = result
            payload["ts"] = time.time()
            value = json.dumps(payload, sort_keys=True)
        except (KeyError, TypeError, AttributeError):
            return ""
        self.HOME_WINDOW.setProperty(self._PLAYBACK_RESULT_KEY, value)
        return value

    def set_playback_result_for_unidentified(self, action_args, result="failed"):
        """A play request that could not even be identified (the movie or episode is not in Trakt's data, or has no Trakt ID) has
        no item information, so set_playback_result cannot be used; build the same signal from the request's own action args
        (TMDb id - the show's for an episode -, season, episode). Without it another add-on cannot tell this from the user backing
        out and would not try its next player. Written after reset_playback_result and never once the user cancelled. Returns the
        value written, or "" when the request carries no usable TMDb id."""
        try:
            mediatype = action_args.get("mediatype")
            tmdb_id = action_args.get("tmdb_id")
            if not tmdb_id:
                return ""
            if mediatype == self.MEDIA_EPISODE:
                info = {"mediatype": mediatype, "tmdb_show_id": tmdb_id, "season": int(action_args["season"]), "episode": int(action_args["episode"])}
            elif mediatype == self.MEDIA_MOVIE:
                info = {"mediatype": mediatype, "tmdb_id": tmdb_id}
            else:
                return ""
        except (KeyError, TypeError, ValueError, AttributeError):
            return ""
        return self.set_playback_result({"info": info}, result)

    def close_busy_dialog(self):
        xbmc.executebuiltin("Dialog.Close(busydialog)")
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")

    @staticmethod
    def deaccent_string(text):
        """Deaccent the provided text leaving other unicode characters intact
        Example: Mîxéd ДљфӭЖ Tëst -> Mixed ДљфэЖ Test
        :param: text: Text to deaccent
        :type text: str
        :return: Deaccented string
        :rtype:str
        """
        nfkd_form = unicodedata.normalize('NFKD', text)  # pylint: disable=c-extension-no-member
        return "".join([c for c in nfkd_form if not unicodedata.combining(c)])  # pylint: disable=c-extension-no-member

    @staticmethod
    def transliterate_string(text):
        """Transliterate the provided text into ascii equivalents
        Example: 张新成 -> Zhang Xincheng
        Note that this method will remove any extra whitespace leaving only single spaces *between* characters
        :param: text: Text to transliterate
        :type text: str
        :return: Transliterated string
        :rtype:str
        """
        from unidecode import unidecode
        transliterted_text = unidecode(text)
        # Remove extra whitespace
        transliterted_text = " ".join(transliterted_text.split())
        return transliterted_text

    def premium_check(self):
        return bool(self.PLAYLIST.getposition() > 0 or self.debrid_available())

    @cached_property
    def _debrid_available(self):
        return self.premiumize_enabled() or self.real_debrid_enabled() or self.all_debrid_enabled() or self.torbox_enabled() or self.debridlink_enabled() or self.offcloud_enabled()

    def debrid_available(self):
        return self._debrid_available

    def trakt_active(self):
        return bool(self.get_setting('trakt.auth')) and self.get_bool_setting('trakt.enabled', False)

    def mdblist_active(self):
        return self.get_setting('mdblist.enabled') == "true" and bool(
            self.get_setting('mdblist.auth') or self.get_setting('mdblist.apikey')
        )

    def simkl_active(self):
        return bool(self.get_setting('simkl.auth')) and self.get_bool_setting('simkl.enabled')

    def local_scraping_configured(self):
        """Settings-only check, no I/O — safe to call from the synchronous dispatch path."""
        if not self.get_bool_setting('local.fileInspection'):
            return False
        for setting_id in ('local.location', 'download.location'):
            folder = (self.get_setting(setting_id) or '').strip()
            if folder and folder.lower() != 'userdata':
                return True
        return False

    def local_playback_available(self):
        """Adds a filesystem liveness probe on top of local_scraping_configured() —
        only call this from a worker thread, never the synchronous dispatch path."""
        if not self.local_scraping_configured():
            return False
        tried = []
        for setting_id in ('local.location', 'download.location'):
            folder = (self.get_setting(setting_id) or '').strip()
            if folder and folder.lower() != 'userdata':
                tried.append(folder)
                if xbmcvfs.exists(tools.ensure_path_is_dir(folder)):
                    return True
        self.log(f"Local scraper: configured folder(s) not accessible: {tried}", "info")
        return False

    @cached_property
    def _premiumize_enabled(self):
        return bool(self.get_setting("premiumize.token") != "" and self.get_bool_setting("premiumize.enabled"))

    def premiumize_enabled(self):
        return self._premiumize_enabled

    @cached_property
    def _real_debrid_enabled(self):
        return bool(self.get_setting("rd.auth") and self.get_bool_setting("realdebrid.enabled"))

    def real_debrid_enabled(self):
        return self._real_debrid_enabled

    @cached_property
    def _all_debrid_enabled(self):
        return bool(self.get_setting("alldebrid.apikey") != "" and self.get_bool_setting("alldebrid.enabled"))

    def all_debrid_enabled(self):
        return self._all_debrid_enabled

    @cached_property
    def _torbox_enabled(self):
        return bool(self.get_setting("torbox.token") != "" and self.get_bool_setting("torbox.enabled"))

    def torbox_enabled(self):
        return self._torbox_enabled

    @cached_property
    def _debridlink_enabled(self):
        return bool(self.get_setting("debridlink.token") != "" and self.get_bool_setting("debridlink.enabled"))

    def debridlink_enabled(self):
        return self._debridlink_enabled

    @cached_property
    def _offcloud_enabled(self):
        return bool(self.get_setting("offcloud.apikey") != "" and self.get_bool_setting("offcloud.enabled"))

    def offcloud_enabled(self):
        return self._offcloud_enabled

    # A calendar window (gui/windows/calendar_context_menu.py) runs the Trakt / MDBList / Simkl manager on top of itself. The
    # manager's Container.Refresh would re-run whatever list is behind the dialog (a calendar opened as a Videos directory would
    # open again), and trigger_widget_refresh() would wait for the Home window - which cannot come while the modal window is
    # open - and freeze it. While the flag is set the Container.Refresh is dropped (the window rebuilds its own page, and the
    # menu behind it holds no data) and the widget refresh is only noted; end_calendar_window() runs it once the window is
    # closed. In-process on purpose: a flag that outlives its interpreter (a crash) would silently suppress every refresh.
    _calendar_window_open = False
    _calendar_widget_pending = None  # None, or the if_playing value of the deferred widget refresh
    calendar_option_ran = False  # set by either refresh below while a calendar window is open: an option changed something

    def begin_calendar_window(self):
        self._calendar_window_open = True
        self._calendar_widget_pending = None
        self.calendar_option_ran = False

    def end_calendar_window(self):
        """Run the widget refresh that was held back while the calendar window was open (the window is closed by now)."""
        self._calendar_window_open = False
        widget_if_playing = self._calendar_widget_pending
        self._calendar_widget_pending = None
        if widget_if_playing is not None:
            self.trigger_widget_refresh(if_playing=widget_if_playing, bridge=False)

    def container_refresh(self):
        if self._calendar_window_open:
            self.calendar_option_ran = True
            return None
        return xbmc.executebuiltin("Container.Refresh")

    def trigger_widget_refresh(self, if_playing=True, bridge=True):
        """
        Trigger a widget refresh using the update library with an invalid path trick
        Widget refresh will not be attempted if playing if if_playing is False or if another process is waiting to
        refresh widgets.
        The widget refresh will not occur until the user returns to the home window to prevent updating other addon
        containers.

        Care must be taken when executing this method as it will block until the home window becomes available or
        playback is started or if the library is already being scanned, but for at most WIDGET_REFRESH_MAX_WAIT
        seconds: an uncapped wait held one plugin interpreter for 208-412 s on the Shield (3.9.45/3.9.49 logs). A refresh
        that gives up is dropped, not deferred - the next widget-affecting action queues a new one.
        bridge=True (every caller that follows a change the user made) also asks the cross-service sync to run shortly
        (setting crosssync.dynamic, modules/bridgeTrigger.py); the request is made before any early return below.
        :param if_playing: Whether to attempt to refresh widgets if playing.  Default: True
        :type if_playing: bool
        :param bridge: Whether this refresh follows a change of the user's data. Default: True
        :type bridge: bool
        """
        if bridge:
            from resources.lib.modules.bridgeTrigger import request_run

            request_run()
        if self._calendar_window_open:  # held back until the calendar window is closed (see begin_calendar_window)
            self._calendar_widget_pending = if_playing and (self._calendar_widget_pending is not False)
            self.calendar_option_ran = True
            return
        player = xbmc.Player()
        if (
            self.get_bool_runtime_setting("widget_refreshing")
            or (player.isPlaying() and not if_playing)
            or xbmc.getCondVisibility(  # Don't wait if we are playing as it will refresh after
                "Library.IsScanningVideo"
            )  # Don't do library update if already scanning library
        ):
            del player
            return
        deadline = time.monotonic() + WIDGET_REFRESH_MAX_WAIT
        try:
            g.set_runtime_setting("widget_refreshing", True)
            while not self.abort_requested():
                if time.monotonic() > deadline:
                    self.log(
                        f"Giving up queued widget refresh: home window not reached within {WIDGET_REFRESH_MAX_WAIT}s",
                        "debug",
                    )
                    break
                if xbmcgui.getCurrentWindowId() == 10000:
                    if not (
                        self.wait_for_abort(0.2)
                        or xbmc.getCondVisibility(  # Short wait to see if anything else kicks off a widget refresh
                            "Container().isUpdating"
                        )  # Check if widgets currently refreshing
                    ):
                        self.log("TRIGGERING WIDGET REFRESH")
                        xbmc.executebuiltin('UpdateLibrary(video,widget_refresh,true)')
                    else:
                        self.log("Aborting widget refresh as container on home screen already refreshing", "debug")
                    break
                elif (
                    self.wait_for_abort(0.3) or player.isPlaying() or xbmc.getCondVisibility("Library.IsScanningVideo")
                ):
                    self.log("Aborting queued widget refresh as another process will trigger it", "debug")
                    break
        finally:
            del player
            g.clear_runtime_setting("widget_refreshing")

    def get_language_code(self, country=None):
        lang = self.json_rpc("Application.getProperties", {"properties": ["language"]}).get("language")
        if lang is None:
            g.log("Could not determine language", "warning")
            return ""
        if country:
            from resources.lib.third_party import pytz
            if lang == "en_GB" and g.get_setting("general.localtimezone") in pytz.country_timezones["US"]:
                lang = "en_US"  # Workaround for Americans that just can't comprehend that Kodi default is en_GB
            lang = lang.split("_")
            if len(lang) > 1 and len(lang[1]) == 2:
                lang = f"{lang[0].lower()}-{lang[1].upper()}"
                return lang
            else:
                g.log("Could not determine country part of language", "warning")
                return ""
        return lang.split("_")[0].lower()

    @cached_property
    def common_video_extensions(self):
        return tuple({ext for ext in xbmc.getSupportedMedia("video").split("|") if ext not in {"", ".zip", ".rar", ".url"}})

    def add_directory_item(self, name, **params):
        menu_item = params.pop("menu_item", {})
        if not isinstance(menu_item, dict):
            menu_item = {}

        item = xbmcgui.ListItem(label=name, offscreen=True)
        item.setContentLookup(False)
        tag = self._video_tag(item)

        info = menu_item.pop("info", {})
        self.add_empty_video_stream(item, tag)

        if info is None or not isinstance(info, dict):
            info = {}

        self._apply_listitem_properties(item, info)
        if self.studio_limit:
            self.handle_studio_icon_skin_workaround(item, info)

        if "unwatched_episodes" in menu_item:
            item.setProperty("UnWatchedEpisodes", str(menu_item["unwatched_episodes"]))
        if "watched_episodes" in menu_item:
            item.setProperty("WatchedEpisodes", str(menu_item["watched_episodes"]))
        if (
            menu_item.get("episode_count", 0)
            and menu_item.get("watched_episodes", 0)
            and menu_item.get("episode_count", 0) == menu_item.get("watched_episodes", 0)
        ):
            info["playcount"] = 1
        if (
            menu_item.get("watched_episodes", 0) == 0
            and menu_item.get("episode_count", 0)
            and menu_item.get("episode_count", 0) > 0
        ):
            item.setProperty("WatchedEpisodes", str(0))
            item.setProperty("UnWatchedEpisodes", str(menu_item.get("episode_count", 0)))
        if "episode_count" in menu_item:
            item.setProperty("TotalEpisodes", str(menu_item["episode_count"]))
        if "season_count" in menu_item:
            item.setProperty("TotalSeasons", str(menu_item["season_count"]))
        if (
            "percent_played" in menu_item
            and menu_item.get("percent_played") is not None
            and float(menu_item.get("percent_played", 0)) > 0
        ):
            item.setProperty("percentplayed", str(menu_item["percent_played"]))
        if (
            "resume_time" in menu_item
            and menu_item.get("resume_time") is not None
            and int(menu_item.get("resume_time", 0)) > 0
        ):
            params["resume"] = str(menu_item["resume_time"])
            item.setProperty("resumetime", str(menu_item["resume_time"]))
        if "play_count" in menu_item and menu_item.get("play_count") is not None:
            info["playcount"] = menu_item["play_count"]
        if "air_date" in menu_item and menu_item.get("air_date") is not None:
            info["premiered"] = menu_item["air_date"]
            info["aired"] = menu_item["air_date"]
        if "description" in params:
            info["plot"] = info["overview"] = info["description"] = params.pop("description", None)
        if menu_item.get("user_rating"):
            item.setProperty("userrating", str(menu_item["user_rating"]))

        special_sort = params.pop("special_sort", None)
        if special_sort is not None:
            item.setProperty("SpecialSort", str(special_sort))
        label2 = params.pop("label2", None)
        if label2 is not None:
            item.setLabel2(label2)

        if params.pop("is_playable", False):
            item.setProperty("IsPlayable", "true")
            is_folder = params.pop("is_folder", False)
        else:
            item.setProperty("IsPlayable", "false")
            is_folder = params.pop("is_folder", True)

        cast = menu_item.get("cast", [])
        if cast is None or not isinstance(cast, (set, list)):
            cast = []
        self.set_video_cast(item, cast, tag)

        for key, value in info.items():
            if key.endswith("_id"):
                item.setProperty(key, str(value))

        media_type = info.get("mediatype", None)
        is_child_type = media_type in self._EPISODE_SEASON_TYPES
        self.set_video_unique_ids(
            item,
            {
                unique_id_key: info[f"tvshow.{id_key}" if is_child_type else id_key]
                for id_key, unique_id_key in self._ID_KEYS.items()
                if info.get(f"tvshow.{id_key}" if is_child_type else id_key)
            },
            tag,
        )

        for i in info:
            if i.startswith("rating."):
                self.set_video_rating(
                    item, i.split(".")[1], float(info[i].get("rating", 0.0)), int(info[i].get("votes", 0)), tag
                )

        cm = params.pop("cm", [])
        if cm is None or not isinstance(cm, (set, list)):
            cm = []
        item.addContextMenuItems(cm)

        art = menu_item.pop("art", {})
        if art is None or not isinstance(art, dict):
            art = {}
        if (
            art.get("fanart", art.get("season.fanart", art.get("tvshow.fanart", None))) is None
        ) and not self.fanart_fallback_disabled:
            art["fanart"] = self.DEFAULT_FANART
        if art.get("poster", art.get("season.poster", art.get("tvshow.poster", None))) is None:
            art["poster"] = self.DEFAULT_POSTER
        if not art.get("icon"):
            art["icon"] = self.DEFAULT_ICON
        if not art.get("thumb"):
            art["thumb"] = ""
        with contextlib.suppress(Exception):
            item.setArt(art)

        # Clear out keys not relevant to Kodi info labels
        self.clean_info_keys(info)
        # Convert dates to localtime for display
        self.convert_info_dates(info)

        self.set_video_info(item, info, tag)

        bulk_add = params.pop("bulk_add", False)
        url = self.create_url(self.BASE_URL, params)
        if bulk_add:
            return url, item, is_folder
        else:
            xbmcplugin.addDirectoryItem(handle=self.PLUGIN_HANDLE, url=url, listitem=item, isFolder=is_folder)

    def add_menu_items(self, item_list):
        xbmcplugin.addDirectoryItems(self.PLUGIN_HANDLE, item_list, len(item_list))

    @staticmethod
    def clean_info_keys(info_dict):
        if not isinstance(info_dict, dict):
            return info_dict

        for key in info_dict.keys() - info_labels:
            info_dict.pop(key)

        return info_dict

    @cached_property
    def _local_is_utc(self):
        """True if local timezone is UTC — skip date conversions."""
        return self.LOCAL_TIMEZONE == self.UTC_TIMEZONE

    def convert_info_dates(self, info_dict):
        if not isinstance(info_dict, dict) or self._local_is_utc:
            return info_dict

        converted_dates = {key: self.utc_to_local(info_dict.get(key)) for key in info_dict.keys() & info_dates}
        info_dict.update(converted_dates)

        return info_dict

    @staticmethod
    def _video_tag(item):
        """The item's InfoTagVideo, or None where the tag has no setters (Kodi 19)."""
        tag = None
        with contextlib.suppress(Exception):
            tag = item.getVideoInfoTag()
        return tag if tag is not None and hasattr(tag, "setTitle") else None

    def set_video_info(self, item, info, tag=None):
        """Apply an info dict to a ListItem through the InfoTagVideo setters instead of the deprecated setInfo.

        Keys are applied in sorted order, as setInfo's std::map did, which matters for rating before votes.
        Keys without a setter (overlay, castandrole), and every key when the tag has no setters (Kodi 19),
        still go through setInfo. One rejected value is logged and skipped, not allowed to fail the whole item.
        """
        if tag is None:
            tag = self._video_tag(item)
        if tag is None:
            item.setInfo("video", info)
            return

        leftover = {}
        for key in sorted(info):
            value = info[key]
            setter_name, convert = _VIDEO_INFOTAG_SETTERS.get(key.lower(), (None, None))
            setter = getattr(tag, setter_name, None) if setter_name else None
            if setter is None:
                leftover[key] = value
            elif value is not None:
                try:
                    setter(convert(value))
                except Exception as exc:  # pylint: disable=broad-except
                    self.log(f"InfoTagVideo.{setter_name} rejected {key}={value!r}: {exc}", "warning")

        if leftover:
            try:
                item.setInfo("video", leftover)
            except Exception as exc:  # pylint: disable=broad-except
                self.log(f"ListItem.setInfo rejected {sorted(leftover)}: {exc}", "warning")

    def set_video_cast(self, item, cast, tag=None):
        """Set cast through InfoTagVideo.setCast; ListItem.setCast is deprecated. Falls back to it on Kodi 19."""
        if tag is None:
            tag = self._video_tag(item)
        actor_class = getattr(xbmc, "Actor", None)
        if tag is not None and actor_class is not None and hasattr(tag, "setCast"):
            try:
                actors = []
                for entry in cast:
                    # Actor() rejects an empty name, so nameless entries are skipped
                    name = entry.get("name") if isinstance(entry, dict) else None
                    if name is None or not (name := str(name)):
                        continue
                    role = entry.get("role")
                    order = entry.get("order")
                    thumbnail = entry.get("thumbnail")
                    actors.append(
                        actor_class(
                            name,
                            "" if role is None else str(role),
                            -1 if order is None else _tag_int(order),
                            "" if thumbnail is None else str(thumbnail),
                        )
                    )
                tag.setCast(actors)
                return
            except Exception as exc:  # pylint: disable=broad-except
                self.log(f"InfoTagVideo.setCast failed: {exc}", "warning")
        item.setCast(cast)

    def set_video_unique_ids(self, item, unique_ids, tag=None):
        """Set unique ids through InfoTagVideo.setUniqueIDs; ListItem.setUniqueIDs is deprecated."""
        if tag is None:
            tag = self._video_tag(item)
        if tag is not None and hasattr(tag, "setUniqueIDs"):
            try:
                tag.setUniqueIDs({str(k): str(v) for k, v in unique_ids.items() if v is not None})
                return
            except Exception as exc:  # pylint: disable=broad-except
                self.log(f"InfoTagVideo.setUniqueIDs failed: {exc}", "warning")
        item.setUniqueIDs(unique_ids)

    def set_video_rating(self, item, rating_type, rating, votes, tag=None):
        """Add a typed rating through InfoTagVideo.setRating; ListItem.setRating is deprecated."""
        if tag is None:
            tag = self._video_tag(item)
        if tag is not None and hasattr(tag, "setRating"):
            try:
                # InfoTagVideo.setRating takes (rating, votes, type, isDefault), not ListItem.setRating's order
                tag.setRating(rating, votes, rating_type, False)
                return
            except Exception as exc:  # pylint: disable=broad-except
                self.log(f"InfoTagVideo.setRating failed: {exc}", "warning")
        item.setRating(rating_type, rating, votes, False)

    def add_empty_video_stream(self, item, tag=None):
        """Mark the item as having a video stream; ListItem.addStreamInfo is deprecated."""
        if tag is None:
            tag = self._video_tag(item)
        stream_class = getattr(xbmc, "VideoStreamDetail", None)
        if tag is not None and stream_class is not None and hasattr(tag, "addVideoStream"):
            try:
                tag.addVideoStream(stream_class())
                return
            except Exception as exc:  # pylint: disable=broad-except
                self.log(f"InfoTagVideo.addVideoStream failed: {exc}", "warning")
        item.addStreamInfo("video", {})

    def close_directory(self, content_type, sort=False, cache=False):
        if sort == "title":
            xbmcplugin.addSortMethod(self.PLUGIN_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
        if sort == "episode":
            xbmcplugin.addSortMethod(self.PLUGIN_HANDLE, xbmcplugin.SORT_METHOD_EPISODE)
        if not sort:
            xbmcplugin.addSortMethod(self.PLUGIN_HANDLE, xbmcplugin.SORT_METHOD_NONE)
        xbmcplugin.setContent(self.PLUGIN_HANDLE, content_type)
        menu_caching = self.menu_caching_enabled or cache
        xbmcplugin.endOfDirectory(self.PLUGIN_HANDLE, cacheToDisc=menu_caching)
        self.set_view_type(content_type)

    def set_view_type(self, content_type):
        def _execute_set_view_mode(view):
            xbmc.sleep(50)
            xbmc.executebuiltin(f"Container.SetViewMode({view})")

        if self.set_views_enabled and self.is_addon_visible():
            view_type = self.get_view_type(content_type)
            if view_type > 0:
                tools.run_threaded(_execute_set_view_mode, view_type)

    def is_addon_visible(self):
        return xbmc.getInfoLabel('Container.PluginName') == "plugin.video.seren"

    def cancel_directory(self, silent=False):
        if g.FROM_WIDGET or not silent:
            g.add_directory_item(
                g.get_language_string(284, addon=False),
                menu_item=g.create_icon_dict("trakt_sync", base_path=g.ICONS_PATH),
            )
            xbmcplugin.setContent(self.PLUGIN_HANDLE, g.CONTENT_MENU)
            xbmcplugin.endOfDirectory(self.PLUGIN_HANDLE, succeeded=True, cacheToDisc=False)
        else:
            xbmcplugin.endOfDirectory(self.PLUGIN_HANDLE, succeeded=False, cacheToDisc=False)

    def read_all_text(self, file_path):
        try:
            f = xbmcvfs.File(file_path, "r")
            return f.read()
        except OSError:
            return None
        finally:
            with contextlib.suppress(Exception):
                f.close()

    def write_all_text(self, file_path, content):
        try:
            f = xbmcvfs.File(file_path, "w")
            return f.write(content)
        except OSError:
            return None
        finally:
            with contextlib.suppress(Exception):
                f.close()

    def notification(self, heading, message, time=5000, sound=True):
        if self.disable_notification_sound:
            sound = False
        dialogue = xbmcgui.Dialog()
        dialogue.notification(heading, message, time=time, sound=sound)
        del dialogue

    def notification_unless_playing(self, heading, message, time=5000, sound=True):
        """For pop-ups raised by background work (the scheduled provider syncs): skip it while a video is playing
        so it can't appear over what the user is watching. The work itself is unaffected."""
        if xbmc.Player().isPlayingVideo():
            self.log(f"Skipped pop-up while a video is playing: {message}", "debug")
            return
        self.notification(heading, message, time=time, sound=sound)

    def get_keyboard_input(self, heading=None, default=None, hidden=False):
        k = xbmc.Keyboard(default, heading, hidden)
        k.doModal()
        input_value = k.getText() if k.isConfirmed() else None
        del k
        return input_value

    def json_rpc(self, method, params=None):
        request_data = {
            "jsonrpc": "2.0",
            "method": method,
            "id": 1,
            "params": params or {},
        }
        response = json.loads(xbmc.executeJSONRPC(json.dumps(request_data)))
        if "error" in response:
            self.log(f"JsonRPC Error {response['error']['code']}: {response['error']['message']}", "debug")
        return response.get("result", {})

    def get_kodi_subtitle_languages(self, iso_format=False):
        subtitle_language = self.json_rpc("Settings.GetSettingValue", {"setting": "subtitles.languages"})
        if iso_format:
            return [self.convert_language_iso(x) for x in subtitle_language["value"]]
        else:
            return list(subtitle_language["value"])

    def get_kodi_preferred_subtitle_language(self, iso_format=False):
        subtitle_language = self.json_rpc("Settings.GetSettingValue", {"setting": "locale.subtitlelanguage"})
        if subtitle_language["value"] in ["forced_only", "original", "default", "none"]:
            return subtitle_language["value"]
        if iso_format:
            return self.convert_language_iso(subtitle_language["value"])
        else:
            return subtitle_language["value"]

    def convert_language_iso(self, from_value):
        return xbmc.convertLanguage(from_value, xbmc.ISO_639_1)

    @staticmethod
    def _apply_listitem_properties(item, info):
        for prop in listitem_properties:
            value = info
            for subkey in prop[0]:
                value = value.get(subkey, {})

            if value:
                item.setProperty(prop[1], str(value))

    @cached_property
    def menu_caching_enabled(self):
        return g.get_bool_setting("general.menucaching")

    @cached_property
    def set_views_enabled(self):
        return g.get_bool_setting("general.setViews")

    @cached_property
    def disable_notification_sound(self):
        return g.get_bool_setting("general.disableNotificationSound")

    @cached_property
    def fanart_fallback_disabled(self):
        return g.get_bool_setting("general.fanart.fallback", False)

    @cached_property
    def studio_limit(self):
        return g.get_bool_setting("general.meta.studiolimit", True)

    def handle_studio_icon_skin_workaround(self, item, info):
        media_type = info.get("mediatype")
        studios = info.get("studio", [])
        property_name = "studio" if media_type == g.MEDIA_MOVIE else "network"

        if isinstance(studios, list) and len(studios) >= 1:
            for studio in reversed(studios):
                if (lower_studio := studio.lower()) in self.studio_icons or (
                    lower_studio.endswith(" ltd.") and (lower_studio := lower_studio[:-5]) in self.studio_icons
                ):
                    item.setProperty(property_name, lower_studio)
                    info['studio'] = studio
                    return

            item.setProperty(property_name, studios[0].lower())
            info['studio'] = studios[0]
        elif studios and isinstance(studios, str):
            item.setProperty(property_name, studios.lower())
            info['studio'] = studios

    _STUDIO_ICONS_KEY = "seren.studio_icons"

    @cached_property
    def studio_icons(self):
        # Try loading from window property (pre-warmed in service.py)
        try:
            window = xbmcgui.Window(10000)
            cached = window.getProperty(self._STUDIO_ICONS_KEY)
            if cached:
                return set(json.loads(cached))
        except Exception:
            pass

        # Fallback: scan filesystem (two listdir calls)
        colored = {i[:-4] for i in xbmcvfs.listdir("resource://resource.images.studios.coloured")[1]}
        white = {i[:-4] for i in xbmcvfs.listdir("resource://resource.images.studios.white")[1]}
        icons = colored | white if (colored and white) else colored or white

        # Store for future plugin calls
        try:
            window = xbmcgui.Window(10000)
            window.setProperty(self._STUDIO_ICONS_KEY, json.dumps(list(icons)))
        except Exception:
            pass

        return icons

    def create_url(self, base_url, params):
        if params is None:
            return base_url
        if "action_args" in params and isinstance(params["action_args"], dict):
            params["action_args"] = json.dumps(params["action_args"], sort_keys=True)
        return f"{base_url}/?{parse.urlencode(sorted(params.items()))}"

    # Singleton monitor — avoids creating/destroying xbmc.Monitor() on every call.
    # During scraping keep-alive loops, abort_requested() and wait_for_abort() are
    # called hundreds of times.
    _MONITOR = None

    @classmethod
    def _get_monitor(cls):
        if cls._MONITOR is None:
            cls._MONITOR = xbmc.Monitor()
        return cls._MONITOR

    @classmethod
    def abort_requested(cls):
        return cls._get_monitor().abortRequested()

    @classmethod
    def wait_for_abort(cls, timeout=1.0):
        return cls._get_monitor().waitForAbort(timeout)

    @staticmethod
    def reload_profile():
        xbmc.executebuiltin(f"LoadProfile({xbmc.getInfoLabel('system.profilename')})")

    @staticmethod
    def validate_date(date_string):
        """Validates the date string and returns in standard date time format, if it is invalid it just returns none.

        :param date_string:string value with a supposed date.
        :type date_string:str
        :return:formatted datetime or none
        :rtype:str
        """
        if not date_string:
            return date_string

        try:
            result = tools.parse_datetime(date_string, False)
        except ValueError:
            return None

        if result and result.year > 1900:
            return str(g.datetime_to_string(result))
        return None

    @staticmethod
    def datetime_to_string(date_time_or_date):
        """
        Converts a datetime or date object to a string in ISO format truncated to seconds and without TZ offset
        If this is a date, then the isoformat for a date without time is returned
        :param date_time_or_date: A datetime.datetime or a datetime.date object
        :return: Datetime or date string in ISO format truncated to seconds and without TZ offset.
                 Empty string if invalid object provided
        :rtype str
        """
        try:
            if hasattr(date_time_or_date, "second"):
                return date_time_or_date.isoformat(timespec="seconds").split("+", 1)[0]
            return date_time_or_date.isoformat()
        except (ValueError, AttributeError):
            return ""

    def utc_to_local(self, utc_string):
        """
        Converts a UTC style datetime string to the local timezone
        :param utc_string: UTC datetime string
        :return: localized datetime string
        """
        if not utc_string:
            return None

        utc = tools.parse_datetime(utc_string, False)
        utc = self.UTC_TIMEZONE.localize(utc)
        local_time = utc.astimezone(self.LOCAL_TIMEZONE)
        return g.datetime_to_string(local_time)

    def local_to_utc_by_country(self, datetime_string, country_code):
        """
        Converts a local datetime string to the utc timezone based on a provided country code
        Note that some countries have moe than one timezone, we choose the first as there is no perfect solution
        :param datetime_string: Local date time string
        :type datetime_string: str
        :param country_code: The ISO-3166 2 char country code
        :return: UTC datetime string
        """
        if not datetime_string:
            return None

        try:
            from resources.lib.third_party import pytz
            local_time = tools.parse_datetime(datetime_string, False)
            tz = pytz.timezone(pytz.country_timezones[country_code][0])  # First timezone for a country
            local_time = tz.localize(local_time)
            utc_time = local_time.astimezone(self.UTC_TIMEZONE)
            return g.datetime_to_string(utc_time)
        except (KeyError, IndexError, Exception) as e:
            g.log(
                f"Unable to covert local time to utc based on country_code='{country_code}', "
                f"datetime_string='{datetime_string}'/n{e}",
                "error",
            )
            return None

    def open_addon_settings(self, section_offset, setting_offset=None):
        """
        Open seren settings at a particular section and setting
        :param section_offset: Section number starting at 0
        :type section_offset: int
        :param setting_offset: Setting number within section, starting at 0.  Note that sep / lsep are counted.
        :type setting_offset: None|int
        :return:
        """
        xbmc.executebuiltin(f"Addon.OpenSettings({self.ADDON_ID})")
        xbmc.executebuiltin(f"SetFocus({-(200 - section_offset)})")
        if setting_offset is not None:
            xbmc.executebuiltin(f"SetFocus({-(179 - setting_offset)})")

    def create_icon_dict(self, icon_slug, base_path, art_types=None):
        keys = art_types or ['icon', 'poster', 'thumb', 'fanart']
        return {"art": dict.fromkeys(keys, f"{base_path}{icon_slug}.png")}


g = GlobalVariables()
