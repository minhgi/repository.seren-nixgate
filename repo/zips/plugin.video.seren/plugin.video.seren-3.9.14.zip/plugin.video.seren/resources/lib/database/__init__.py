import os
import pickle
import sqlite3
import threading
import types
from abc import ABCMeta
from abc import abstractmethod
from contextlib import contextmanager
from functools import wraps

import xbmcvfs

from resources.lib.common import tools
from resources.lib.modules.exceptions import RanOnceAlready
from resources.lib.modules.global_lock import GlobalLock
from resources.lib.modules.globals import g

try:
    pickletype = buffer  # noqa: F821  pylint: disable=undefined-variable
except NameError:
    pickletype = bytes

# Session-level set of (db_file, schema_checksum) pairs that have already passed
# _integrity_check_db this session.  Skips the md5_hash + GlobalLock + xbmcvfs.exists +
# file-read on every Database subclass instantiation after the first.  Ported from
# Otaku's _tables_ready pattern (database.py _ensure_table).
_DB_INITIALIZED: set = set()

# Per-thread, per-db-file SQLite connections, kept open for the thread's lifetime
# instead of open-query-close on every fetchall/fetchone/execute_sql call. Deliberately
# thread-local rather than one shared connection: SQLite/WAL already lets concurrent
# readers run unserialized, and a single connection shared across threads would need a
# lock around every query to avoid interleaving BEGIN/COMMIT state — that lock would
# serialize the very reads WAL was letting run in parallel. Thread-local keeps each
# thread's transaction state private and needs no cross-thread lock at all.
# Keyed as {db_file: (connection, generation)} per thread; _DB_GENERATION lets
# rebuild_database() invalidate every thread's cached connection for a file without
# reaching into other threads' storage — see reference_seren_migration_cache_rebuild_trap.
_THREAD_LOCAL = threading.local()
_DB_GENERATION: dict = {}
_DB_GENERATION_LOCK = threading.Lock()


def _get_thread_connection(db_file):
    connections = getattr(_THREAD_LOCAL, "connections", None)
    if connections is None:
        connections = {}
        _THREAD_LOCAL.connections = connections

    current_gen = _DB_GENERATION.get(db_file, 0)
    entry = connections.get(db_file)
    if entry is not None:
        connection, generation = entry
        if generation == current_gen:
            return connection
        connection.close()  # db_file was rebuilt since this thread opened it

    connection = SQLiteConnection(db_file, keep_alive=True)
    connection.connect()
    connections[db_file] = (connection, current_gen)
    return connection


def _evict_thread_connection(db_file):
    """Drop this thread's cached connection for db_file after a query fails.

    _execute_query's own retry loop re-issues BEGIN on the same connection on
    retry — if a rare failure (e.g. COMMIT itself hitting "database is locked")
    leaves the transaction open rather than rolled back, that BEGIN would fail
    every time from then on. Under the old open-query-close pattern a failing
    connection was simply discarded next call; pooling removed that accidental
    reset, so this restores it explicitly: evict on failure, reopen clean next use.
    """
    connections = getattr(_THREAD_LOCAL, "connections", None)
    if not connections:
        return
    entry = connections.pop(db_file, None)
    if entry is not None:
        entry[0].close()


def _run_pooled(db_file, method_name, query, data):
    connection = _get_thread_connection(db_file)
    try:
        return getattr(connection, method_name)(query, data)
    except Exception:
        _evict_thread_connection(db_file)
        raise


def _handle_single_item_or_list(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        if isinstance(args[-1], (list, types.GeneratorType)):
            return [func(*args[:-1] + (i,), **kwargs) for i in args[-1]]
        return func(*args, **kwargs)

    return wrapper


@_handle_single_item_or_list
def _dumps(obj):
    """Pickling method.

    :param obj:Object to be pickled
    :type obj:any
    :return:Bytes with the pickled content
    :rtype:bytes
    """
    if obj is None:
        return None
    return tuple(
        pickle.dumps(i, protocol=pickle.HIGHEST_PROTOCOL) if i.__class__.__name__ in PICKLE_TYPES else i for i in obj
    )


def _loads(value):
    """Depickling method.

    :param value:Bytes with the pickled object
    :type value:str|bytes
    :return:Depickled value
    :rtype:any
    """
    try:
        return pickle.loads(value) if isinstance(value, pickletype) else value
    except pickle.UnpicklingError:
        return value


PICKLE_TYPES = {"list", "set", "dict", "tuple", "Response"}


class Database:
    def __init__(self, db_file, database_layout):
        self._db_file = db_file
        self._database_layout = database_layout
        self._integrity_check_db()

    # region DatabaseSchema
    # region private methods
    def _create_tables(self, connection):
        for table_name, data in self._database_layout.items():
            self._create_table(connection, table_name, data)
        return connection

    def _create_table(self, connection, table_name, data):
        table_data = [
            self._create_column_expression(column_name, column_declaration)
            for column_name, column_declaration in data["columns"].items()
        ]
        table_data.extend(data["table_constraints"])

        connection.execute(f"CREATE TABLE IF NOT EXISTS [{table_name}]({','.join(table_data)})")
        indices = data.get("indices")
        if indices and len(indices) > 0:
            for index_name, columns in indices:
                connection.execute(f"CREATE INDEX IF NOT EXISTS [{index_name}] ON {table_name}({','.join(columns)})")
        default_seed = data["default_seed"]
        if not default_seed or len(default_seed) == 0:
            return
        query = f"""
            INSERT OR IGNORE INTO [{table_name}] ({','.join(data['columns'])})
            VALUES ({','.join(['?' for _ in data['columns']])})
            """

        for row_values in (tuple(row) for row in data["default_seed"]):
            connection.execute(query, row_values)

    @staticmethod
    def _create_column_expression(column_name, column_declaration):
        return f"{column_name} {' '.join(column_declaration)}"

    def _integrity_check_db(self):
        db_file_checksum = tools.md5_hash(self._database_layout)
        init_key = (self._db_file, db_file_checksum)
        if init_key in _DB_INITIALIZED:
            return  # already verified this session — skip md5_hash + GlobalLock + file I/O
        try:
            with GlobalLock(self.__class__.__name__, True, db_file_checksum):
                if xbmcvfs.exists(self._db_file) and g.read_all_text(f"{self._db_file}.md5") == db_file_checksum:
                    _DB_INITIALIZED.add(init_key)
                    return
                g.log(f"Integrity checked failed - {self._db_file} - {db_file_checksum} - rebuilding db")
                self.rebuild_database()
                g.write_all_text(f"{self._db_file}.md5", db_file_checksum)
                _DB_INITIALIZED.add(init_key)
        except RanOnceAlready:
            _DB_INITIALIZED.add(init_key)  # concurrent check already handled it
            return

    # endregion

    # region public methods
    def rebuild_database(self):
        g.log(f"Rebuilding database: {self._db_file}")
        # PRAGMA journal_mode below needs no other connection open to this file —
        # drop this thread's own pooled one first so it can't self-collide.
        _evict_thread_connection(self._db_file)
        with SQLiteConnection(self._db_file) as sqlite:
            # Switch to fast-bulk PRAGMAs: synchronous=OFF + journal_mode=MEMORY avoids
            # repeated fsync and disk-journal writes during the heavy DROP + VACUUM + recreate.
            # Ported from POV clean_databases() PRAGMA pattern.  Cache DBs are fully
            # rebuildable so data-loss risk on crash is acceptable. Best-effort: switching
            # off WAL requires no other connection have the file open, and the eviction
            # above only covers this thread — another thread's pooled connection can still
            # hold it, so fall through on default (WAL) PRAGMAs rather than crash the caller.
            try:
                with sqlite.cursor() as cur:
                    cur.execute("PRAGMA synchronous = OFF")
                    cur.execute("PRAGMA journal_mode = MEMORY")
            except sqlite3.OperationalError:
                g.log(
                    f"Fast-bulk PRAGMA unavailable for {self._db_file} rebuild (file in use elsewhere) — using defaults",
                    "warning",
                )

            with sqlite.transaction() as transaction:
                transaction.execute("PRAGMA writable_schema = ON")
                transaction.execute("DELETE FROM sqlite_master WHERE type IN ('table', 'index', 'trigger')")
                transaction.execute("PRAGMA writable_schema = OFF")

            with sqlite.cursor() as cursor:
                cursor.execute("VACUUM")

            with sqlite.transaction():
                self._create_tables(sqlite._connection)

            # Restore standard PRAGMAs so subsequent operations use normal durability.
            with sqlite.cursor() as cur:
                cur.execute("PRAGMA synchronous = NORMAL")
                cur.execute("PRAGMA journal_mode = WAL")

        # Invalidate every thread's pooled connection for this file — the rebuild
        # above used its own ad-hoc connection, so any thread-local one is now stale.
        with _DB_GENERATION_LOCK:
            _DB_GENERATION[self._db_file] = _DB_GENERATION.get(self._db_file, 0) + 1

    def fetchall(self, query, data=None):
        return _run_pooled(self._db_file, "fetchall", query, data)

    def fetchone(self, query, data=None):
        return _run_pooled(self._db_file, "fetchone", query, data)

    def execute_sql(self, query, data=None):
        return _run_pooled(self._db_file, "execute_sql", query, data)

    def create_temp_table(self, table_name, columns, primary_key=None):
        return TempTable(self, table_name, columns, primary_key)

    # endregion


class _connection(metaclass=ABCMeta):
    def __init__(self, keep_alive=False):
        self._keep_alive = keep_alive
        self._connection = None

    def __enter__(self):
        self.connect()
        if not self._connection:
            g.log("Database _create_connection() failed!", "error")
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if not self._keep_alive:
            self.close()

    def __del__(self):
        self.close()

    def connect(self):
        if not self._connection:
            self._connection = self._create_connection()

    def close(self):
        if self._connection:
            self._connection.close()

    @abstractmethod
    def _create_connection(self):
        pass

    @abstractmethod
    def _create_cursor(self):
        pass

    @contextmanager
    def cursor(self):
        self.connect()
        cursor = self._connection.cursor()
        try:
            yield cursor
        finally:
            cursor.close()

    @contextmanager
    def smart_transaction(self, query):
        no_transaction_keywords = ["select ", "vacuum"]

        if (
            isinstance(query, list)
            and any(
                k for k in no_transaction_keywords if any(q for q in query if q[:10].lstrip().lower().startswith(k))
            )
            or not isinstance(query, list)
            and any(k for k in no_transaction_keywords if query[:10].lstrip().lower().startswith(k))
        ):
            with self.cursor() as cursor:
                yield cursor
        else:
            with self.transaction() as transaction:
                yield transaction

    @contextmanager
    def transaction(self):
        with self.cursor() as cursor:
            cursor.execute("BEGIN")
            try:
                yield cursor
            except BaseException as be:
                try:
                    cursor.execute("ROLLBACK")
                finally:
                    if isinstance(be, Exception):
                        raise
            else:
                cursor.execute("COMMIT")

    def fetchall(self, query, data=None):
        return self._execute_query(_dumps(data), "fetchall", query)

    def fetchone(self, query, data=None):
        return self._execute_query(_dumps(data), "fetchone", query)

    def execute_sql(self, query, data=None):
        return self._execute_query(_dumps(data), None, query)

    @abstractmethod
    def _retry_handler(self, exception):
        raise exception

    @_handle_single_item_or_list
    def _execute_query(self, data, result_method, query, retries=50):
        retry_count = 0
        while retry_count <= retries:
            try:
                with self.smart_transaction(query) as cursor:
                    if isinstance(data, (list, types.GeneratorType)):
                        cursor.executemany(query, data)
                    elif data:
                        cursor.execute(query, data)
                    else:
                        cursor.execute(query)

                    if result_method == "fetchone":
                        return cursor.fetchone()
                    elif result_method == "fetchall":
                        return cursor.fetchall()
                    else:
                        return cursor
            except Exception as e:
                try:
                    self._retry_handler(e)
                    retry_count += 1
                except Exception:
                    self._log_error(query, data)
                    raise

    @staticmethod
    def _log_error(query, data):
        if data:
            g.log(f"{query}\n{data}", "error")
        else:
            g.log(query, "error")


class SQLiteConnection(_connection):
    def __init__(self, path, keep_alive=False):
        super().__init__(keep_alive=keep_alive)
        self.path = path
        self._create_db_path()

    def _create_connection(self):
        retries = 0
        exception = None
        while retries != 50 and not g.abort_requested():
            try:
                connection = sqlite3.connect(  # pylint: disable=no-member
                    self.path,
                    timeout=30,
                    detect_types=sqlite3.PARSE_DECLTYPES,  # pylint: disable=no-member
                    isolation_level=None,
                    check_same_thread=False,
                )
                self._set_connection_settings(connection)
                return connection
            except Exception as error:
                self._retry_handler(error)
                exception = error
            retries += 1
        # If we reach here we have exceeded our retries so just raise the last exception
        g.log(f"Unable to connect to database '{self.path}' {exception=}", "error")
        if isinstance(exception, BaseException):
            raise exception
        raise RuntimeError(str(exception))

    def _retry_handler(self, exception):
        if isinstance(exception, sqlite3.OperationalError) and (  # pylint: disable=no-member
            "database is locked" in str(exception) or "unable to open database" in str(exception)
        ):
            g.log(
                f"database is locked waiting: {self.path}",
                "warning",
            )
            g.wait_for_abort(0.1)
        else:
            super()._retry_handler(exception)

    def _create_cursor(self):
        super()._create_cursor()
        return self._connection.cursor()

    @staticmethod
    def _set_connection_settings(connection):
        connection.row_factory = lambda c, r: {
            col[0]: _loads(r[idx]) if isinstance(r[idx], pickletype) else r[idx]
            for idx, col in enumerate(c.description)
        }
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA page_size = 32768")  # no-translate
        connection.execute("PRAGMA journal_mode = WAL")
        connection.execute("PRAGMA synchronous = normal")
        connection.execute("PRAGMA temp_store = memory")
        connection.execute("PRAGMA mmap_size = 30000000000")

    def _create_db_path(self):
        if not xbmcvfs.exists(os.path.dirname(self.path)):
            xbmcvfs.mkdirs(os.path.dirname(self.path))


class MySqlConnection(_connection):
    from functools import cached_property

    def __init__(self, config, keep_alive=False):
        # keep_alive defaults False to match SQLiteConnection: the sole caller
        # (globals.clear_kodi_bookmarks) is a self-contained `with` block that
        # should close its connection deterministically on exit, the same way the
        # SQLite branch does - not leave it open until GC/__del__ collects it.
        super().__init__(keep_alive=keep_alive)
        self.config = {
            'user': config.get("user"),
            'password': config.get("password"),
            'host': config.get("host"),
            'port': config.get("port"),
            'database': config.get("database"),
            'autocommit': True,
            'charset': 'utf8',
            'use_unicode': True,
        }

    @cached_property
    def mysql(self):
        import mysql.connector

        return mysql.connector

    @cached_property
    def MySQLCursorDict(self):
        from resources.lib.database.mysql_cursor_dict import MySQLCursorDict

        return MySQLCursorDict

    def _create_connection(self):
        return self.mysql.connect(**self.config)

    def _create_cursor(self):
        return self._connection.cursor(cursor_class=self.MySQLCursorDict)

    def _retry_handler(self, exception):
        super()._retry_handler(exception)


class TempTable:
    def __init__(self, database, table_name, columns, primary_key=None):
        self.database = database
        self.columns = columns
        self.table_name = table_name
        self.primary_key = primary_key

    def __enter__(self):
        self._drop_table()
        self._create_table()
        return self

    def insert_data(self, data):
        columns = ",".join(f"[{c}]" for c in self.columns)
        placeholder = ",".join("?" for _ in self.columns)

        self.database.execute_sql(
            f"INSERT OR IGNORE INTO [{self.table_name}] ({columns}) VALUES ({placeholder})",
            (tuple(row[i] for i in self.columns) for row in data),
        )

    def __exit__(self, exc_type, exc_val, exc_tb):
        self._drop_table()

    def _create_table(self):
        self.database.execute_sql(
            f"""
            CREATE TABLE IF NOT EXISTS [{self.table_name}] ({",".join(f"[{c}] VARCHAR" for c in self.columns)}{
                f',PRIMARY KEY ({self.primary_key}), UNIQUE ({self.primary_key})' if self.primary_key else ''
            })
            """
        )

    def _drop_table(self):
        self.database.execute_sql(f"drop table if exists [{self.table_name}]")
